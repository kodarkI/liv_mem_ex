#!/usr/bin/env python3
"""
Memory Control: Routes incoming experiences and detects changes
Reference: .augment/skills/liv-mem/references/04-operating-contracts.md
"""
import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional

class MemoryControl:
    """Routes Current Experience through governance before assigning permanence"""

    def __init__(self, memory_root: Path):
        self.memory_root = Path(memory_root)
        self.experiences_dir = self.memory_root / "data" / "experiences"
        self.experiences_dir.mkdir(parents=True, exist_ok=True)

    def receive_experience(self,
                          source: str,
                          content: Dict[str, Any],
                          source_entity_id: Optional[str] = None,
                          occurred_at: Optional[str] = None) -> str:
        """
        Create immutable Experience record
        Returns: experience_id
        """
        experience_id = str(uuid.uuid4())
        received_at = datetime.utcnow().isoformat() + 'Z'

        experience = {
            "id": experience_id,
            "source": source,
            "source_entity_id": source_entity_id,
            "occurred_at": occurred_at or received_at,
            "received_at": received_at,
            "content": content,
            "interpretation_status": "raw",
            "truth_status": "asserted",  # ASSERTED → VALIDATED → SUPPORTED → EFFECTIVE → HISTORICAL
            "routed_to": [],
            "retention_level": "ephemeral"  # Default until governed
        }

        # Write immutable experience
        exp_file = self.experiences_dir / f"{experience_id}.json"

        # Check for duplicate experiences (per ref 08, lines 64-68)
        duplicate_id = self._find_duplicate_experience(source, content, source_entity_id)
        if duplicate_id:
            # Return existing experience ID instead of creating duplicate
            return duplicate_id

        with open(exp_file, 'w') as f:
            json.dump(experience, f, indent=2)

        return experience_id

    def route_experience(self, experience_id: str) -> Dict[str, List[str]]:
        """
        Analyze experience and determine memory operations
        Returns: routing decisions
        """
        exp_file = self.experiences_dir / f"{experience_id}.json"
        with open(exp_file, 'r') as f:
            experience = json.load(f)

        routing = {
            "entity_operations": [],
            "state_operations": [],
            "relationship_operations": [],
            "direction_operations": [],
            "skill_operations": []
        }

        content_type = experience["content"].get("type")
        text = experience["content"].get("text", "")

        # Simple routing heuristics (to be refined)
        if content_type == "message":
            # Check for entity mentions, state changes, relationships
            if any(word in text.lower() for word in ["i am", "my name", "i'm"]):
                routing["entity_operations"].append("identify_source_entity")

            if any(word in text.lower() for word in ["build", "create", "implement"]):
                routing["direction_operations"].append("establish_intent")

            # State changes: working on, started, now doing, etc.
            if any(word in text.lower() for word in ["working on", "work on", "started", "now doing", "currently"]):
                routing["state_operations"].append("state_update")

            if any(word in text.lower() for word in ["works on", "depends on", "relates to", "work on"]):
                routing["relationship_operations"].append("propose_relationship")

        # Update experience with routing
        experience["interpretation_status"] = "routed"
        experience["routed_to"] = [
            op for ops in routing.values() for op in ops
        ]

        # Advance truth status: ASSERTED → VALIDATED (structure checks passed)
        if experience["truth_status"] == "asserted":
            experience["truth_status"] = "validated"
            experience["validated_at"] = datetime.utcnow().isoformat() + 'Z'

        with open(exp_file, 'w') as f:
            json.dump(experience, f, indent=2)

        return routing

    def get_experience(self, experience_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve an experience by ID"""
        exp_file = self.experiences_dir / f"{experience_id}.json"
        if not exp_file.exists():
            return None
        with open(exp_file, 'r') as f:
            return json.load(f)

    def update_retention(self, experience_id: str, retention_decision: Dict[str, Any]):
        """Update experience with governance retention decision"""
        exp_file = self.experiences_dir / f"{experience_id}.json"
        with open(exp_file, 'r') as f:
            experience = json.load(f)

        experience["retention_level"] = retention_decision["level"]
        experience["retention_decision"] = retention_decision

        # Advance truth status based on retention
        # VALIDATED → SUPPORTED (has evidence via routing)
        if experience["truth_status"] == "validated" and retention_decision["level"] in ["retained", "durable"]:
            experience["truth_status"] = "supported"
            experience["supported_at"] = datetime.utcnow().isoformat() + 'Z'

        # SUPPORTED → EFFECTIVE (governance accepts as current truth)
        if experience["truth_status"] == "supported" and retention_decision["level"] == "durable":
            experience["truth_status"] = "effective"
            experience["effective_at"] = datetime.utcnow().isoformat() + 'Z'

        with open(exp_file, 'w') as f:
            json.dump(experience, f, indent=2)

        # After becoming EFFECTIVE, check for conflicts with other EFFECTIVE experiences
        if experience.get("truth_status") == "effective":
            conflicts = self.detect_conflicts(experience_id)
            if conflicts:
                resolution = self.resolve_conflict(experience_id, conflicts)
                # Update experience with resolution info
                with open(exp_file, 'r') as f:
                    exp_data = json.load(f)
                exp_data["conflict_resolution"] = resolution["resolution_id"]
                with open(exp_file, 'w') as f:
                    json.dump(exp_data, f, indent=2)

    def mark_as_historical(self, experience_id: str, reason: str):
        """Mark experience truth status as HISTORICAL (was effective, now superseded)"""
        exp_file = self.experiences_dir / f"{experience_id}.json"
        with open(exp_file, 'r') as f:
            experience = json.load(f)

        experience["truth_status"] = "historical"
        experience["made_historical_at"] = datetime.utcnow().isoformat() + 'Z'
        experience["historical_reason"] = reason

        with open(exp_file, 'w') as f:
            json.dump(experience, f, indent=2)

    def mark_as_qualified(self, experience_id: str, reason: str):
        """
        Mark experience truth status as QUALIFIED
        (remains recorded but limited/corrected by later decision)
        Per ref 08, line 43
        """
        exp_file = self.experiences_dir / f"{experience_id}.json"
        with open(exp_file, 'r') as f:
            experience = json.load(f)

        experience["truth_status"] = "qualified"
        experience["qualified_at"] = datetime.utcnow().isoformat() + 'Z'
        experience["qualification_reason"] = reason

        with open(exp_file, 'w') as f:
            json.dump(experience, f, indent=2)

    def mark_as_contested(self, experience_id: str, reason: str):
        """
        Mark experience truth status as CONTESTED
        (competing claims cannot be resolved under current policy)
        Per ref 08, line 42
        """
        exp_file = self.experiences_dir / f"{experience_id}.json"
        with open(exp_file, 'r') as f:
            experience = json.load(f)

        experience["truth_status"] = "contested"
        experience["contested_at"] = datetime.utcnow().isoformat() + 'Z'
        experience["contested_reason"] = reason

        with open(exp_file, 'w') as f:
            json.dump(experience, f, indent=2)

    def detect_conflicts(self, new_experience_id: str) -> List[str]:
        """
        Detect if new experience conflicts with existing EFFECTIVE experiences

        Simple conflict detection:
        - Same entity, same topic, different claims
        - Returns list of conflicting experience IDs
        """
        new_exp = self.get_experience(new_experience_id)
        if not new_exp or new_exp.get("truth_status") not in ["effective", "supported"]:
            return []  # Only check if new experience is significant

        new_entity = new_exp.get("source_entity_id")
        new_text = new_exp.get("content", {}).get("text", "").lower()

        conflicts = []

        # Check all experiences from same entity
        for exp_file in self.experiences_dir.glob("*.json"):
            try:
                with open(exp_file, 'r', encoding='utf-8') as f:
                    exp = json.load(f)

                # Skip self
                if exp.get("id") == new_experience_id:
                    continue

                # Only check EFFECTIVE experiences
                if exp.get("truth_status") != "effective":
                    continue

                # Same entity?
                if exp.get("source_entity_id") == new_entity:
                    exp_text = exp.get("content", {}).get("text", "").lower()

                    # Simple conflict heuristics (can be improved)
                    # Detect negation patterns
                    if self._texts_conflict(new_text, exp_text):
                        conflicts.append(exp.get("id"))
            except:
                continue

        return conflicts

    def _texts_conflict(self, text1: str, text2: str) -> bool:
        """
        Simple heuristic to detect if two texts conflict
        Real implementation would use NLP
        """
        # Negation patterns
        negations = ["not", "no longer", "stop", "quit", "instead", "actually", "rather"]
        correction_patterns = ["i mean", "correction", "wrong", "mistake"]

        # Check for explicit negation or correction
        has_negation = any(neg in text1 for neg in negations)
        has_correction = any(pat in text1 for pat in correction_patterns)

        if has_negation or has_correction:
            # Extract content words (ignore common words)
            stop_words = {"i", "am", "is", "are", "the", "a", "an", "on", "in", "at", "to", "for", "of", "and", "or", "i'm"}

            # Strip punctuation from words
            import string
            words1 = set(w.strip(string.punctuation).lower() for w in text1.split()
                        if w.strip(string.punctuation).lower() not in stop_words and len(w.strip(string.punctuation)) > 2)
            words2 = set(w.strip(string.punctuation).lower() for w in text2.split()
                        if w.strip(string.punctuation).lower() not in stop_words and len(w.strip(string.punctuation)) > 2)
            shared = words1.intersection(words2)

            # If they share content words and one has negation/correction, it's a conflict
            if len(shared) >= 2:  # Lowered threshold
                return True

        return False

    def resolve_conflict(self, new_experience_id: str, conflicting_ids: List[str],
                        resolution_policy: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Resolve conflict between new experience and existing ones

        Per architecture (ref 08-memory-lifecycle, lines 50-61):
        - Retain both records (don't delete)
        - Check: source authority, directness, corroboration, effective time, explicit correction
        - If one wins → EFFECTIVE, others → HISTORICAL or QUALIFIED
        - If can't decide → all CONTESTED, request resolution
        - Newer is NOT automatically truer

        Args:
            new_experience_id: New experience that conflicts
            conflicting_ids: List of conflicting experience IDs
            resolution_policy: Optional policy with strategies and factors

        Returns: resolution record
        """
        new_exp = self.get_experience(new_experience_id)
        new_time = new_exp.get("received_at")
        new_source = new_exp.get("source")

        # Default policy if none provided
        if not resolution_policy:
            resolution_policy = {
                "strategies": ["explicit_correction", "source_authority", "temporal_precedence"],
                "source_authority_order": ["user", "agent", "system"],
                "require_explicit_correction_keywords": True
            }

        resolution = {
            "resolution_id": str(uuid.uuid4()),
            "resolved_at": datetime.utcnow().isoformat() + 'Z',
            "new_experience": new_experience_id,
            "conflicting_experiences": conflicting_ids,
            "superseded_experiences": [],
            "contested_experiences": [],
            "qualified_experiences": [],
            "resolution_strategy": None,
            "reason": None,
            "policy_version": "v1.0"
        }

        # Try resolution strategies in order
        for strategy in resolution_policy.get("strategies", []):
            result = self._try_resolution_strategy(
                strategy, new_exp, conflicting_ids, resolution_policy
            )

            if result["resolved"]:
                resolution["resolution_strategy"] = strategy
                resolution["reason"] = result["reason"]

                # Apply resolution
                if result["winner_id"] == new_experience_id:
                    # New experience wins
                    for conflict_id in conflicting_ids:
                        conflict_exp = self.get_experience(conflict_id)

                        if result.get("qualify_losers"):
                            self.mark_as_qualified(conflict_id, result["reason"])
                            resolution["qualified_experiences"].append(conflict_id)
                        else:
                            self.mark_as_historical(conflict_id, result["reason"])
                            resolution["superseded_experiences"].append({
                                "id": conflict_id,
                                "superseded_at": datetime.utcnow().isoformat() + 'Z',
                                "original_truth_status": conflict_exp.get("truth_status")
                            })
                else:
                    # Old experience wins, mark new as qualified or historical
                    if result.get("qualify_losers"):
                        self.mark_as_qualified(new_experience_id, result["reason"])
                        resolution["qualified_experiences"].append(new_experience_id)
                    else:
                        self.mark_as_historical(new_experience_id, result["reason"])

                # Record resolution in winner
                self._record_conflict_resolution(result["winner_id"], resolution["resolution_id"], conflicting_ids)
                return resolution

        # No strategy resolved the conflict → CONTESTED
        resolution["resolution_strategy"] = "contested"
        resolution["reason"] = "Competing claims cannot be resolved under current policy"

        # Mark all as CONTESTED
        for exp_id in [new_experience_id] + conflicting_ids:
            self.mark_as_contested(exp_id, resolution["reason"])
            resolution["contested_experiences"].append(exp_id)

        return resolution

    def _try_resolution_strategy(self, strategy: str, new_exp: Dict, conflicting_ids: List[str],
                                 policy: Dict) -> Dict[str, Any]:
        """Try a specific conflict resolution strategy"""

        if strategy == "explicit_correction":
            # Check if new experience explicitly corrects old one
            new_text = new_exp.get("content", {}).get("text", "").lower()
            correction_keywords = ["actually", "correction", "i mean", "mistake", "wrong", "not"]

            if policy.get("require_explicit_correction_keywords") and \
               any(kw in new_text for kw in correction_keywords):
                return {
                    "resolved": True,
                    "winner_id": new_exp["id"],
                    "reason": "Explicit correction statement supersedes previous claim",
                    "qualify_losers": False
                }

        elif strategy == "source_authority":
            # Check source authority hierarchy
            authority_order = policy.get("source_authority_order", ["user", "agent", "system"])
            new_source = new_exp.get("source")

            for conflict_id in conflicting_ids:
                conflict_exp = self.get_experience(conflict_id)
                conflict_source = conflict_exp.get("source")

                try:
                    new_rank = authority_order.index(new_source)
                    conflict_rank = authority_order.index(conflict_source)

                    if new_rank < conflict_rank:
                        return {
                            "resolved": True,
                            "winner_id": new_exp["id"],
                            "reason": f"Source '{new_source}' has higher authority than '{conflict_source}'",
                            "qualify_losers": True
                        }
                    elif conflict_rank < new_rank:
                        return {
                            "resolved": True,
                            "winner_id": conflict_id,
                            "reason": f"Source '{conflict_source}' has higher authority than '{new_source}'",
                            "qualify_losers": True
                        }
                except ValueError:
                    continue

        elif strategy == "temporal_precedence":
            # Only use if same scope and explicit update
            new_time = new_exp.get("received_at")

            for conflict_id in conflicting_ids:
                conflict_exp = self.get_experience(conflict_id)
                conflict_time = conflict_exp.get("received_at")

                # Temporal precedence only if newer AND same source entity
                if new_exp.get("source_entity_id") == conflict_exp.get("source_entity_id"):
                    if new_time > conflict_time:
                        return {
                            "resolved": True,
                            "winner_id": new_exp["id"],
                            "reason": "Same source entity: newer assertion supersedes older (temporal precedence)",
                            "qualify_losers": False
                        }

        # Strategy didn't resolve
        return {"resolved": False}

    def _record_conflict_resolution(self, winner_id: str, resolution_id: str, all_conflict_ids: List[str]):
        """Record conflict resolution in winner experience"""
        exp_file = self.experiences_dir / f"{winner_id}.json"
        with open(exp_file, 'r') as f:
            exp_data = json.load(f)

        exp_data["conflict_resolution"] = resolution_id
        exp_data["supersedes"] = all_conflict_ids

        with open(exp_file, 'w') as f:
            json.dump(exp_data, f, indent=2)


    def _find_duplicate_experience(self, source: str, content: Dict[str, Any],
                                   source_entity_id: Optional[str]) -> Optional[str]:
        """
        Find duplicate experience to avoid recording same thing twice

        Per ref 08, lines 64-68:
        "Preserve each submitted Experience. Compare claims field-by-field;
         link only exact or policy-defined semantic duplicates."

        Returns: experience_id if duplicate found, None otherwise
        """
        import string

        # Only check recent experiences (last 100)
        recent_experiences = sorted(
            self.experiences_dir.glob("*.json"),
            key=lambda p: p.stat().st_mtime,
            reverse=True
        )[:100]

        content_type = content.get("type")
        content_text = content.get("text", "").lower().strip()

        # Normalize text
        content_text_normalized = content_text.translate(str.maketrans('', '', string.punctuation))

        for exp_file in recent_experiences:
            try:
                with open(exp_file, 'r', encoding='utf-8') as f:
                    exp = json.load(f)

                # Same source and entity?
                if exp.get("source") != source:
                    continue
                if exp.get("source_entity_id") != source_entity_id:
                    continue

                # Same content type?
                exp_content = exp.get("content", {})
                if exp_content.get("type") != content_type:
                    continue

                # Same text (normalized)?
                exp_text = exp_content.get("text", "").lower().strip()
                exp_text_normalized = exp_text.translate(str.maketrans('', '', string.punctuation))

                if content_text_normalized == exp_text_normalized:
                    # Exact duplicate found
                    return exp.get("id")
            except:
                continue

        return None

    # ============================================================================
    # Governed Recall (Per GOVERNED_RECALL_DESIGN.md)
    # ============================================================================

    def recall_relevant_experiences(self,
                                    query_context: Dict[str, Any],
                                    current_directions: List[str] = None,
                                    retention_levels: List[str] = None,
                                    limit: int = 20) -> Dict[str, Any]:
        """
        Recall past experiences through governed architecture flow

        Per ref 02 line 9:
        "Memory Control perceives, identifies, interprets, detects changes,
         detects Relationships, and routes operations."

        Per ref 03 line 36:
        "Require Skills to operate through Memory Control and Memory Governance
         rather than bypassing them."

        This is the CORRECT way to recall - routes through:
        Memory Control → Historical Integration → Relevance → Governance

        NOT: Direct filesystem search (violates architecture)

        Args:
            query_context: Current situation requiring recall
                {
                    "type": "user_question",
                    "text": "experiment from first conversation",
                    "entities": [],
                    "topics": ["experiment", "challenge", "test"]
                }
            current_directions: Active direction IDs for relevance filtering
            retention_levels: Filter by retention (default: ["durable"])
            limit: Max results to return

        Returns:
            {
                "query": {...},
                "recall_method": "governed_historical_integration",
                "experiences": [...],
                "governance_decision": {...}
            }
        """
        # Import at top of file to avoid circular import issues
        import sys
        from pathlib import Path as ImportPath
        if str(ImportPath(__file__).parent) not in sys.path:
            sys.path.insert(0, str(ImportPath(__file__).parent))

        from memory_governance import MemoryGovernance

        # Default to DURABLE only
        if retention_levels is None:
            retention_levels = ["durable"]

        recall_timestamp = datetime.utcnow().isoformat() + 'Z'

        # Step 1: Load all experiences matching retention filter
        candidates = []
        for exp_file in self.experiences_dir.glob('*.json'):
            with open(exp_file, 'r') as f:
                exp = json.load(f)

            # Filter by retention level
            if exp.get('retention_level') in retention_levels:
                candidates.append(exp)

        # Step 2: Evaluate relevance through Governance
        governance = MemoryGovernance(self.memory_root)
        relevant_experiences = []

        for exp in candidates:
            relevance = governance.evaluate_relevance_for_recall(
                exp,
                query_context,
                current_directions or []
            )

            if relevance["is_relevant"]:
                exp_with_relevance = exp.copy()
                exp_with_relevance["relevance_score"] = relevance["relevance_score"]
                exp_with_relevance["relevance_reason"] = relevance["reason"]
                relevant_experiences.append(exp_with_relevance)

        # Step 3: Sort by relevance score (descending) then by recency
        relevant_experiences.sort(
            key=lambda e: (e.get("relevance_score", 0), e.get("occurred_at", "")),
            reverse=True
        )

        # Step 4: Limit results
        results = relevant_experiences[:limit]

        # Step 5: Return governed results
        all_exp_count = len([e for e in self._load_all_experiences()])

        return {
            "query": {
                "context": query_context,
                "directions": current_directions,
                "timestamp": recall_timestamp
            },
            "recall_method": "governed_historical_integration",
            "candidates_considered": len(candidates),
            "results_returned": len(results),
            "experiences": results,
            "governance_decision": {
                "filtered_by_retention": all_exp_count - len(candidates),
                "filtered_by_relevance": len(candidates) - len(relevant_experiences),
                "final_count": len(results)
            }
        }

    def _load_all_experiences(self) -> List[Dict]:
        """Helper to load all experiences"""
        experiences = []
        for exp_file in self.experiences_dir.glob('*.json'):
            with open(exp_file, 'r') as f:
                experiences.append(json.load(f))
        return experiences
