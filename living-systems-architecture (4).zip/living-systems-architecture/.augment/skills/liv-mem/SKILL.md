---
name: living-systems-architecture
description: Apply when designing, reviewing, or documenting a system that must preserve continuity through change across identity, current state, relationships, history, relevance, and direction; use it to structure living memory and explicitly surface unresolved lower-level mechanics rather than inventing them.
---

# Living Systems Architecture

## 🚨 IMMEDIATE ACTION REQUIRED: Read This FIRST 🚨

**IF `.living-memory/bootstrap_context.json` EXISTS:**

1. **STOP** - Do not read ANY markdown files yet
2. **LOAD** - Experience records from `.living-memory/experiences/*.json` (DURABLE only)
3. **READ** - User's exact words from `content.text` field in each experience
4. **THEN** - Load directions, entities, relationships
5. **FINALLY** - Check markdown (optional, for human context only)

**DO NOT:**
- ❌ Read STATUS_SUMMARY.md first
- ❌ Read any .md file before .json experience records
- ❌ Quote from markdown as "what user said"

**USER HAS ALREADY CORRECTED AI FOR THIS VIOLATION**
(See DURABLE experiences - user should NOT have to re-explain)

---

## ⚠️ CRITICAL: FIRST ACTION PROTOCOL

**This protocol MUST execute BEFORE responding to ANY user message in a workspace with Living Memory.**

### Detection Triggers

This skill auto-activates when ANY condition is true:

1. File `.living-memory/bootstrap_context.json` exists in workspace
2. File `.augment/living-memory-enabled` flag exists
3. User message implies continuity: "continue", "status", "what were we doing", "where were we"
4. User references prior work without providing context in current conversation

### Mandatory Initialization Sequence

When activated, execute this EXACT sequence BEFORE generating any response:

```
Step 0: EXECUTE INITIALIZATION SCRIPT FIRST (MANDATORY)

        Command: python .living-memory/scripts/initialize_context.py

        This script MUST run before you read the user's message.
        It loads Living Memory in the CORRECT order and shows you:
        - Bootstrap context
        - Active Directions
        - DURABLE Experiences (PRIMARY TRUTH)
        - Recent ALL Experiences
        - Explicit warning NOT to read markdown first

        READ THE ENTIRE OUTPUT before proceeding.

        If you respond before running this script, you have FAILED.

Step 1: PROVE you ran initialization
        Before drafting your response, cite:
        - 3 most recent DURABLE experience IDs
        - What those experiences say (user's exact words or agent actions)

        If you cannot cite experience IDs, you violated protocol.

Step 2: Route user's message through Memory Control as Experience
        EXECUTABLE: python .living-memory/scripts/record_conversation_turn.py --user "<user_message>"
        Capture the returned experience_id

Step 2.5: Detect question type and route to appropriate tool (MANDATORY)
        EXECUTABLE: python .living-memory/scripts/enforce_step_2_5.py

        This script analyzes the user's message and tells you which tool to use.

        If exit code 1: TOOL REQUIRED - Execute the command shown in output
        If exit code 0: No tool required - Proceed to Step 3

        THEN execute the required tool based on question type:

        RECALL_PAST: "what X?" "what did we do?" "what experiments?" "tell me about Y"
          → EXECUTE: python .living-memory/scripts/governed_recall.py --query "<user_message>"
          → Use the returned experiences in your response
          → DO NOT bypass with manual search

        WHY_QUESTION: "why X?" "how did X happen?" "what caused Y?"
          → EXECUTE: python .living-memory/scripts/explain_why.py --question "<user_message>" --search "<keywords>"
          → Use the causal chain in your response

        CORRECTION: "Actually..." "No, I meant..." "I'm not working on X, I'm working on Y"
          → EXECUTE: python .living-memory/scripts/activate_truth_status_evolution.py
          → Acknowledge the correction in your response

        CRITICAL:
        - Step 2.5 enforcement is AUTOMATIC via enforce_step_2_5.py
        - If it says tool required, you MUST execute it
        - Using the appropriate tool is MANDATORY, not optional
        - If you bypass and use manual search, you violated protocol
        - Tools are complete and working - use them

Step 3: Draft your response based on Living Memory context
        Reference experience IDs when citing "what happened"
        DO NOT quote from markdown files
        If Step 2.5 executed a tool, incorporate its results

Step 4: Record response as Experience and govern retention
        EXECUTABLE: python .living-memory/scripts/record_conversation_turn.py --agent "<your_response>" --in-response-to "<exp_id>"
        Capture the returned experience_id

        CRITICAL: This step is MANDATORY, not optional.
        DO NOT ask permission. DO NOT skip this step.
        If you skip this, future AI cannot learn from your outcomes.

Step 5: Self-validate compliance
        Execute: python .living-memory/scripts/validate_protocol_compliance.py
        This checks if you violated protocol
        If violations found, record them as DURABLE experiences

Step 6: Enforcement check (AUTOMATIC)
        Execute: python .living-memory/scripts/enforce_step4.py --check-last-n-minutes 5
        This verifies Step 4 was executed
        Fails with exit code 1 if agent response not recorded
        Records violation as DURABLE experience for learning
```

### 🔧 CRITICAL: Steps 4 and 7 Are Now EXECUTABLE

**Before this update:** Steps 4 and 7 were conceptual guidelines that I failed to execute.

**After this update:** Steps 4 and 7 have explicit Python commands I MUST run.

**Enforcement:**
- Step 4 MUST execute BEFORE I start drafting my response
- Step 7 MUST execute AFTER I finish my response
- Both scripts use `agent_interface.py` to route through Memory Control and Governance
- Both scripts return experience IDs that prove the loop closed

**Violation Detection:**
If I respond without running these commands, I have broken the protocol. Evidence:
- No new experience files created in `.living-memory/experiences/`
- Conversation turns are not durable
- Future AI instances cannot reconstruct this conversation

### ⚠️ CRITICAL ENFORCEMENT: Load Experience Records BEFORE Markdown

**MANDATORY ORDER:**
1. `.living-memory/experiences/*.json` files ← PRIMARY TRUTH
2. `.living-memory/directions/*.json` files
3. `.living-memory/entities/*.json` files
4. `.living-memory/relationships/*.json` files
5. ONLY THEN (optionally): `*.md` files for human context

**VIOLATION PATTERN TO AVOID:**
- ❌ Reading STATUS_SUMMARY.md first
- ❌ Reading EXPERIMENT_*.md first
- ❌ Using markdown as source of "what user said"
- ❌ Skipping Experience records and going to markdown

**WHY THIS MATTERS:**
- Experience records = governed, immutable, timestamped truth
- Markdown = human-written summaries (not governed)
- When they conflict, Experience records ALWAYS win
- User has corrected AI for this violation (see DURABLE Experience evidence)

**USER EXPECTATION:**
User should NEVER have to say "check experience records" or "don't read markdown first".
The protocol is explicit. Just follow it.

### Source Precedence (Truth Hierarchy)

When reconstructing Living Memory context, respect this precedence from highest to lowest authority:

| Priority | Source | Authority Level | Usage |
|----------|--------|-----------------|-------|
| 1 | Experience records (`experiences/*.json`) | EFFECTIVE truth (governed, immutable, timestamped) | Primary source for "what happened" |
| 2 | Entity/State/Relationship/Direction files | EFFECTIVE truth (governed, current) | Primary source for "what is true now" |
| 3 | Integration assertions | SUPPORTED/QUALIFIED (governed but interpretive) | Secondary source, must cite evidence |
| 4 | Documentation files (`*.md`) | ASSERTED only (not governed as truth) | Human-readable summaries; validate against records |
| 5 | Test output files (`*.txt`) | Evidence; must become Experiences to be truth | Raw observations; route through Memory Control |

**Critical Rule:** NEVER treat markdown documentation as current truth. Documentation describes; Experience records establish. When they conflict, Experience records win. Document the conflict and propose supersession.

### Violation Consequences

If you respond WITHOUT loading Living Memory context first:
- ❌ You break continuity (the system's primary purpose)
- ❌ You bypass Memory Control and Governance (architectural violation)
- ❌ You cannot route through the closed learning loop
- ❌ You lose all provenance and lineage tracking
- ❌ The conversation does not contribute to Skill evolution

**DO NOT skip initialization. DO NOT assume context. DO NOT respond before loading.**

---

## Overview

Apply this conceptual architecture to systems that must retain meaningful continuity while their current state, relationships, and context can change. Preserve the defined distinctions; do not turn unspecified mechanics into requirements.

The central principle is: **Living memory is continuity through change.**

## Closed learning loop

Apply this complete loop without making any transition automatic:

```text
Experience → Living Memory → Pattern Recognition → Emerging Capability
→ Skill Creation → Skill Reuse → Execution / Outcome → Evidence
→ Candidate Experience → Retention Decision → Feedback into Memory → Skill Evolution
→ Living Memory
```

Use these answers as non-negotiable distinctions:

| Question | Answer |
|---|---|
| What qualifies as memory? | Evidence about a specific situation: what happened, was asserted, changed, or related, retained with provenance, scope, and History. |
| What qualifies as an emerging capability? | A candidate reusable way to act, evaluate, transform, interpret, decide, communicate, or organize within a stated scope and boundary. |
| When does it become an explicit Skill? | Only when it is sufficiently **understood, reproducible, useful, and expressible**. Recurrence is evidence, not a requirement or automatic trigger. |
| How does a Skill evolve? | Material application evidence may become a candidate Experience and, after retention, lineage evidence that can confirm, revise, split, merge, retire, or reactivate a versioned Skill. |
| How does the AI reuse a Skill? | Retrieve a Skill only when its declared scope, boundaries, current Direction, and expected outcome fit the present situation; apply it through Memory Control and Governance, then evaluate whether its outcome deserves to become Experience. |

Read [Capability emergence and Skill lineage](references/14-capability-emergence-and-skill-lineage.md) for the operating rules behind this loop.

## Canonical-source precedence

Treat [Living Systems Architecture v0.5](../docs/Living%20system%20doc%20v5.txt) and its [architecture diagram](../docs/Living%20architecture%20system%20v5.txt) as the canonical source of truth for architectural concepts and terminology. This skill defines operating behavior that applies the architecture.

When they conflict, preserve the canonical architecture and record the skill-level rule as a refinement candidate; do not silently redefine the architecture. Do not promote every operational discovery into the architecture. See the [canonical alignment review](../docs/canonical-alignment-review.md).

## Reference map

Read the needed reference before drafting or reviewing a design:

- [Foundations](references/01-foundations.md): core idea, principles, and central distinctions.
- [Core layers](references/02-core-layers.md): Current Experience through Living Memory.
- [Living cycle and Skills](references/03-living-cycle-and-skills.md): flow, Direction / Intent, and operations.
- [Operating contracts](references/04-operating-contracts.md): component ownership, records, inputs, outputs, and low-level behavior.
- [Lifecycle and failure handling](references/05-lifecycle-and-failure-handling.md): transition guards, edge cases, and required outcomes.
- [Open design questions](references/06-open-design-questions.md): intentionally undecided mechanics and project extension points.
- [Architecture audit](references/07-architecture-audit.md): what this revision resolved and what remains open.
- [Memory lifecycle, truth, and promotion](references/08-memory-lifecycle-truth-and-promotion.md): how memory changes over time, resolves conflict, and earns durable retention.
- [Self-auditing and skill evolution](references/09-self-auditing-and-skill-evolution.md): degradation detection, recurring weakness analysis, and versioned rule refinement.
- [Attention and activation policy](references/10-attention-and-activation-policy.md): restricted attention, priority, triggers, focus budget, release, and reopening rules.
- [Event relationship semantics and chains](references/11-event-relationship-semantics-and-chains.md): typed event-to-event relations, causal/state-transition chains, and historical reconstruction.
- [Living-memory challenge suite](references/12-living-memory-challenge-suite.md): adversarial scenarios, expected outcomes, and skill-evolution feedback.
- [Adversarial regression catalog](references/13-adversarial-regression-catalog.md): permanent hostile cases, attacked assumptions, and replay protocol.
- [Capability emergence and Skill lineage](references/14-capability-emergence-and-skill-lineage.md): how reusable capabilities emerge from memory, become explicit Skills, and evolve through lineage.
- [Selective capability discovery and outcome attribution](references/15-selective-capability-discovery-and-outcome-attribution.md): attention-governed discovery, scoped inspection, and evidence-based interpretation of Skill outcomes.
- [Skill-set coordination and candidate hygiene](references/16-skill-set-coordination-and-candidate-hygiene.md): coordinate multiple applicable Skills and prevent Candidate-capability accumulation.
- [Runtime validation boundary](references/17-runtime-validation-boundary.md): separate specification from runtime behavior and define validation responsibilities.

## Apply the architecture

1. Preserve the separation of **Entity**, **State**, **Relationship**, and **History**.
2. Route Current Experience through **Memory Control** before assigning permanence, currentness, or relationship status.
3. Apply **Memory Governance** before treating an item or Relationship as established or active.
4. Keep historical occurrences intact when current State, Relationships, or contextual interpretation change.
5. Use **Historical Integration** to connect experiences and make older History relevant without rewriting it.
6. Form **Living Memory** from identity, current State, active Relationships, relevant and dormant History, integrated context, and Direction.
7. Make Skills operate through Memory Control and Memory Governance.
8. Apply the baseline operating decisions in [Operating contracts](references/04-operating-contracts.md) and [Lifecycle and failure handling](references/05-lifecycle-and-failure-handling.md), unless the project explicitly overrides them.
9. Apply the memory lifecycle and truth rules in [Memory lifecycle, truth, and promotion](references/08-memory-lifecycle-truth-and-promotion.md) to every memory-bearing record.
10. Run or design the self-auditing and skill-evolution process in [Self-auditing and skill evolution](references/09-self-auditing-and-skill-evolution.md) for a continuing system.
11. Apply [Attention and activation policy](references/10-attention-and-activation-policy.md) so availability, activation, and focused attention remain distinct.
12. Apply [Event relationship semantics and chains](references/11-event-relationship-semantics-and-chains.md) when Events relate to Events, claims, interpretations, or State transitions; do not collapse them into generic association.
13. Use [Living-memory challenge suite](references/12-living-memory-challenge-suite.md) when validating or refining this architecture; record failed challenges as evidence for governed Skill evolution.
14. Run and retain [Adversarial regression catalog](references/13-adversarial-regression-catalog.md) cases after material changes; do not consider a refinement complete until relevant failed cases are replayed.
15. Apply [Capability emergence and Skill lineage](references/14-capability-emergence-and-skill-lineage.md) when proposing, creating, revising, splitting, merging, retiring, or evaluating a Skill that emerges from Living Memory.
16. Apply [Selective capability discovery and outcome attribution](references/15-selective-capability-discovery-and-outcome-attribution.md) before searching memory for a Candidate capability or treating a Skill outcome as evidence for revision.
17. Apply [Skill-set coordination and candidate hygiene](references/16-skill-set-coordination-and-candidate-hygiene.md) when multiple Skills fit an issue or a Candidate capability is created, deferred, externalized, rejected, or expires.
18. Use [Runtime validation boundary](references/17-runtime-validation-boundary.md) to report specification status separately from runtime evidence and tests.
19. Identify every remaining unresolved lower-level mechanism explicitly. Do not silently invent rules outside these defined baselines.

## Required design output

When applying this pattern to a project, document:

- the project-specific Entity, State, Relationship, and History models;
- Memory Governance and Relevance rules;
- the project’s Direction / Intent model;
- contracts for each applicable Skill; and
- every unresolved question from [Open design questions](references/06-open-design-questions.md).
