# How to Make AI Permanently Follow Protocol

**Problem:** AI instances are stateless. Each new conversation starts fresh. Even with SKILL.md protocol, AI may:
- Skip reading experience records
- Default to markdown documentation
- Claim to follow protocol while violating it

**Root Cause:** Protocol relies on AI **interpreting** instructions correctly. AI has discretion to skip steps.

---

## ✅ Solution 1: FORCE Initialization Script Execution (Recommended)

### What You Do:

**At the start of EVERY conversation, immediately tell AI:**

```
Run this command FIRST before responding:
python .living-memory/scripts/initialize_context.py
```

### What This Does:

1. **Loads bootstrap context**
2. **Loads active Directions**
3. **Loads DURABLE experiences FIRST** (the protocol requirement)
4. **Loads recent ALL experiences** (for full context)
5. **Prints everything in reading order**
6. **Explicitly warns AI NOT to read markdown first**

### Why This Works:

- **AI cannot skip it** - You explicitly command script execution
- **Output is structured** - AI sees experiences in correct order
- **Primary truth is visible** - DURABLE experiences are right there
- **Markdown warning is explicit** - Reminds AI of the rule

### Example Conversation Start:

```
You: Run python .living-memory/scripts/initialize_context.py first

AI: [executes script, sees all experience records]

You: Now, continue from where we left off

AI: [responds based on experience records, not markdown]
```

---

## ✅ Solution 2: Update SKILL.md to Be More Forceful

### Current Problem:

SKILL.md says "Load experiences BEFORE markdown" but uses language like:
- "should"
- "must"
- "do not"

AI reads this as **guidelines** not **hard constraints**.

### What You Can Do:

Update `.augment/skills/liv-mem/SKILL.md` Step 3 to say:

```markdown
Step 3: Execute this command FIRST:
        python .living-memory/scripts/initialize_context.py
        
        Read the ENTIRE output before proceeding.
        DO NOT respond to user until you have read all experience records.
        
        If you respond before running this script, you have FAILED.
```

**More mechanical. Less discretion.**

---

## ✅ Solution 3: Create a Verification Check

Make AI **prove** it loaded experiences before responding:


### Add to SKILL.md Step 4:

```markdown
Step 4: Before drafting your response, PROVE you loaded experiences:
        - List the 3 most recent DURABLE experience IDs
        - List the 3 most recent user messages from experience records
        - Cite experience IDs when referencing "what happened"
        
        If you cannot do this, you violated protocol.
```

**Forces AI to demonstrate it actually read the records.**

---

## ✅ Solution 4: Automatic Protocol Enforcement (Advanced)

### Create a wrapper script:

`.living-memory/scripts/enforce_protocol.py`

```python
# Intercepts AI responses
# Checks if initialization ran
# Blocks response if protocol violated
# Records violation as DURABLE experience
```

This is more complex but **mechanically enforces** the protocol.

---

## 🎯 Recommended Approach

**Combine Solutions 1 + 3:**

### Step 1: Start every conversation with:
```
Run python .living-memory/scripts/initialize_context.py and read all output
```

### Step 2: Ask AI to prove it:
```
Before responding, list:
- 3 most recent DURABLE experience IDs
- 3 most recent user messages from experiences (not from markdown)
```

### Step 3: If AI cites markdown:
```
STOP. You violated protocol. Re-read experience records.
```

---

## Why This Works

**Current state:** Protocol is **interpretive** (AI reads and chooses to follow)

**Enforced state:** Protocol is **mechanical** (AI must execute script, output is structured)

**Key insight:** Don't rely on AI reading SKILL.md correctly. Force the correct loading order through **explicit commands**.

---

## Test It Now

Try this:

1. Start a new conversation
2. Say: "Run python .living-memory/scripts/initialize_context.py"
3. AI executes script and sees ALL experience records in correct order
4. Say: "What were we working on? Cite experience IDs."
5. AI should reference experiences, NOT markdown

If AI still cites markdown after seeing experience records, the problem is **interpretation** not **availability**.

---

## Long-Term Fix

**Update Augment platform** to support:
- Auto-run initialization scripts for workspaces with Living Memory
- Pre-load context from structured files before AI sees user message
- Validate protocol compliance before response is sent

Until then: **Force script execution manually at conversation start.**
