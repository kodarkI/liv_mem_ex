#!/usr/bin/env python3
"""
Agent Interface: How the AI agent interacts with Living Memory
This is what I (the AI) use to maintain continuity
"""
import json
import sys
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

# Add to path
sys.path.insert(0, str(Path(__file__).parent))

from memory_control import MemoryControl
from memory_governance import MemoryGovernance
from continuity_loader import ContinuityLoader

class AgentMemoryInterface:
    """
    Interface for AI agent to interact with Living Memory
    Implements the closed learning loop from liv-mem/SKILL.md
    """
    
    def __init__(self, memory_root: Optional[Path] = None):
        if memory_root is None:
            # Default to .living-memory/ (parent of core/)
            memory_root = Path(__file__).parent.parent

        self.memory_root = Path(memory_root)
        self.mc = MemoryControl(self.memory_root)
        self.mg = MemoryGovernance(self.memory_root)
        self.loader = ContinuityLoader(self.memory_root)
        
        # Load living memory
        self.living_memory = None
        self.my_entity_id = None
        self.user_entity_id = None
        self.conversation_entity_id = None
        
    def initialize_continuity(self) -> Dict[str, Any]:
        """
        CRITICAL: Call this at conversation start to maintain continuity
        Returns: living_memory_context
        """
        self.living_memory = self.loader.load_living_memory()
        
        # Extract key entity IDs
        bootstrap = self.living_memory["bootstrap"]
        self.my_entity_id = bootstrap["entities"]["agent"]
        self.user_entity_id = bootstrap["entities"]["user"]
        self.conversation_entity_id = bootstrap["entities"]["conversation"]
        
        return self.living_memory
    
    def receive_user_message(self, text: str) -> str:
        """
        Receive user message as Experience
        Returns: experience_id
        """
        exp_id = self.mc.receive_experience(
            source="user",
            source_entity_id=self.user_entity_id,
            content={"type": "message", "text": text}
        )

        # Route through Memory Control
        routing = self.mc.route_experience(exp_id)

        # Execute routed operations
        self._execute_routing_operations(routing, exp_id)

        # Governance decides retention
        experience = self.mc.get_experience(exp_id)
        retention = self.mg.decide_retention(experience)
        self.mc.update_retention(exp_id, retention)

        return exp_id
    
    def record_my_response(self, text: str, in_response_to: str) -> str:
        """
        Record my (agent) response as Experience
        Returns: experience_id
        """
        exp_id = self.mc.receive_experience(
            source="agent",
            source_entity_id=self.my_entity_id,
            content={
                "type": "message",
                "text": text,
                "in_response_to": in_response_to
            }
        )

        # Route and execute operations
        routing = self.mc.route_experience(exp_id)
        self._execute_routing_operations(routing, exp_id)

        # Governance decides retention
        retention = self.mg.decide_retention(self.mc.get_experience(exp_id))
        self.mc.update_retention(exp_id, retention)

        return exp_id
    
    def record_observation(self, observation: str, observation_type: str = "general") -> str:
        """
        Record an observation (e.g., "User seems confused", "Pattern detected")
        Returns: experience_id
        """
        exp_id = self.mc.receive_experience(
            source="agent",
            source_entity_id=self.my_entity_id,
            content={
                "type": "observation",
                "text": observation,
                "observation_type": observation_type
            }
        )
        
        retention = self.mg.decide_retention(self.mc.get_experience(exp_id))
        self.mc.update_retention(exp_id, retention)
        
        return exp_id
    
    def establish_new_direction(self, intent: str, scope: str = "conversation") -> str:
        """
        Establish a new direction (what we're continuing toward)
        Returns: direction_id
        """
        # First create experience
        exp_id = self.mc.receive_experience(
            source="agent",
            source_entity_id=self.my_entity_id,
            content={"type": "assertion", "text": f"New direction: {intent}"}
        )
        
        # Make it durable
        self.mc.update_retention(exp_id, {
            "level": "durable",
            "reason": "Establishes direction",
            "decided_at": datetime.utcnow().isoformat() + 'Z',
            "decided_by": "agent",
            "next_review_at": None
        })
        
        # Create direction
        direction_id = self.mg.establish_direction(
            entity_id=self.conversation_entity_id,
            intent=intent,
            scope=scope,
            source_experience_id=exp_id
        )
        
        return direction_id
    
    def get_current_directions(self) -> List[Dict[str, Any]]:
        """Get all active directions"""
        if not self.living_memory:
            self.initialize_continuity()
        return self.living_memory["directions"]
    
    def get_conversation_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get recent experiences"""
        if not self.living_memory:
            self.initialize_continuity()
        return self.living_memory["recent_experiences"][:limit]
    
    def summarize_context(self) -> str:
        """Generate human-readable summary of current context"""
        if not self.living_memory:
            self.initialize_continuity()
        
        state = self.living_memory["current_state"]
        directions = self.get_current_directions()
        
        summary = f"""
🧠 LIVING MEMORY CONTEXT
========================

Entities: {state['total_entities']} active
Relationships: {state['active_relationships']} active
Active Directions: {state['active_directions']}

Primary Direction:
{directions[0]['intent'] if directions else 'None'}

Entity Breakdown:
{json.dumps(state['entities_by_type'], indent=2)}
"""
        return summary.strip()

    def _execute_routing_operations(self, routing: Dict[str, List[str]], experience_id: str):
        """
        Execute operations routed by Memory Control

        This is the critical bridge: routing detects what needs to happen,
        this method actually executes it through Memory Governance.

        Args:
            routing: Dict with operation lists per category
            experience_id: Source experience for provenance
        """
        # Execute state operations
        for op in routing.get("state_operations", []):
            if op == "state_update":
                self._handle_state_update(experience_id)

        # Execute relationship operations
        for op in routing.get("relationship_operations", []):
            if op == "propose_relationship":
                self._handle_relationship_proposal(experience_id)

        # Execute direction operations
        for op in routing.get("direction_operations", []):
            if op == "establish_intent":
                self._handle_establish_intent(experience_id)

        # Execute entity operations
        for op in routing.get("entity_operations", []):
            if op == "identify_source_entity":
                self._handle_identify_entity(experience_id)

    def _handle_state_update(self, experience_id: str):
        """
        Handle state update operation
        Creates state snapshot when entity state changes
        """
        experience = self.mc.get_experience(experience_id)
        text = experience["content"].get("text", "").lower()
        source_entity = experience.get("source_entity_id")

        # Detect what changed (simple heuristic - can be improved)
        if "working on" in text or "started" in text:
            # Extract what they're working on (very simple extraction)
            # In production, this would be more sophisticated
            fields = {
                "activity": "working",
                "mentioned_in": text[:100]  # Store snippet
            }

            # Create state snapshot
            state_id = self.mg.create_state_snapshot(
                entity_id=source_entity,
                fields=fields,
                source_experiences=[experience_id]
            )
            print(f"    [State] Created snapshot {state_id} for entity {source_entity}")

    def _handle_relationship_proposal(self, experience_id: str):
        """
        Handle relationship proposal operation
        Progresses through POSSIBLE → CANDIDATE → SUPPORTED → ESTABLISHED
        """
        experience = self.mc.get_experience(experience_id)
        text = experience["content"].get("text", "").lower()
        source_entity = experience.get("source_entity_id")

        # Simple relationship extraction (can be improved)
        # Look for patterns like "X works on Y", "X depends on Y"
        if "works on" in text or "working on" in text:
            # Find or create project entity (simplified)
            # In production, this would do proper entity resolution
            predicate = "works_on"
            # For now, use conversation as object (simplified)
            object_entity = self.conversation_entity_id

            # Propose relationship
            rel_id = self.mg.propose_relationship(
                subject_id=source_entity,
                predicate=predicate,
                object_id=object_entity,
                origin_experience_id=experience_id
            )

            # Apply governance to advance it
            result = self.mg.apply_relationship_governance(rel_id, experience_id)
            print(f"    [Relationship] {predicate}: {result['from_status']} -> {result['to_status']}")

    def _handle_establish_intent(self, experience_id: str):
        """
        Handle direction/intent establishment
        """
        experience = self.mc.get_experience(experience_id)
        text = experience["content"].get("text", "")

        # Extract intent (simplified)
        if any(word in text.lower() for word in ["build", "create", "implement", "fix"]):
            # This would create/update a Direction record
            # For now, just log it
            print(f"    [Direction] Detected intent in experience {experience_id}")

    def _handle_identify_entity(self, experience_id: str):
        """
        Handle entity identification
        """
        experience = self.mc.get_experience(experience_id)
        # This would do entity resolution
        # For now, just log it
        print(f"    [Entity] Identity operation for experience {experience_id}")

if __name__ == "__main__":
    # Test the interface
    agent = AgentMemoryInterface()
    context = agent.initialize_continuity()
    print(agent.summarize_context())
