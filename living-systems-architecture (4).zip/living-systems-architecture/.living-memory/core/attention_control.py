#!/usr/bin/env python3
"""
Attention Control Module

Manages focus budget, attention allocation, and priority assessment
Per reference/10: Attention and activation policy
"""
import json
from pathlib import Path
from typing import Dict, List, Optional, Set
from datetime import datetime, timedelta


class AttentionControl:
    """
    Separate retention/activation from attention/focus
    Per ref 10: "Retain broadly, activate selectively, focus intensely only when warranted"
    """

    # Attention States (ref 10, lines 26-34)
    ATTENTION_STATES = {
        "NOT_ATTENDING",  # Retained/active but no deliberate monitoring
        "MONITOR",        # Watching for defined trigger
        "QUEUED",         # Merits work, waiting for capacity
        "FOCUSED",        # Currently receiving bounded work
        "URGENT"          # Requires immediate resolution
    }

    # Attention Priorities (ref 10, lines 38-48)
    ATTENTION_PRIORITIES = {
        "URGENT",   # Affects current State/Relationship, boundary violation
        "HIGH",     # Affects current State, active Relationship, committed Direction
        "NORMAL",   # Explains context, qualified trigger, planned review
        "LOW"       # Old, unrelated, already resolved
    }

    def __init__(self, memory_root: Path):
        self.memory_root = Path(memory_root)
        self.attention_dir = self.memory_root / "data" / "attention_allocations"
        self.attention_dir.mkdir(parents=True, exist_ok=True)

        # Focus budget per scope (ref 10, lines 66-79)
        # Baseline: 1 FOCUSED per scope, 1 URGENT per scope
        self.focus_budgets = {}
        self.default_budget = {
            "FOCUSED": 1,
            "URGENT": 1
        }

    def allocate_attention(self, target_id: str, target_type: str,
                          state: str, priority: str,
                          reason: str, triggering_event_id: str,
                          scope: str = "default",
                          release_condition: Optional[str] = None) -> Optional[str]:
        """
        Allocate attention to a target

        Per ref 10, lines 35:
        "An Attention allocation must name the target, scope, state, priority reason,
         triggering event, allocation time, and release or review condition."

        Args:
            target_id: What to attend to (experience, state, relationship, etc.)
            target_type: Type of target
            state: One of ATTENTION_STATES
            priority: One of ATTENTION_PRIORITIES
            reason: Why attention is needed
            triggering_event_id: What triggered this allocation
            scope: Scope for budget tracking
            release_condition: When to release attention

        Returns:
            allocation_id if successful, None if budget exceeded
        """
        import uuid

        # Validate state and priority
        if state not in self.ATTENTION_STATES:
            print(f"[ERROR] Invalid attention state: {state}")
            return None

        if priority not in self.ATTENTION_PRIORITIES:
            print(f"[ERROR] Invalid attention priority: {priority}")
            return None

        # Check focus budget (ref 10, lines 66-79)
        if state in ["FOCUSED", "URGENT"]:
            budget = self.focus_budgets.get(scope, self.default_budget)
            current = self._count_current_allocations(scope, state)

            if current >= budget.get(state, 1):
                # Budget exceeded - queue instead
                if state == "FOCUSED":
                    print(f"[BUDGET] Focus budget exceeded in scope '{scope}', queuing instead")
                    state = "QUEUED"
                elif state == "URGENT" and priority != "URGENT":
                    # Only true URGENT priority can interrupt
                    print(f"[BUDGET] URGENT budget exceeded, queuing instead")
                    state = "QUEUED"

        allocation_id = str(uuid.uuid4())

        allocation = {
            "id": allocation_id,
            "target_id": target_id,
            "target_type": target_type,
            "state": state,
            "priority": priority,
            "reason": reason,
            "triggering_event": triggering_event_id,
            "scope": scope,
            "allocated_at": datetime.utcnow().isoformat() + 'Z',
            "release_condition": release_condition,
            "released_at": None,
            "active": True
        }

        allocation_file = self.attention_dir / f"{allocation_id}.json"
        with open(allocation_file, 'w') as f:
            json.dump(allocation, f, indent=2)

        return allocation_id

    def _count_current_allocations(self, scope: str, state: str) -> int:
        """Count active allocations in given scope and state"""
        count = 0
        for alloc_file in self.attention_dir.glob("*.json"):
            try:
                with open(alloc_file, 'r') as f:
                    alloc = json.load(f)

                if (alloc.get("scope") == scope and
                    alloc.get("state") == state and
                    alloc.get("active") == True):
                    count += 1
            except:
                continue

        return count


    def release_attention(self, allocation_id: str, reason: str) -> bool:
        """
        Release attention when purpose is met

        Per ref 10, lines 81-94:
        "Release attention when its recorded purpose is met. A memory does not
         remain attended merely because it was once important."

        Args:
            allocation_id: Allocation to release
            reason: Why attention is being released

        Returns:
            True if released, False if not found
        """
        allocation_file = self.attention_dir / f"{allocation_id}.json"

        if not allocation_file.exists():
            return False

        with open(allocation_file, 'r') as f:
            allocation = json.load(f)

        allocation["active"] = False
        allocation["released_at"] = datetime.utcnow().isoformat() + 'Z'
        allocation["release_reason"] = reason

        with open(allocation_file, 'w') as f:
            json.dump(allocation, f, indent=2)

        return True

    def assess_priority(self, target_id: str, target_type: str,
                       affects_current_state: bool = False,
                       affects_active_relationship: bool = False,
                       affects_critical_direction: bool = False,
                       is_contested: bool = False,
                       is_explicit_request: bool = False,
                       is_boundary_violation: bool = False) -> str:
        """
        Assess attention priority based on impact

        Per ref 10, lines 38-48:
        Priority levels based on what is affected

        Returns:
            URGENT, HIGH, NORMAL, or LOW
        """
        # URGENT (ref 10, line 43)
        if is_explicit_request and is_contested:
            return "URGENT"

        if is_boundary_violation:
            return "URGENT"

        if is_contested and (affects_current_state or affects_active_relationship):
            return "URGENT"

        if affects_critical_direction and is_contested:
            return "URGENT"

        # HIGH (ref 10, line 44)
        if affects_current_state or affects_active_relationship:
            return "HIGH"

        if affects_critical_direction:
            return "HIGH"

        # NORMAL (ref 10, line 46)
        if is_explicit_request:
            return "NORMAL"

        # LOW (ref 10, line 47)
        return "LOW"

    def evaluate_triggers(self, event_id: str, event_type: str,
                         related_targets: List[Dict]) -> List[Dict]:
        """
        Evaluate activation/reopening triggers

        Per ref 10, lines 50-64:
        Triggers make re-evaluation permissible but don't automatically allocate focus

        Returns:
            List of recommended attention allocations
        """
        recommendations = []

        # Per ref 10, line 56: New evidence linked to record
        if event_type == "new_evidence":
            for target in related_targets:
                recommendations.append({
                    "target_id": target["id"],
                    "target_type": target["type"],
                    "recommended_state": "MONITOR",
                    "recommended_priority": "NORMAL",
                    "reason": "New evidence linked to record",
                    "trigger": "new_evidence"
                })

        # Per ref 10, line 57: Contradiction with effective claim
        if event_type == "contradiction":
            for target in related_targets:
                if target.get("is_effective"):
                    priority = "URGENT" if target.get("affects_current_context") else "NORMAL"
                    state = "URGENT" if priority == "URGENT" else "QUEUED"

                    recommendations.append({
                        "target_id": target["id"],
                        "target_type": target["type"],
                        "recommended_state": state,
                        "recommended_priority": priority,
                        "reason": "Contradiction with effective claim",
                        "trigger": "contradiction"
                    })

        # Per ref 10, line 59: State change
        if event_type == "state_change":
            for target in related_targets:
                recommendations.append({
                    "target_id": target["id"],
                    "target_type": target["type"],
                    "recommended_state": "MONITOR",
                    "recommended_priority": "NORMAL",
                    "reason": "Re-evaluate due to state change",
                    "trigger": "state_change"
                })

        # Per ref 10, line 61: User explicitly revisits
        if event_type == "user_request":
            for target in related_targets:
                recommendations.append({
                    "target_id": target["id"],
                    "target_type": target["type"],
                    "recommended_state": "FOCUSED",
                    "recommended_priority": "NORMAL",
                    "reason": "User explicitly requested",
                    "trigger": "user_request"
                })

        return recommendations

    def get_active_allocations(self, scope: Optional[str] = None,
                               state_filter: Optional[str] = None) -> List[Dict]:
        """Get all active attention allocations"""
        allocations = []

        for alloc_file in self.attention_dir.glob("*.json"):
            try:
                with open(alloc_file, 'r') as f:
                    alloc = json.load(f)

                if not alloc.get("active"):
                    continue

                if scope and alloc.get("scope") != scope:
                    continue

                if state_filter and alloc.get("state") != state_filter:
                    continue

                allocations.append(alloc)
            except:
                continue

        return allocations

    def set_focus_budget(self, scope: str, focused_limit: int = 1, urgent_limit: int = 1):
        """
        Set focus budget for a scope

        Per ref 10, lines 66-70:
        "Baseline: one FOCUSED allocation per scope and one interrupting URGENT
         allocation per scope."
        """
        self.focus_budgets[scope] = {
            "FOCUSED": focused_limit,
            "URGENT": urgent_limit
        }
