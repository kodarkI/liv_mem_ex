#!/usr/bin/env python3
"""
Memory Governance: Protects coherence by controlling what becomes established truth
Reference: .augment/skills/liv-mem/references/02-core-layers.md
          .augment/skills/liv-mem/references/08-memory-lifecycle-truth-and-promotion.md
"""
import json
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional

class MemoryGovernance:
    """
    Controls progression: POSSIBLE → CANDIDATE → SUPPORTED → ESTABLISHED → ACTIVE/DORMANT/HISTORICAL
    """

    def __init__(self, memory_root: Path):
        self.memory_root = Path(memory_root)
        self.entities_dir = self.memory_root / "data" / "entities"
        self.states_dir = self.memory_root / "data" / "states"
        self.relationships_dir = self.memory_root / "data" / "relationships"
        self.directions_dir = self.memory_root / "data" / "directions"
        self.context_dir = self.memory_root / "data" / "context_memberships"

        for d in [self.entities_dir, self.states_dir, self.relationships_dir,
                  self.directions_dir, self.context_dir]:
            d.mkdir(parents=True, exist_ok=True)

    def decide_retention(self, experience: Dict[str, Any], current_retention: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Decide retention level per reference/08-memory-lifecycle-truth-and-promotion.md

        Correct Living Memory Retention Policy:

        EPHEMERAL: Immediate processing only (questions, acknowledgments, meta-conversation)
        RETAINED: May matter later (recent context, observations, routed but not establishing)
        DURABLE: Establishes identity/state/relationship/direction/origin/transition
        ARCHIVED: Outside ordinary retrieval (aged out, dormant, preserved)

        Recency makes things ACCESSIBLE (RETAINED), not automatically DURABLE.

        Args:
            experience: Experience to evaluate
            current_retention: Previous retention decision (for supersession tracking)

        Returns retention decision with optional supersession link
        """
        content_type = experience["content"].get("type")
        routed_to = experience.get("routed_to", [])
        source = experience.get("source", "unknown")
        experience_id = experience.get("id")

        # Step 1: Check if should be ARCHIVED (aged out of retention window)
        # This must check FIRST, before recency window extends retention
        if current_retention and current_retention.get("level") == "retained":
            # Check if next_review has passed
            next_review = current_retention.get("next_review_at")
            if next_review:
                try:
                    # Parse ISO datetime string
                    if next_review.endswith('Z'):
                        next_review = next_review[:-1]  # Remove Z
                    review_time = datetime.fromisoformat(next_review)

                    if review_time < datetime.utcnow():
                        # Aged out - move to ARCHIVED
                        decision = {
                            "level": "archived",
                            "reason": "Aged out of retention window; preserved but not ordinarily retrieved",
                            "decided_at": datetime.utcnow().isoformat() + 'Z',
                            "decided_by": "memory_governance",
                            "next_review_at": None
                        }
                        # Track supersession
                        if current_retention.get("decision_id"):
                            decision["supersedes"] = current_retention["decision_id"]
                        return decision
                except Exception as e:
                    pass  # If parsing fails, skip archive check

        # Step 2: Check if establishes DURABLE criteria (highest priority for new decisions)
        # DURABLE = establishes identity, state, relationship, direction, origin, or important transition
        durable_operations = ["identify_source_entity", "establish_intent",
                             "propose_relationship", "state_update",
                             "record_transition", "record_origin"]

        if any(op in routed_to for op in durable_operations):
            return {
                "level": "durable",
                "reason": "Establishes identity, state, relationship, or direction",
                "decided_at": datetime.utcnow().isoformat() + 'Z',
                "decided_by": "memory_governance",
                "next_review_at": None  # Durable doesn't auto-expire
            }

        # Step 2.5: Content-based DURABLE evaluation (per ref 08 line 82)
        # Evaluate actual content to detect important information that should be preserved
        content_eval = self._evaluate_content_importance(experience)
        if content_eval["is_durable"]:
            return {
                "level": "durable",
                "reason": content_eval["reason"],
                "decided_at": datetime.utcnow().isoformat() + 'Z',
                "decided_by": "memory_governance",
                "next_review_at": None
            }

        # Step 3: Check recency window (makes things RETAINED, not DURABLE)
        # Recent = accessible for immediate context, but not necessarily permanent
        is_recent = self._is_within_recency_window(experience_id, source)

        if is_recent:
            return {
                "level": "retained",
                "reason": "Within recency window (accessible for recent context)",
                "decided_at": datetime.utcnow().isoformat() + 'Z',
                "decided_by": "memory_governance",
                "next_review_at": (datetime.utcnow() + timedelta(hours=24)).isoformat() + 'Z'
            }

        # Step 4: Check if routed to any memory operations (RETAINED)
        if routed_to:
            return {
                "level": "retained",
                "reason": "Routed to memory operations; may matter later",
                "decided_at": datetime.utcnow().isoformat() + 'Z',
                "decided_by": "memory_governance",
                "next_review_at": (datetime.utcnow() + timedelta(days=7)).isoformat() + 'Z'
            }

        # Step 5: Default to EPHEMERAL (immediate processing only)
        return {
            "level": "ephemeral",
            "reason": "Received material with no established continuing value",
            "decided_at": datetime.utcnow().isoformat() + 'Z',
            "decided_by": "memory_governance",
            "next_review_at": (datetime.utcnow() + timedelta(hours=1)).isoformat() + 'Z'
        }

    def _evaluate_content_importance(self, experience: Dict[str, Any]) -> Dict[str, Any]:
        """
        Content-based evaluation to detect DURABLE-worthy information.

        Per ref 08 line 82, promote to DURABLE when:
        - Establishes/changes identity, State, or Relationship
        - Preserves origin or important transition
        - Necessary to explain an already durable memory
        - Remains relevant across repeated evaluations
        - Project policy marks as required

        This method detects content that meets these criteria even if not routed
        to explicit durable operations.

        Args:
            experience: Experience to evaluate

        Returns:
            Dict with 'is_durable' (bool) and 'reason' (str)
        """
        content = experience.get("content", {})
        text = content.get("text", "").lower()
        source = experience.get("source", "")
        content_type = content.get("type", "")

        # Criterion 1: User shares detailed knowledge/information
        # Patterns: "experiment", "feature", "design", "architecture", "test", detailed descriptions
        if source == "user":
            # High-value knowledge sharing indicators
            knowledge_indicators = [
                ("experiment", "detailed experiment description or test case"),
                ("feature", "feature specification or requirements"),
                ("design", "design decision or architectural pattern"),
                ("architecture", "architectural concept or structure"),
                ("challenge", "challenge or test scenario"),
                ("test", "test definition or validation criteria"),
                ("requirement", "requirement or specification"),
                ("specification", "detailed specification"),
                ("contract", "contract or interface definition"),
            ]

            for indicator, reason_text in knowledge_indicators:
                if indicator in text:
                    # Detect if it's a substantive description (not just mention)
                    # Look for length, detail markers, or multiple sentences
                    if len(text) > 100 or any(marker in text for marker in [":", "•", "-", "1.", "2.", "•"]):
                        return {
                            "is_durable": True,
                            "reason": f"User shared {reason_text} - necessary to explain context"
                        }

            # Criterion 2: User provides corrections, clarifications, or important context
            correction_indicators = ["actually", "correction", "fix", "wrong", "should be", "meant to", "clarify"]
            if any(ind in text for ind in correction_indicators):
                return {
                    "is_durable": True,
                    "reason": "User correction or clarification - establishes accurate state"
                }

            # Criterion 3: User shares lists or multiple items
            if text.count("\n") > 2 or (("1." in text or "2." in text) and len(text) > 50):
                return {
                    "is_durable": True,
                    "reason": "User shared structured information - preserves important context"
                }

        # Criterion 4: Agent records important outcomes, implementations, or discoveries
        if source == "agent":
            outcome_indicators = [
                "implemented", "completed", "fixed", "discovered", "violation",
                "critical", "architecture", "compliance", "test pass", "test fail"
            ]
            if any(ind in text for ind in outcome_indicators) and len(text) > 100:
                return {
                    "is_durable": True,
                    "reason": "Important outcome or implementation record - establishes transition"
                }

        # Criterion 5: Explicit test execution records
        if content_type == "test_execution":
            return {
                "is_durable": True,
                "reason": "Test execution record - establishes validation evidence"
            }

        # Criterion 6: Protocol violations or corrections
        if content_type == "protocol_violation" or "violation" in text:
            return {
                "is_durable": True,
                "reason": "Protocol violation or system issue - necessary for improvement"
            }

        # Default: not durable based on content
        return {
            "is_durable": False,
            "reason": "No content-based durable criteria detected"
        }

    def _is_within_recency_window(self, experience_id: str, source: str) -> bool:
        """
        Check if experience is within recency window for its source type.

        Recency window:
        - Last 5 user messages
        - Last 5 agent responses
        - Last 10 total experiences

        Args:
            experience_id: ID of experience being checked
            source: Source type (user/agent/system)

        Returns: True if within recency window
        """
        experiences_dir = self.memory_root / "data" / "experiences"
        if not experiences_dir.exists():
            return False

        # Load all experiences and sort by received_at timestamp
        all_experiences = []
        for exp_file in experiences_dir.glob("*.json"):
            try:
                with open(exp_file, 'r', encoding='utf-8') as f:
                    exp_data = json.load(f)
                    all_experiences.append(exp_data)
            except:
                continue

        # Sort by received_at timestamp (most recent first)
        all_experiences.sort(key=lambda e: e.get("received_at", ""), reverse=True)

        source_count = 0
        total_count = 0

        for exp_data in all_experiences[:20]:  # Check last 20 max
            total_count += 1

            # Check if this is the experience we're deciding on
            if exp_data.get("id") == experience_id:
                # Is it within top 10 total?
                if total_count <= 10:
                    return True
                # Is it within top 5 of its source type?
                if exp_data.get("source") == source and source_count < 5:
                    return True
                return False

            # Count experiences of the same source type
            if exp_data.get("source") == source:
                source_count += 1

        return False

    def propose_entity(self, entity_type: str, identity_assertion: str,
                      source_experience_id: str, check_duplicates: bool = True) -> str:
        """
        Propose new entity (not automatic - requires governance)

        Args:
            entity_type: Type of entity (person, agent, project, etc.)
            identity_assertion: Textual assertion of identity
            source_experience_id: Experience that asserts this identity
            check_duplicates: If True, checks for existing similar entities

        Returns: entity_id (either new or existing if duplicate detected)
        """
        # Step 1: Check for duplicates (if enabled)
        if check_duplicates:
            duplicate_id = self._find_duplicate_entity(entity_type, identity_assertion)
            if duplicate_id:
                # Merge into existing entity by adding identity assertion
                self._add_identity_assertion(duplicate_id, identity_assertion, source_experience_id)
                return duplicate_id

        # Step 2: Create new entity
        entity_id = str(uuid.uuid4())
        created_at = datetime.utcnow().isoformat() + 'Z'

        entity = {
            "id": entity_id,
            "type": entity_type,
            "identity_assertions": [{
                "assertion": identity_assertion,
                "source": source_experience_id,
                "asserted_at": created_at
            }],
            "lifecycle_status": "active",
            "created_at": created_at
        }

        entity_file = self.entities_dir / f"{entity_id}.json"
        with open(entity_file, 'w') as f:
            json.dump(entity, f, indent=2)

        return entity_id

    def _find_duplicate_entity(self, entity_type: str, identity_assertion: str) -> Optional[str]:
        """
        Find existing entity that matches type and identity

        Simple heuristics:
        - Same type
        - Identity assertion has high similarity (shared words + synonyms)

        Returns: entity_id if duplicate found, None otherwise
        """
        import string

        # Common abbreviations/synonyms
        expansions = {
            "ml": ["ml", "machine", "learning"],
            "ai": ["ai", "artificial", "intelligence"],
            "dev": ["dev", "developer", "development"],
            "eng": ["eng", "engineer", "engineering"]
        }

        # Normalize and expand assertion
        stop_words = {"the", "a", "an", "is", "are", "for", "of", "and", "or", "in", "on", "at", "to", "who", "works"}

        def expand_words(text):
            """Expand words with synonyms"""
            words = set()
            for w in text.split():
                w_clean = w.strip(string.punctuation).lower()
                if w_clean in stop_words or len(w_clean) <= 2:
                    continue
                # Check if it's an abbreviation
                if w_clean in expansions:
                    words.update(expansions[w_clean])
                else:
                    words.add(w_clean)
                    # Check if any word starts with this
                    for abbr, full_words in expansions.items():
                        if w_clean in full_words:
                            words.add(abbr)
            return words

        new_words = expand_words(identity_assertion)

        # Check all entities of same type
        for entity_file in self.entities_dir.glob("*.json"):
            try:
                with open(entity_file, 'r', encoding='utf-8') as f:
                    entity = json.load(f)

                # Same type and active?
                if entity.get("type") != entity_type:
                    continue
                if entity.get("lifecycle_status") != "active":
                    continue

                # Check all identity assertions
                for assertion_record in entity.get("identity_assertions", []):
                    existing_assertion = assertion_record.get("assertion", "")
                    existing_words = expand_words(existing_assertion)

                    # Calculate similarity
                    if new_words and existing_words:
                        shared = new_words.intersection(existing_words)
                        similarity = len(shared) / max(len(new_words), len(existing_words))

                        # Lower threshold (>40%) with expansion
                        if similarity > 0.4:
                            return entity.get("id")
            except:
                continue

        return None

    def _add_identity_assertion(self, entity_id: str, identity_assertion: str, source_experience_id: str):
        """Add new identity assertion to existing entity"""
        entity_file = self.entities_dir / f"{entity_id}.json"
        with open(entity_file, 'r', encoding='utf-8') as f:
            entity = json.load(f)

        # Add new assertion
        entity["identity_assertions"].append({
            "assertion": identity_assertion,
            "source": source_experience_id,
            "asserted_at": datetime.utcnow().isoformat() + 'Z'
        })

        with open(entity_file, 'w', encoding='utf-8') as f:
            json.dump(entity, f, indent=2)

    def propose_relationship(self, subject_id: str, predicate: str,
                           object_id: str, origin_experience_id: str) -> str:
        """
        Propose relationship - starts at POSSIBLE, must progress through governance
        Returns: relationship_id
        """
        relationship_id = str(uuid.uuid4())
        created_at = datetime.utcnow().isoformat() + 'Z'

        relationship = {
            "id": relationship_id,
            "subject": subject_id,
            "predicate": predicate,
            "object": object_id,
            "status": "possible",  # Not automatic!
            "origin": origin_experience_id,
            "evidence": [origin_experience_id],
            "created_at": created_at
        }

        rel_file = self.relationships_dir / f"{relationship_id}.json"
        with open(rel_file, 'w') as f:
            json.dump(relationship, f, indent=2)

        return relationship_id

    def advance_relationship(self, relationship_id: str,
                           new_status: str, evidence_experience_id: str):
        """
        Advance relationship through governance pipeline
        possible → candidate → supported → established → active
        """
        valid_transitions = {
            "possible": ["candidate", "invalidated"],
            "candidate": ["supported", "invalidated"],
            "supported": ["established", "invalidated"],
            "established": ["active", "dormant"],
            "active": ["dormant", "historical", "invalidated"],
            "dormant": ["active", "historical"]
        }

        rel_file = self.relationships_dir / f"{relationship_id}.json"
        with open(rel_file, 'r') as f:
            relationship = json.load(f)

        current_status = relationship["status"]

        if new_status not in valid_transitions.get(current_status, []):
            raise ValueError(f"Invalid transition: {current_status} → {new_status}")

        relationship["status"] = new_status
        relationship["status_changed_at"] = datetime.utcnow().isoformat() + 'Z'
        if evidence_experience_id not in relationship["evidence"]:
            relationship["evidence"].append(evidence_experience_id)

        with open(rel_file, 'w') as f:
            json.dump(relationship, f, indent=2)

    def evaluate_relationship_advancement(self, relationship_id: str) -> dict:
        """
        Evaluate if relationship should advance based on evidence
        Returns: {"should_advance": bool, "to_status": str, "reason": str}
        """
        rel_file = self.relationships_dir / f"{relationship_id}.json"
        with open(rel_file, 'r') as f:
            relationship = json.load(f)

        current_status = relationship["status"]
        evidence_count = len(relationship.get("evidence", []))

        # Governance rules for advancement
        if current_status == "possible":
            if evidence_count >= 1:  # At least one supporting experience
                return {
                    "should_advance": True,
                    "to_status": "candidate",
                    "reason": f"Initial evidence present ({evidence_count} experience(s))"
                }

        elif current_status == "candidate":
            if evidence_count >= 2:  # Multiple supporting experiences
                return {
                    "should_advance": True,
                    "to_status": "supported",
                    "reason": f"Multiple evidence points ({evidence_count} experiences)"
                }

        elif current_status == "supported":
            if evidence_count >= 3:  # Consistent pattern
                return {
                    "should_advance": True,
                    "to_status": "established",
                    "reason": f"Consistent pattern ({evidence_count} experiences)"
                }

        elif current_status == "established":
            # ESTABLISHED → DORMANT (default: remembered but not currently active)
            # Per ref 02 lines 65-69: "DORMANT: remembered but not currently active"
            return {
                "should_advance": True,
                "to_status": "dormant",
                "reason": "Established relationships become dormant (remembered but not active) until relevance activates them"
            }

        elif current_status == "dormant":
            # DORMANT → ACTIVE requires relevance evaluation
            # This should be called by context membership / relevance system
            return {
                "should_advance": False,
                "to_status": current_status,
                "reason": "Dormant relationships require relevance evaluation for activation"
            }

        return {
            "should_advance": False,
            "to_status": current_status,
            "reason": f"Insufficient evidence (need more than {evidence_count})"
        }

    def apply_relationship_governance(self, relationship_id: str, new_evidence_id: str = None):
        """
        Apply governance: add evidence and auto-advance if criteria met
        Returns: {"advanced": bool, "from_status": str, "to_status": str}
        """
        rel_file = self.relationships_dir / f"{relationship_id}.json"
        with open(rel_file, 'r') as f:
            relationship = json.load(f)

        original_status = relationship["status"]

        # Add new evidence if provided
        if new_evidence_id and new_evidence_id not in relationship.get("evidence", []):
            relationship["evidence"].append(new_evidence_id)
            with open(rel_file, 'w') as f:
                json.dump(relationship, f, indent=2)

        # Evaluate advancement
        evaluation = self.evaluate_relationship_advancement(relationship_id)

        if evaluation["should_advance"]:
            self.advance_relationship(
                relationship_id,
                evaluation["to_status"],
                new_evidence_id or relationship["evidence"][-1]
            )
            return {
                "advanced": True,
                "from_status": original_status,
                "to_status": evaluation["to_status"],
                "reason": evaluation["reason"]
            }
        else:
            return {
                "advanced": False,
                "from_status": original_status,
                "to_status": original_status,
                "reason": evaluation["reason"]
            }

    def establish_direction(self, entity_id: str, intent: str,
                          scope: str, source_experience_id: str) -> str:
        """
        Establish Direction - what entity is continuing toward
        Returns: direction_id
        """
        direction_id = str(uuid.uuid4())
        created_at = datetime.utcnow().isoformat() + 'Z'

        direction = {
            "id": direction_id,
            "entity_id": entity_id,
            "intent": intent,
            "scope": scope,
            "status": "active",
            "created_at": created_at,
            "source_experience": source_experience_id,
            "evidence": [source_experience_id],
            "milestones": []
        }

        dir_file = self.directions_dir / f"{direction_id}.json"
        with open(dir_file, 'w') as f:
            json.dump(direction, f, indent=2)

        return direction_id

    def create_state_snapshot(self, entity_id: str, fields: dict,
                             source_experiences: list, effective_at: str = None) -> str:
        """
        Create state snapshot for entity
        Returns: state_snapshot_id
        """
        state_id = str(uuid.uuid4())
        snapshot_at = datetime.utcnow().isoformat() + 'Z'
        effective_at = effective_at or snapshot_at

        # Check for previous current state
        previous_state_id = self._get_current_state(entity_id)

        state_snapshot = {
            "id": state_id,
            "entity_id": entity_id,
            "fields": fields,
            "effective_at": effective_at,
            "snapshot_at": snapshot_at,
            "source_experiences": source_experiences,
            "status": "current"
        }

        if previous_state_id:
            state_snapshot["supersedes"] = previous_state_id

        # Write new state
        state_file = self.states_dir / f"{state_id}.json"
        with open(state_file, 'w') as f:
            json.dump(state_snapshot, f, indent=2)

        # Supersede previous state if exists
        if previous_state_id:
            self._supersede_state(previous_state_id, state_id)

        return state_id

    def _get_current_state(self, entity_id: str):
        """Find current state snapshot for entity"""
        for state_file in self.states_dir.glob("*.json"):
            with open(state_file, 'r') as f:
                state = json.load(f)
                if state["entity_id"] == entity_id and state.get("status") == "current":
                    return state["id"]
        return None

    def _supersede_state(self, old_state_id: str, new_state_id: str):
        """Mark old state as historical and link to new state"""
        old_state_file = self.states_dir / f"{old_state_id}.json"
        with open(old_state_file, 'r') as f:
            old_state = json.load(f)

        old_state["status"] = "historical"
        old_state["superseded_by"] = new_state_id
        old_state["superseded_at"] = datetime.utcnow().isoformat() + 'Z'

        with open(old_state_file, 'w') as f:
            json.dump(old_state, f, indent=2)

    def get_state_history(self, entity_id: str) -> list:
        """
        Get full state history for entity (current → historical chain)
        Returns list ordered newest to oldest
        """
        states = []
        for state_file in self.states_dir.glob("*.json"):
            with open(state_file, 'r') as f:
                state = json.load(f)
                if state["entity_id"] == entity_id:
                    states.append(state)

        # Sort by snapshot_at descending
        states.sort(key=lambda s: s["snapshot_at"], reverse=True)
        return states


    # ============================================================================
    # Context Membership and Relevance (Per ref 04, lines 147-155)
    # ============================================================================

    def evaluate_relevance(self, relationship_id: str, current_direction_ids: List[str]) -> Dict[str, Any]:
        """
        Evaluate if a DORMANT relationship is relevant to current context/direction

        Per ref 02 lines 65-69:
        "Do not treat dormant memory as forgotten.
         Allow it to become active when a new Relationship makes it relevant."

        Returns: {"is_relevant": bool, "reason": str}
        """
        rel_file = self.relationships_dir / f"{relationship_id}.json"
        with open(rel_file, 'r') as f:
            relationship = json.load(f)

        # Load current directions
        current_directions = []
        for direction_id in current_direction_ids:
            dir_file = self.directions_dir / f"{direction_id}.json"
            if dir_file.exists():
                with open(dir_file, 'r') as f:
                    current_directions.append(json.load(f))

        # Relevance heuristics
        subject_id = relationship.get("subject")
        object_id = relationship.get("object")

        # Check if relationship involves entities in current directions
        for direction in current_directions:
            if direction.get("status") != "active":
                continue

            direction_entity = direction.get("entity_id")

            if subject_id == direction_entity or object_id == direction_entity:
                return {
                    "is_relevant": True,
                    "reason": f"Relationship involves entity {direction_entity} active in current direction"
                }

        return {
            "is_relevant": False,
            "reason": "Not referenced in current context or direction"
        }

    def evaluate_relevance_for_recall(self, experience: Dict, query_context: Dict,
                                     current_directions: List[str] = None) -> Dict[str, Any]:
        """
        Evaluate if historical experience is relevant to current recall request

        Per ref 03 lines 11:
        "Relevance can come from current Entity, current State, active Relationship,
         recent change, historical origin, current Direction, previously established
         context, or a newly discovered Relationship."

        Args:
            experience: Experience record to evaluate
            query_context: Current context requiring recall (type, text, entities, topics)
            current_directions: Active direction IDs

        Returns: {
            "is_relevant": bool,
            "relevance_score": float,  # 0.0-1.0
            "reason": str
        }
        """
        score = 0.0
        reasons = []

        # Extract query terms
        query_text = query_context.get('text', '').lower()
        query_entities = query_context.get('entities', [])
        query_topics = query_context.get('topics', [])

        # Get experience content
        content = experience.get('content', {})
        exp_text = content.get('text', content.get('observation_type', '')).lower()

        # 1. Check topic/keyword matching (basic relevance)
        for topic in query_topics:
            if topic.lower() in exp_text:
                score += 0.3
                reasons.append(f"Matches topic '{topic}'")
                break

        # 2. Check entity matching
        exp_source_entity = experience.get('source_entity_id')
        if exp_source_entity and exp_source_entity in query_entities:
            score += 0.2
            reasons.append(f"Involves queried entity {exp_source_entity[:8]}")

        # 3. Check Direction relevance
        if current_directions:
            for direction_id in current_directions:
                direction_file = self.directions_dir / f"{direction_id}.json"
                if direction_file.exists():
                    with open(direction_file, 'r') as f:
                        direction = json.load(f)

                    intent = direction.get('intent', '').lower()
                    # Check if experience relates to direction
                    if any(word in exp_text for word in intent.split() if len(word) > 4):
                        score += 0.3
                        reasons.append(f"Relates to active Direction: {direction.get('intent')[:50]}")
                        break

        # 4. Retention level bonus (DURABLE experiences more relevant)
        retention = experience.get('retention_level', 'ephemeral')
        if retention == 'durable':
            score += 0.2
            reasons.append("DURABLE retention (high value)")

        # 5. Truth status bonus (EFFECTIVE > SUPPORTED > ASSERTED)
        truth_status = experience.get('truth_status', 'asserted')
        if truth_status == 'effective':
            score += 0.1
        elif truth_status == 'supported':
            score += 0.05

        # Cap score at 1.0
        score = min(score, 1.0)

        # Is relevant if score > threshold
        is_relevant = score >= 0.3

        return {
            "is_relevant": is_relevant,
            "relevance_score": score,
            "reason": "; ".join(reasons) if reasons else "No relevance detected"
        }

    def activate_relationship(self, relationship_id: str, relevance_reason: str, context_id: str = None):
        """
        Activate a DORMANT relationship when it becomes relevant
        Creates Context Membership record (ref 04, line 23)
        """
        rel_file = self.relationships_dir / f"{relationship_id}.json"
        with open(rel_file, 'r') as f:
            relationship = json.load(f)

        if relationship.get("status") != "dormant":
            raise ValueError(f"Can only activate DORMANT relationships, got {relationship.get('status')}")

        # Advance to ACTIVE
        self.advance_relationship(
            relationship_id,
            "active",
            relationship.get("evidence", ["unknown"])[0]
        )

        # Create Context Membership record
        membership_id = str(uuid.uuid4())
        context_id = context_id or str(uuid.uuid4())

        membership = {
            "id": membership_id,
            "member_id": relationship_id,
            "member_type": "relationship",
            "context_id": context_id,
            "activation_status": "active",
            "reason_for_relevance": relevance_reason,
            "activated_at": datetime.utcnow().isoformat() + 'Z',
            "evaluated_at": datetime.utcnow().isoformat() + 'Z'
        }

        membership_file = self.context_dir / f"{membership_id}.json"
        with open(membership_file, 'w') as f:
            json.dump(membership, f, indent=2)

        return membership_id

    def deactivate_relationship(self, relationship_id: str, reason: str):
        """
        Deactivate an ACTIVE relationship when no longer relevant
        ACTIVE → DORMANT (not HISTORICAL - remembered, just not active)
        """
        rel_file = self.relationships_dir / f"{relationship_id}.json"
        with open(rel_file, 'r') as f:
            relationship = json.load(f)

        if relationship.get("status") != "active":
            raise ValueError(f"Can only deactivate ACTIVE relationships, got {relationship.get('status')}")

        # Demote to DORMANT
        self.advance_relationship(
            relationship_id,
            "dormant",
            relationship.get("evidence", ["unknown"])[0]
        )

        # Update context membership
        for membership_file in self.context_dir.glob("*.json"):
            with open(membership_file, 'r') as f:
                membership = json.load(f)

            if membership.get("member_id") == relationship_id:
                membership["activation_status"] = "dormant"
                membership["deactivated_at"] = datetime.utcnow().isoformat() + 'Z'
                membership["deactivation_reason"] = reason

                with open(membership_file, 'w') as f:
                    json.dump(membership, f, indent=2)

    # ============================================================================
    # Direction Lifecycle (Per ref 04, lines 167-173)
    # ============================================================================

    def complete_direction(self, direction_id: str, completion_reason: str,
                          completion_experience_id: str = None):
        """
        Mark direction as completed

        Per ref 04, lines 167-173:
        "Must: record a new Direction / Intent record when it changes"
        """
        dir_file = self.directions_dir / f"{direction_id}.json"
        with open(dir_file, 'r') as f:
            direction = json.load(f)

        direction["status"] = "completed"
        direction["completed_at"] = datetime.utcnow().isoformat() + 'Z'
        direction["completion_reason"] = completion_reason

        if completion_experience_id:
            direction["completion_experience"] = completion_experience_id

        with open(dir_file, 'w') as f:
            json.dump(direction, f, indent=2)

    def supersede_direction(self, old_direction_id: str, new_direction_id: str, reason: str):
        """
        Supersede old direction with new one
        Links them for historical continuity
        """
        old_dir_file = self.directions_dir / f"{old_direction_id}.json"
        with open(old_dir_file, 'r') as f:
            old_direction = json.load(f)

        old_direction["status"] = "superseded"
        old_direction["superseded_at"] = datetime.utcnow().isoformat() + 'Z'
        old_direction["superseded_by"] = new_direction_id
        old_direction["supersession_reason"] = reason

        with open(old_dir_file, 'w') as f:
            json.dump(old_direction, f, indent=2)

        # Link new direction to old
        new_dir_file = self.directions_dir / f"{new_direction_id}.json"
        with open(new_dir_file, 'r') as f:
            new_direction = json.load(f)

        new_direction["supersedes"] = old_direction_id

        with open(new_dir_file, 'w') as f:
            json.dump(new_direction, f, indent=2)
