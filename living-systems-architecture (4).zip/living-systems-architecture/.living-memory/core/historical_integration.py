#!/usr/bin/env python3
"""
Historical Integration Module

Provides chain traversal and pattern discovery across experiences and relationships
Per reference/11: Event relationship semantics and chains
"""
import json
from pathlib import Path
from typing import List, Dict, Optional, Set


class HistoricalIntegration:
    """
    Connect experiences, discover relationships, traverse chains
    WITHOUT rewriting history

    Per ref 11: Event relationship semantics and chains
    """

    # Typed Event Relation Predicates (ref 11, lines 40-56)
    VALID_PREDICATES = {
        # Temporal (not causal)
        "OCCURS_BEFORE",
        "OCCURS_AFTER",
        # Causal
        "CAUSES",
        "RESULTS_FROM",
        "DEPENDS_ON",
        "HAS_CONSEQUENCE",
        # Evidential
        "PROVIDES_EVIDENCE_FOR",
        "CONTRADICTS",
        # Continuation
        "CONTINUES",
        "RECURS_FROM",
        # State-related
        "SUPERSEDES_STATE_FROM",
        "INITIATES_TRANSITION",
        "CONFIRMS_STATE",
        # Relevance
        "REACTIVATES_RELEVANCE_OF",
        # Generic (use only when nothing specific)
        "CONTEXTUALLY_ASSOCIATED_WITH"
    }

    # Predicates requiring causal evidence (not just temporal order)
    CAUSAL_PREDICATES = {"CAUSES", "RESULTS_FROM", "HAS_CONSEQUENCE"}

    # Predicates requiring governance routing
    GOVERNED_PREDICATES = {"CAUSES", "CONTRADICTS", "SUPERSEDES_STATE_FROM",
                           "INITIATES_TRANSITION", "REACTIVATES_RELEVANCE_OF"}

    def __init__(self, memory_root: Path):
        self.memory_root = Path(memory_root)
        self.relationships_dir = self.memory_root / "data" / "relationships"
        self.experiences_dir = self.memory_root / "data" / "experiences"
        self.integrations_dir = self.memory_root / "data" / "integration_assertions"
        self.patterns_dir = self.memory_root / "data" / "patterns"
        self.event_relations_dir = self.memory_root / "data" / "event_relations"

        # Create directories
        for d in [self.integrations_dir, self.patterns_dir, self.event_relations_dir]:
            d.mkdir(parents=True, exist_ok=True)

    # ============================================================================
    # Event-to-Event Typed Relationships (Per ref 11)
    # ============================================================================

    def create_event_relation(self, source_event_id: str, predicate: str,
                             target_event_id: str, evidence: str,
                             source: str = "agent",
                             scope: Optional[str] = None,
                             temporal_claim: Optional[str] = None,
                             status: str = "asserted") -> Optional[str]:
        """
        Create a typed Event-to-Event relationship

        Per ref 11, lines 20-30:
        "Represent Event relations as first-class, directed, typed records:
         source Event + predicate + target Event + source and evidence +
         assertion and governance status + scope + temporal claim(s)"

        Per ref 11, line 34:
        "One Event may have zero, one, or many Event relations. Multiple
         relations may share the same Event pair when they express distinct meanings."

        Args:
            source_event_id: Source experience ID
            predicate: One of VALID_PREDICATES
            target_event_id: Target experience/state/claim ID
            evidence: Evidence supporting this relation
            source: Who asserted this (user/agent/system)
            scope: Optional scope limitation
            temporal_claim: When this relation holds
            status: asserted, validated, supported, effective, contested, historical

        Returns:
            relation_id if created, None if invalid
        """
        import uuid
        from datetime import datetime

        # Validate predicate
        if predicate not in self.VALID_PREDICATES:
            print(f"[ERROR] Invalid predicate '{predicate}'. Must be one of: {self.VALID_PREDICATES}")
            return None

        # Enforce causal evidence requirement (ref 11, line 119)
        if predicate in self.CAUSAL_PREDICATES:
            if not evidence or len(evidence.strip()) < 10:
                print(f"[ERROR] Predicate '{predicate}' requires explicit causal evidence (not just temporal order)")
                return None

        # Verify source and target events exist
        source_file = self.experiences_dir / f"{source_event_id}.json"
        if not source_file.exists():
            print(f"[ERROR] Source event {source_event_id} not found")
            return None

        # Target might be event, state, or claim - check experiences first
        target_file = self.experiences_dir / f"{target_event_id}.json"
        target_exists = target_file.exists()

        relation_id = str(uuid.uuid4())

        relation = {
            "id": relation_id,
            "type": "event_relation",
            "source_event": source_event_id,
            "predicate": predicate,
            "target": target_event_id,
            "target_type": "event" if target_exists else "claim",
            "evidence": evidence,
            "source": source,
            "status": status,
            "scope": scope,
            "temporal_claim": temporal_claim,
            "created_at": datetime.utcnow().isoformat() + 'Z',
            "governed": predicate in self.GOVERNED_PREDICATES
        }

        relation_file = self.event_relations_dir / f"{relation_id}.json"
        with open(relation_file, 'w') as f:
            json.dump(relation, f, indent=2)

        return relation_id

    def get_event_relations(self, event_id: str,
                           direction: str = "both",
                           predicate_filter: Optional[Set[str]] = None) -> List[Dict]:
        """
        Get all typed relations for an event

        Args:
            event_id: Event to query
            direction: "outgoing" (source), "incoming" (target), or "both"
            predicate_filter: Optional set of predicates to filter by

        Returns:
            List of relation records
        """
        relations = []

        for rel_file in self.event_relations_dir.glob("*.json"):
            try:
                with open(rel_file, 'r', encoding='utf-8') as f:
                    rel = json.load(f)

                # Check direction
                is_source = rel.get("source_event") == event_id
                is_target = rel.get("target") == event_id

                if direction == "outgoing" and not is_source:
                    continue
                if direction == "incoming" and not is_target:
                    continue
                if direction == "both" and not (is_source or is_target):
                    continue

                # Check predicate filter
                if predicate_filter and rel.get("predicate") not in predicate_filter:
                    continue

                relations.append(rel)
            except:
                continue

        return relations

    def traverse_event_chain(self, start_event_id: str,
                            predicate_types: Optional[Set[str]] = None,
                            max_depth: int = 10) -> Dict:
        """
        Traverse typed Event relation chain

        Per ref 11, lines 98-106:
        "Traverse only predicates relevant to the requested chain: temporal,
         causal/consequence, dependency, evidence, contradiction, continuation/
         recurrence, relevance, or State transition."

        "Preserve predicate labels and uncertainty at every step. Do not present
         OCCURS_BEFORE as CAUSES."

        Args:
            start_event_id: Starting event
            predicate_types: Filter to specific predicate types (e.g., causal, temporal)
            max_depth: Maximum traversal depth

        Returns:
            Dict with events, relations, and chain structure
        """
        visited_events = set()
        visited_relations = set()
        chain_events = []
        chain_relations = []

        def _traverse(event_id: str, depth: int, path: List[str]):
            if depth >= max_depth or event_id in visited_events:
                return

            visited_events.add(event_id)

            # Load event
            event_file = self.experiences_dir / f"{event_id}.json"
            if event_file.exists():
                with open(event_file, 'r', encoding='utf-8') as f:
                    event = json.load(f)
                    chain_events.append({
                        "id": event_id,
                        "depth": depth,
                        "path": path.copy(),
                        "event": event
                    })

            # Get outgoing relations
            relations = self.get_event_relations(event_id, direction="outgoing",
                                                predicate_filter=predicate_types)

            for rel in relations:
                rel_id = rel.get("id")
                if rel_id in visited_relations:
                    continue

                visited_relations.add(rel_id)
                chain_relations.append(rel)

                # Traverse to target
                target_id = rel.get("target")
                new_path = path + [f"{rel.get('predicate')} -> {target_id}"]
                _traverse(target_id, depth + 1, new_path)

        _traverse(start_event_id, 0, [start_event_id])

        return {
            "start_event": start_event_id,
            "events": chain_events,
            "relations": chain_relations,
            "predicate_filter": list(predicate_types) if predicate_types else "all",
            "max_depth": max_depth
        }

    def detect_causal_vs_temporal(self, event_a_id: str, event_b_id: str) -> Dict:
        """
        Distinguish temporal order from causality

        Per ref 11, line 119:
        "Temporal order permits sequence reconstruction but never proves causality."

        Returns:
            Dict with temporal_relation and causal_relation (if any)
        """
        relations = self.get_event_relations(event_a_id, direction="outgoing")

        temporal = None
        causal = None

        for rel in relations:
            if rel.get("target") == event_b_id:
                predicate = rel.get("predicate")

                if predicate in {"OCCURS_BEFORE", "OCCURS_AFTER"}:
                    temporal = {
                        "predicate": predicate,
                        "status": rel.get("status"),
                        "note": "Temporal order only - does not prove causality"
                    }

                if predicate in self.CAUSAL_PREDICATES:
                    causal = {
                        "predicate": predicate,
                        "evidence": rel.get("evidence"),
                        "status": rel.get("status"),
                        "note": "Causal claim - requires explicit evidence"
                    }

        return {
            "event_a": event_a_id,
            "event_b": event_b_id,
            "temporal_relation": temporal,
            "causal_relation": causal,
            "interpretation": "Temporal and causal are distinct" if temporal and causal else
                             "Temporal only" if temporal else
                             "Causal only" if causal else
                             "No direct relation found"
        }

    def traverse_chain(self, start_id: str, max_depth: int = 10) -> List[Dict]:
        """
        Traverse relationship chain from start entity/experience
        Returns: List of relationships in chain with predicates and statuses
        """
        visited = set()
        chain = []

        def _traverse(current_id: str, depth: int):
            if depth >= max_depth or current_id in visited:
                return

            visited.add(current_id)

            # Find relationships where current_id is subject
            for rel_file in self.relationships_dir.glob("*.json"):
                with open(rel_file, 'r') as f:
                    rel = json.load(f)

                    if rel.get("subject") == current_id:
                        chain.append({
                            "id": rel["id"],
                            "subject_id": rel["subject"],
                            "predicate": rel["predicate"],
                            "object_id": rel["object"],
                            "status": rel.get("status", "unknown"),
                            "depth": depth
                        })
                        # Recurse to object
                        _traverse(rel["object"], depth + 1)

        _traverse(start_id, 0)
        return chain

    def find_path(self, from_id: str, to_id: str, max_depth: int = 10) -> Optional[List[Dict]]:
        """
        Find path from from_id to to_id through relationships
        Returns: List of relationships forming path, or None if no path
        """
        visited = set()

        def _search(current_id: str, path: List[Dict], depth: int) -> Optional[List[Dict]]:
            if current_id == to_id:
                return path

            if depth >= max_depth or current_id in visited:
                return None

            visited.add(current_id)

            for rel_file in self.relationships_dir.glob("*.json"):
                with open(rel_file, 'r') as f:
                    rel = json.load(f)

                    if rel.get("subject") == current_id:
                        new_path = path + [rel]
                        result = _search(rel["object"], new_path, depth + 1)
                        if result is not None:
                            return result

            return None

        return _search(from_id, [], 0)

    def infer_relationship(self, from_id: str, to_id: str) -> Dict:
        """
        Answer: "What does to_id imply about from_id?"
        Returns inference WITHOUT creating direct relationship
        """
        path = self.find_path(from_id, to_id)

        if path is None:
            return {
                "connected": False,
                "inference": "No relationship path found",
                "predicates": [],
                "chain_length": 0,
                "weakest_link": "none"
            }

        predicates = [rel["predicate"] for rel in path]
        statuses = [rel.get("status", "unknown") for rel in path]

        # Analyze chain quality
        weakest_status = self._weakest_status(statuses)

        return {
            "connected": True,
            "inference": f"{from_id} connects to {to_id} via {len(path)}-step chain",
            "predicates": predicates,
            "chain_length": len(path),
            "weakest_link": weakest_status,
            "path": path,
            "caution": "Derived inference - not a direct established fact"
        }

    def _weakest_status(self, statuses: List[str]) -> str:
        """Find weakest link in chain"""
        hierarchy = ["possible", "candidate", "supported", "established", "active"]
        weakest_idx = 0
        for status in statuses:
            if status in hierarchy:
                idx = hierarchy.index(status)
                if idx < hierarchy.index(hierarchy[weakest_idx]) or weakest_idx == 0:
                    weakest_idx = idx
        return hierarchy[weakest_idx] if weakest_idx < len(hierarchy) else "unknown"

    def find_related_experiences(self, entity_id: str, predicate_filter: Optional[str] = None) -> List[str]:
        """
        Find experiences related to entity through relationships
        """
        experience_ids = set()

        # Find relationships involving entity
        for rel_file in self.relationships_dir.glob("*.json"):
            with open(rel_file, 'r') as f:
                rel = json.load(f)

                if predicate_filter and rel.get("predicate") != predicate_filter:
                    continue

                if rel.get("subject") == entity_id or rel.get("object") == entity_id:
                    # Get source experience
                    if "origin" in rel:
                        experience_ids.add(rel["origin"])
                    # Get evidence experiences
                    for evidence_id in rel.get("evidence", []):
                        experience_ids.add(evidence_id)

        return list(experience_ids)

    def reconstruct_context(self, entity_id: str) -> Dict:
        """
        Reconstruct full context for entity: relationships + experiences + chain insights
        """
        # Get direct relationships
        relationships = []
        for rel_file in self.relationships_dir.glob("*.json"):
            with open(rel_file, 'r') as f:
                rel = json.load(f)
                if rel.get("subject") == entity_id or rel.get("object") == entity_id:
                    relationships.append(rel)

        # Get related experiences
        experience_ids = self.find_related_experiences(entity_id)

        # Get chains
        chains = self.traverse_chain(entity_id, max_depth=5)

        return {
            "entity_id": entity_id,
            "direct_relationships": len(relationships),
            "related_experiences": len(experience_ids),
            "chain_depth": len(chains),
            "relationships": relationships,
            "experience_ids": experience_ids,
            "chains": chains
        }

    # ============================================================================
    # Integration Assertions (Per ref 04, line 21)
    # ============================================================================

    def create_integration_assertion(self, connected_ids: List[str],
                                     interpretation: str, rationale: str,
                                     status: str = "proposed") -> str:
        """
        Create an Integration assertion linking History/Experience items

        Per ref 04, line 21:
        "Integration assertion: identifiers of connected History/Experience items,
         asserted interpretation, rationale/evidence, and status"

        Per ref 04, lines 119-125:
        "Must: create an Integration assertion rather than altering underlying History.
               Route any newly inferred Relationship through Memory Governance."
        """
        import uuid
        from datetime import datetime

        assertion_id = str(uuid.uuid4())

        assertion = {
            "id": assertion_id,
            "connected_ids": connected_ids,
            "interpretation": interpretation,
            "rationale": rationale,
            "status": status,  # proposed, accepted, rejected
            "created_at": datetime.utcnow().isoformat() + 'Z',
            "type": "integration_assertion"
        }

        assertion_file = self.integrations_dir / f"{assertion_id}.json"
        with open(assertion_file, 'w') as f:
            json.dump(assertion, f, indent=2)

        return assertion_id

    def reactivate_relevance(self, old_experience_id: str, new_experience_id: str,
                            reason: str) -> str:
        """
        Make an old experience relevant through a new relationship

        Per ref 02, lines 48-52:
        "A new experience can make an older experience relevant.
         Keep History intact while allowing its Relationships and
         contextual interpretation to evolve."

        Creates integration assertion linking them
        """
        interpretation = f"Experience {new_experience_id} reactivates relevance of {old_experience_id}"

        assertion_id = self.create_integration_assertion(
            connected_ids=[old_experience_id, new_experience_id],
            interpretation=interpretation,
            rationale=reason,
            status="accepted"
        )

        return assertion_id

    # ============================================================================
    # Pattern Recognition (Per ref 04, line 29)
    # ============================================================================

    def detect_pattern(self, experience_ids: List[str],
                      pattern_description: str,
                      scope: str = "temporal") -> Dict:
        """
        Detect recurring pattern across experiences

        Per ref 04, line 29:
        "Pattern assertion: linked Experiences/History, observed regularity,
         scope, evidence, counterexamples, status, and interpretation"
        """
        import uuid
        from datetime import datetime

        # Analyze pattern
        experiences = []
        for exp_id in experience_ids:
            exp_file = self.experiences_dir / f"{exp_id}.json"
            if exp_file.exists():
                with open(exp_file, 'r') as f:
                    experiences.append(json.load(f))

        if len(experiences) < 2:
            return {
                "pattern_detected": False,
                "reason": "Insufficient experiences for pattern (need >= 2)"
            }

        # Simple recurrence check
        # In production, this would use ML/statistical analysis
        content_texts = [exp.get("content", {}).get("text", "").lower() for exp in experiences]

        # Find common words
        import string
        stop_words = {"the", "a", "an", "is", "are", "in", "on", "at", "to", "for", "of", "and", "or", "i", "you", "we"}

        word_sets = []
        for text in content_texts:
            words = set(w.strip(string.punctuation).lower() for w in text.split()
                       if w.strip(string.punctuation).lower() not in stop_words and len(w) > 2)
            word_sets.append(words)

        # Find common words across experiences
        if word_sets:
            common_words = word_sets[0]
            for word_set in word_sets[1:]:
                common_words = common_words.intersection(word_set)

            if len(common_words) >= 2:
                # Pattern detected
                pattern_id = str(uuid.uuid4())

                pattern = {
                    "id": pattern_id,
                    "type": "pattern_assertion",
                    "linked_experiences": experience_ids,
                    "observed_regularity": pattern_description,
                    "scope": scope,
                    "evidence": {
                        "experience_count": len(experiences),
                        "common_elements": list(common_words),
                        "recurrence_rate": len(experiences)
                    },
                    "counterexamples": [],
                    "status": "observed",
                    "interpretation": f"Recurring pattern: {pattern_description}",
                    "detected_at": datetime.utcnow().isoformat() + 'Z'
                }

                pattern_file = self.patterns_dir / f"{pattern_id}.json"
                with open(pattern_file, 'w') as f:
                    json.dump(pattern, f, indent=2)

                return {
                    "pattern_detected": True,
                    "pattern_id": pattern_id,
                    "common_elements": list(common_words),
                    "experience_count": len(experiences)
                }

        return {
            "pattern_detected": False,
            "reason": "No significant common elements found"
        }

    def find_recurring_patterns(self, min_occurrences: int = 3) -> List[Dict]:
        """
        Scan all experiences for recurring patterns
        Returns list of detected patterns
        """
        patterns_found = []

        # Group experiences by entity
        entity_experiences = {}

        for exp_file in self.experiences_dir.glob("*.json"):
            try:
                with open(exp_file, 'r') as f:
                    exp = json.load(f)

                entity_id = exp.get("source_entity_id")
                if entity_id:
                    if entity_id not in entity_experiences:
                        entity_experiences[entity_id] = []
                    entity_experiences[entity_id].append(exp.get("id"))
            except:
                continue

        # Check each entity for patterns
        for entity_id, exp_ids in entity_experiences.items():
            if len(exp_ids) >= min_occurrences:
                pattern = self.detect_pattern(
                    exp_ids,
                    f"Recurring behavior from entity {entity_id}",
                    scope="entity_behavior"
                )

                if pattern.get("pattern_detected"):
                    patterns_found.append(pattern)

        return patterns_found
