#!/usr/bin/env python3
"""
Test Governed Recall vs Direct Search
Demonstrates architectural compliance vs violation
"""
import sys
from pathlib import Path
import json

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.memory_control import MemoryControl
from core.memory_governance import MemoryGovernance

def test_governed_recall():
    """
    Test CORRECT way: Governed recall through architecture
    """
    print("=" * 80)
    print("TEST: GOVERNED RECALL (Architecturally Correct)")
    print("=" * 80)
    
    memory_root = Path(".living-memory")
    mc = MemoryControl(memory_root)
    
    # Simulate user question: "Tell me about experiment we did"
    query_context = {
        "type": "user_question",
        "text": "experiment we did at almost first conversation",
        "entities": [],
        "topics": ["experiment", "challenge", "test", "suite"]
    }
    
    # Get active directions
    directions_dir = memory_root / "data" / "directions"
    active_directions = []
    for d in directions_dir.glob('*.json'):
        with open(d, 'r') as f:
            direction = json.load(f)
            if direction['status'] == 'active':
                active_directions.append(direction['id'])
    
    print(f"\n[*] Query: {query_context['text']}")
    print(f"[*] Active Directions: {len(active_directions)}")
    print(f"[*] Topics: {query_context['topics']}")
    
    # GOVERNED RECALL - routes through Memory Control → Governance → Relevance
    results = mc.recall_relevant_experiences(
        query_context=query_context,
        current_directions=active_directions,
        retention_levels=["durable"],
        limit=5
    )
    
    print(f"\n[RESULTS]")
    print(f"  Method: {results['recall_method']}")
    print(f"  Candidates considered: {results['candidates_considered']}")
    print(f"  Filtered by relevance: {results['governance_decision']['filtered_by_relevance']}")
    print(f"  Results returned: {results['results_returned']}")
    
    print(f"\n[TOP RESULTS]")
    for i, exp in enumerate(results['experiences'][:5], 1):
        print(f"\n  [{i}] {exp['occurred_at'][:19]} | {exp['source']} | Score: {exp['relevance_score']:.2f}")
        print(f"      ID: {exp['id'][:8]}")
        print(f"      Relevance: {exp['relevance_reason']}")
        text = exp['content'].get('text', exp['content'].get('observation_type', 'N/A'))
        print(f"      Text: {text[:100]}...")
    
    return results

def test_direct_search_violation():
    """
    Test WRONG way: Direct filesystem search (violates architecture)
    """
    print("\n\n" + "=" * 80)
    print("ANTI-PATTERN: DIRECT SEARCH (Violates Architecture)")
    print("=" * 80)
    
    memory_root = Path(".living-memory")
    experiences_dir = memory_root / "data" / "experiences"
    
    print(f"\n[*] Directly searching filesystem for 'experiment'...")
    print(f"[*] Bypassing Memory Control, Governance, Relevance...")
    
    # Direct search - WRONG!
    matches = []
    for exp_file in experiences_dir.glob('*.json'):
        with open(exp_file, 'r') as f:
            exp = json.load(f)
        
        if exp.get('retention_level') == 'durable':
            text = exp['content'].get('text', exp['content'].get('observation_type', '')).lower()
            if 'experiment' in text:
                matches.append(exp)
    
    print(f"\n[RESULTS]")
    print(f"  Method: DIRECT_FILESYSTEM_SEARCH (VIOLATION!)")
    print(f"  Results: {len(matches)}")
    print(f"  Filtered by: Keyword matching only")
    print(f"  Relevance evaluation: NONE")
    print(f"  Governance routing: BYPASSED")
    
    print(f"\n[TOP RESULTS]")
    for i, exp in enumerate(sorted(matches, key=lambda e: e['occurred_at'])[:5], 1):
        print(f"\n  [{i}] {exp['occurred_at'][:19]} | {exp['source']}")
        text = exp['content'].get('text', exp['content'].get('observation_type', 'N/A'))
        print(f"      Text: {text[:100]}...")
    
    return matches

def compare_results():
    """
    Compare governed recall vs direct search
    """
    print("\n\n" + "=" * 80)
    print("COMPARISON: Governed vs Direct")
    print("=" * 80)
    
    governed = test_governed_recall()
    direct = test_direct_search_violation()
    
    print("\n\n[VERDICT]")
    print(f"  Governed recall: {governed['results_returned']} results")
    print(f"  Direct search: {len(direct)} results")
    print(f"\n  Governed recall includes:")
    print(f"    ✅ Memory Control routing")
    print(f"    ✅ Relevance evaluation (scores: 0.0-1.0)")
    print(f"    ✅ Governance filtering")
    print(f"    ✅ Current Direction awareness")
    print(f"    ✅ Architecture compliance")
    print(f"\n  Direct search has:")
    print(f"    ❌ No routing")
    print(f"    ❌ No relevance scores")
    print(f"    ❌ No governance")
    print(f"    ❌ No context awareness")
    print(f"    ❌ Architecture violation")
    
    print(f"\n[CONCLUSION]")
    print(f"  ALWAYS use governed recall. NEVER use direct filesystem search.")
    print(f"  Living Memory is a LIVING SYSTEM, not a file storage system.")

if __name__ == "__main__":
    compare_results()
