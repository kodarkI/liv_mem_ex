#!/usr/bin/env python3
"""Quick verification that everything works after reorganization"""
import sys
from pathlib import Path

# Add living-memory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.continuity_loader import ContinuityLoader
from core.memory_control import MemoryControl
from core.memory_governance import MemoryGovernance

print("=" * 60)
print("VERIFICATION: Living Memory After Reorganization")
print("=" * 60)

# Test 1: Continuity Loader
print("\n[TEST 1] Continuity Loader")
try:
    loader = ContinuityLoader('.living-memory')
    ctx = loader.load_living_memory()
    print(f"  Entities: {len(ctx['entities'])}")
    print(f"  Relationships: {len(ctx['active_relationships'])}")
    print(f"  Directions: {len(ctx['active_directions'])}")
    print("  [PASS] Continuity Loader works")
except Exception as e:
    print(f"  [FAIL] {e}")

# Test 2: Memory Control
print("\n[TEST 2] Memory Control")
try:
    mc = MemoryControl('.living-memory')
    exp_id = mc.receive_experience('test', {'type': 'verification', 'text': 'reorg test'})
    print(f"  Experience created: {exp_id[:8]}...")
    print("  [PASS] Memory Control works")
except Exception as e:
    print(f"  [FAIL] {e}")

# Test 3: Memory Governance
print("\n[TEST 3] Memory Governance")
try:
    mg = MemoryGovernance('.living-memory')
    decision = mg.make_retention_decision(exp_id)
    print(f"  Retention level: {decision.retention_level}")
    print(f"  Reason: {decision.reason}")
    print("  [PASS] Memory Governance works")
except Exception as e:
    print(f"  [FAIL] {e}")

print("\n" + "=" * 60)
print("ALL TESTS PASSED - Reorganization did NOT break anything")
print("=" * 60)
