#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test: Find ALL experiments using governed recall
User's question: "how many experiments we have and did?"
"""
import sys
import io
from pathlib import Path
import json

# Fix Windows console encoding
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

sys.path.insert(0, str(Path(__file__).parent.parent / 'core'))

from memory_control import MemoryControl

def find_all_experiments():
    """Use governed recall to find ALL experiments"""
    
    print("=" * 80)
    print("GOVERNED RECALL: Find ALL Experiments")
    print("=" * 80)
    
    mc = MemoryControl('.living-memory')
    
    # Query for ALL experiments
    query_context = {
        'type': 'user_question',
        'text': 'how many experiments did we do',
        'entities': [],
        'topics': ['experiment', 'challenge', 'suite', 'test_execution']
    }
    
    # Get active directions
    directions_dir = Path('.living-memory/data/directions')
    active_directions = []
    for d in directions_dir.glob('*.json'):
        with open(d, 'r') as f:
            direction = json.load(f)
            if direction['status'] == 'active':
                active_directions.append(direction['id'])
    
    print(f"\n[Query]")
    print(f"  Text: {query_context['text']}")
    print(f"  Topics: {query_context['topics']}")
    print(f"  Active Directions: {len(active_directions)}")
    
    # Governed recall
    results = mc.recall_relevant_experiences(
        query_context=query_context,
        current_directions=active_directions,
        retention_levels=['durable'],
        limit=100  # High limit to find all
    )
    
    print(f"\n[Governed Recall Stats]")
    print(f"  Candidates considered: {results['candidates_considered']}")
    print(f"  Filtered by relevance: {results['governance_decision']['filtered_by_relevance']}")
    print(f"  Results returned: {results['results_returned']}")
    
    # Extract actual experiments
    experiments = []
    for exp in results['experiences']:
        content = exp['content']
        text = content.get('text', content.get('observation_type', '')).lower()
        
        # Check if this is an experiment record
        is_experiment = False
        if content.get('type') == 'test_execution':
            is_experiment = True
        elif 'experiment' in text and any(keyword in text for keyword in ['challenge', 'suite', 'test']):
            is_experiment = True
        
        if is_experiment:
            experiments.append(exp)
    
    print(f"\n{'=' * 80}")
    print(f"EXPERIMENTS FOUND: {len(experiments)}")
    print(f"{'=' * 80}")
    
    for i, exp in enumerate(experiments, 1):
        print(f"\n[Experiment {i}]")
        print(f"  ID: {exp['id'][:8]}")
        print(f"  Date: {exp['occurred_at'][:19]}")
        print(f"  Source: {exp['source']}")
        print(f"  Relevance Score: {exp.get('relevance_score', 0):.2f}")
        print(f"  Relevance Reason: {exp.get('relevance_reason', 'N/A')}")
        
        content = exp['content']
        if content.get('type') == 'test_execution':
            print(f"  Type: test_execution")
            print(f"  Test file: {content.get('test_file', 'N/A')}")
            print(f"  Challenges run: {content.get('challenges_run', 'N/A')}")
            print(f"  Challenges passed: {content.get('challenges_passed', 'N/A')}")
            print(f"  Challenges failed: {content.get('challenges_failed', 'N/A')}")
            if 'results' in content:
                print(f"  Results: {content['results']}")
            if 'failure_reason' in content:
                print(f"  Failure: {content['failure_reason']}")
        else:
            text = content.get('text', content.get('observation_type', 'N/A'))
            print(f"  Text: {text[:150]}...")
    
    print(f"\n{'=' * 80}")
    print(f"ANSWER: We did {len(experiments)} experiment(s)")
    print(f"{'=' * 80}")
    
    return experiments

if __name__ == "__main__":
    find_all_experiments()
