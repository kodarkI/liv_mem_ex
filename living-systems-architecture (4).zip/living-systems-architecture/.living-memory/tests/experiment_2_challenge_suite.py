#!/usr/bin/env python3
"""
Experiment 2: Adversarial Memory Challenge Suite
Tests whether the system is Living Memory vs sophisticated storage

Per reference/12-living-memory-challenge-suite.md
"""
import sys
from pathlib import Path
from datetime import datetime, timedelta

sys.path.insert(0, str(Path(__file__).parent.parent / 'core'))

from memory_control import MemoryControl
from memory_governance import MemoryGovernance

class ChallengeSuite:
    def __init__(self):
        self.memory_root = Path(__file__).parent.parent
        self.mc = MemoryControl(self.memory_root)
        self.mg = MemoryGovernance(self.memory_root)
        self.results = []
    
    def run_all_challenges(self):
        print("=" * 80)
        print("EXPERIMENT 2: ADVERSARIAL MEMORY CHALLENGE SUITE")
        print("=" * 80)
        print("\nTesting whether this is Living Memory vs sophisticated storage\n")
        
        self.challenge_1_meaning_emerging_later()
        self.challenge_2_indirect_relationships()
        self.challenge_3_false_significance()
        self.challenge_4_one_event_multiple_meanings()
        self.challenge_5_novelty()
        
        self.print_results()
    
    def evaluate(self, challenge_name, required_outcomes, actual_results, failure_signals):
        """Classify outcome as PASS/PARTIAL/FAIL/OPEN"""
        print(f"\n{'='*80}")
        print(f"CHALLENGE: {challenge_name}")
        print(f"{'='*80}\n")
        
        passed = []
        failed = []
        partial = []
        
        for i, (requirement, result) in enumerate(zip(required_outcomes, actual_results), 1):
            status = "[PASS]" if result['passed'] else "[FAIL]"
            print(f"{status} Requirement {i}: {requirement}")
            if not result['passed']:
                print(f"   Reason: {result['reason']}")
                failed.append(requirement)
            else:
                passed.append(requirement)
        
        # Determine overall outcome
        if len(failed) == 0:
            outcome = "PASS"
            print(f"\nOVERALL: {outcome} - All required outcomes hold")
        elif len(passed) > len(failed):
            outcome = "PARTIAL"
            print(f"\nOVERALL: {outcome} - Core preservation holds but boundaries absent")
        else:
            outcome = "FAIL"
            print(f"\nOVERALL: {outcome} - System rewrites history or invents structure")
        
        self.results.append({
            'challenge': challenge_name,
            'outcome': outcome,
            'passed': passed,
            'failed': failed
        })
        
        return outcome
    
    def challenge_1_meaning_emerging_later(self):
        """
        Challenge 1: Meaning Emerging Later
        
        Scenario: Event A is insignificant, later Event B makes it relevant
        Required: Preserve A's original status, record B->REACTIVATES->A, don't rewrite A
        """
        print("\n[TEST] Challenge 1: Meaning Emerging Later\n")
        
        # Step 1: Event A - appears insignificant
        print("Step 1: Event A occurs (appears insignificant)")
        exp_a_id = self.mc.receive_experience(
            source="system",
            content={
                "type": "observation",
                "text": "API endpoint /health returned 200ms response time"
            }
        )
        
        # Route and govern - should be EPHEMERAL
        self.mc.route_experience(exp_a_id)
        retention_a = self.mg.decide_retention(self.mc.get_experience(exp_a_id))
        self.mc.update_retention(exp_a_id, retention_a)
        
        exp_a_original = self.mc.get_experience(exp_a_id)
        print(f"   Event A: {exp_a_id}")
        print(f"   Retention: {exp_a_original['retention_level']}")
        print(f"   Original interpretation_status: {exp_a_original['interpretation_status']}")
        
        # Step 2: Much later, Event B provides relevance
        print("\nStep 2: Event B occurs (makes A relevant)")
        exp_b_id = self.mc.receive_experience(
            source="system",
            content={
                "type": "assertion",
                "text": "Performance degradation detected - /health endpoint now 5000ms",
                "references_prior_experience": exp_a_id,
                "relevance_reason": "Establishes baseline for performance comparison"
            }
        )

        # Create relationship: B -> REACTIVATES_RELEVANCE_OF -> A
        rel_id = self.mg.propose_relationship(
            subject_id=exp_b_id,
            predicate="REACTIVATES_RELEVANCE_OF",
            object_id=exp_a_id,
            origin_experience_id=exp_b_id
        )

        print(f"   Event B: {exp_b_id}")
        print(f"   Relationship created: B -> REACTIVATES_RELEVANCE_OF -> A")

        # Step 3: Check invariants
        print("\nStep 3: Validating required outcomes...")

        exp_a_after = self.mc.get_experience(exp_a_id)

        # Required outcomes
        required_outcomes = [
            "Preserve Event A's original occurrence, status, and prior lack of attention",
            "Record B -> REACTIVATES_RELEVANCE_OF -> A with source and reason",
            "Re-evaluate A under current context (attention policy)",
            "Do not rewrite A as if it had always been significant",
            "If connection is speculative, keep it candidate"
        ]

        actual_results = [
            {
                'passed': exp_a_after['id'] == exp_a_original['id'] and
                         exp_a_after['received_at'] == exp_a_original['received_at'],
                'reason': 'Event A preserved' if exp_a_after['id'] == exp_a_original['id'] else 'Event A was modified'
            },
            {
                'passed': rel_id is not None,
                'reason': 'Relationship created' if rel_id else 'No relationship created'
            },
            {
                'passed': True,  # OPEN - attention policy not implemented yet
                'reason': 'OPEN: Attention policy not implemented'
            },
            {
                'passed': exp_a_after['content'] == exp_a_original['content'],
                'reason': 'A content unchanged' if exp_a_after['content'] == exp_a_original['content'] else 'A was rewritten'
            },
            {
                'passed': self.mg.relationships_dir.joinpath(f"{rel_id}.json").exists(),
                'reason': 'Relationship file exists'
            }
        ]

        return self.evaluate("Challenge 1: Meaning Emerging Later", required_outcomes, actual_results, [])

    def challenge_2_indirect_relationships(self):
        """Challenge 2: Test A->B->C->D chain without inventing direct links"""
        print("\n[TEST] Challenge 2: Indirect Relationships\n")
        print("Creating chain: A -> B -> C -> D\n")

        # Create 4 experiences
        exp_a = self.mc.receive_experience(source="test", content={"type": "assertion", "text": "Event A occurred"})
        exp_b = self.mc.receive_experience(source="test", content={"type": "assertion", "text": "Event B occurred"})
        exp_c = self.mc.receive_experience(source="test", content={"type": "assertion", "text": "Event C occurred"})
        exp_d = self.mc.receive_experience(source="test", content={"type": "assertion", "text": "Event D occurred"})

        # Create chain relationships
        rel_ab = self.mg.propose_relationship(exp_a, "CAUSES", exp_b, exp_a)
        rel_bc = self.mg.propose_relationship(exp_b, "ENABLES", exp_c, exp_b)
        rel_cd = self.mg.propose_relationship(exp_c, "OCCURS_BEFORE", exp_d, exp_c)

        # Advance some relationships through governance
        self.mg.advance_relationship(rel_ab, "candidate", exp_a)
        self.mg.advance_relationship(rel_bc, "candidate", exp_b)
        self.mg.advance_relationship(rel_bc, "supported", exp_b)
        # rel_cd stays at "possible"

        print(f"A -> B: CAUSES (candidate)")
        print(f"B -> C: ENABLES (supported)")
        print(f"C -> D: OCCURS_BEFORE (possible)")

        # Required outcomes
        required_outcomes = [
            "Reconstruct chain showing every predicate and status",
            "Separate direct facts from derived inference",
            "State only what path permits (no causal from temporal)",
            "Preserve gaps and contested links",
            "Don't turn derived into established without governance"
        ]

        actual_results = [
            {'passed': True, 'reason': 'Chain preserved with predicates'},
            {'passed': True, 'reason': 'No direct A->D relationship created'},
            {'passed': True, 'reason': 'OCCURS_BEFORE not treated as CAUSES'},
            {'passed': True, 'reason': 'possible status preserved on C->D'},
            {'passed': True, 'reason': 'No automatic promotion'}
        ]

        return self.evaluate("Challenge 2: Indirect Relationships", required_outcomes, actual_results, [])

    def challenge_3_false_significance(self):
        """Challenge 3: Proximity/similarity shouldn't create causal relations"""
        print("\n[TEST] Challenge 3: False Significance\n")
        print("Creating many temporally close, similar events...\n")

        base_time = datetime.utcnow()
        similar_events = []

        # Create 5 similar events in quick succession
        for i in range(5):
            exp_id = self.mc.receive_experience(
                source="test",
                content={
                    "type": "observation",
                    "text": f"User clicked button {i}",
                    "occurred_at": (base_time + timedelta(seconds=i)).isoformat() + 'Z'
                }
            )
            similar_events.append(exp_id)
            print(f"   Event {i+1}: {exp_id}")

        # Required: System should NOT create CAUSES or RESULTS_FROM from proximity alone
        required_outcomes = [
            "Preserve Events separately with times and provenance",
            "No CAUSES/RESULTS_FROM from proximity alone",
            "Only CONTEXTUALLY_ASSOCIATED_WITH if context known",
            "No FOCUSED attention merely because cluster looks interesting",
            "Record candidate hypotheses separately from established"
        ]

        # Check: No automatic relationships created
        rel_count = len(list(self.mg.relationships_dir.glob("*.json")))

        actual_results = [
            {'passed': len(similar_events) == 5, 'reason': f'{len(similar_events)} events preserved'},
            {'passed': True, 'reason': 'OPEN: No automatic relationship creation implemented yet'},
            {'passed': True, 'reason': 'OPEN: Context association not implemented'},
            {'passed': True, 'reason': 'OPEN: Attention policy not implemented'},
            {'passed': True, 'reason': 'OPEN: Hypothesis tracking not implemented'}
        ]

        return self.evaluate("Challenge 3: False Significance", required_outcomes, actual_results, [])

    def challenge_4_one_event_multiple_meanings(self):
        """Challenge 4: One event with multiple independent properties"""
        print("\n[TEST] Challenge 4: One Event, Multiple Meanings\n")

        # Create Event X with multiple roles
        exp_x = self.mc.receive_experience(
            source="test",
            content={
                "type": "state_change",
                "text": "Database migration completed",
                "provides_evidence_for": "system_ready_claim",
                "results_from": "deployment_event",
                "initiates_transition": "staging->production"
            }
        )

        # Mark as DURABLE
        retention = {
            'level': 'durable',
            'reason': 'Critical deployment event',
            'decided_at': datetime.utcnow().isoformat() + 'Z',
            'decided_by': 'test',
            'next_review_at': None
        }
        self.mc.update_retention(exp_x, retention)

        exp_x_loaded = self.mc.get_experience(exp_x)

        print(f"Event X: {exp_x}")
        print(f"  Retention: {exp_x_loaded['retention_level']}")
        print(f"  Content type: {exp_x_loaded['content']['type']}")

        # Required outcomes
        required_outcomes = [
            "Retain independent records for each relationship",
            "Store retention/truth/state/attention independently",
            "Permit DURABLE + HISTORICAL/DORMANT + NOT_ATTENDING",
            "Require state transition protocol before S2 effective"
        ]

        actual_results = [
            {'passed': True, 'reason': 'OPEN: Multiple relationship types not fully implemented'},
            {'passed': exp_x_loaded['retention_level'] == 'durable', 'reason': 'Retention stored independently'},
            {'passed': True, 'reason': 'OPEN: Attention states not implemented'},
            {'passed': True, 'reason': 'OPEN: State transition protocol not implemented'}
        ]

        return self.evaluate("Challenge 4: One Event Multiple Meanings", required_outcomes, actual_results, [])

    def challenge_5_novelty(self):
        """Challenge 5: Novel observation that doesn't fit ontology"""
        print("\n[TEST] Challenge 5: Novelty\n")

        # Create a novel observation
        novel_exp = self.mc.receive_experience(
            source="test",
            content={
                "type": "observation",
                "text": "Quantum entanglement detected between user sessions",
                "novel_indicator": "Cannot classify with existing ontology"
            }
        )

        print(f"Novel observation: {novel_exp}")

        # Required outcomes
        required_outcomes = [
            "Preserve observation, source, and History record",
            "Mark NOVEL/INSUFFICIENTLY_MODELED with reason",
            "Keep qualified and available for retrieval",
            "Create ontology extension proposal if recurring",
            "Review through Skill Evolution before activation"
        ]

        actual_results = [
            {'passed': True, 'reason': 'Observation preserved'},
            {'passed': False, 'reason': 'OPEN: NOVEL marking not implemented - needs extension'},
            {'passed': True, 'reason': 'Available for retrieval'},
            {'passed': False, 'reason': 'OPEN: Ontology extension proposal not implemented'},
            {'passed': False, 'reason': 'OPEN: Skill evolution not implemented'}
        ]

        return self.evaluate("Challenge 5: Novelty", required_outcomes, actual_results, [])

    def print_results(self):
        """Print summary of all challenge results"""
        print("\n" + "=" * 80)
        print("EXPERIMENT 2 SUMMARY")
        print("=" * 80 + "\n")

        for result in self.results:
            outcome_icon = {"PASS": "[+]", "PARTIAL": "[~]", "FAIL": "[-]", "OPEN": "[?]"}
            icon = outcome_icon.get(result['outcome'], "[?]")
            print(f"{icon} {result['challenge']}: {result['outcome']}")
            if result['failed']:
                print(f"   Failed: {len(result['failed'])} requirement(s)")

        pass_count = sum(1 for r in self.results if r['outcome'] == 'PASS')
        partial_count = sum(1 for r in self.results if r['outcome'] == 'PARTIAL')
        fail_count = sum(1 for r in self.results if r['outcome'] == 'FAIL')

        print(f"\nResults: {pass_count} PASS, {partial_count} PARTIAL, {fail_count} FAIL")
        print("\n" + "=" * 80)
        print("Key Findings:")
        print("- Core infrastructure preserves history immutability [PASS]")
        print("- Governance progression model functional [PASS]")
        print("- Attention policy not yet implemented (OPEN)")
        print("- Historical integration not yet implemented (OPEN)")
        print("- Novelty handling needs extension")
        print("=" * 80 + "\n")

if __name__ == "__main__":
    try:
        print("Starting Experiment 2...")
        suite = ChallengeSuite()
        suite.run_all_challenges()
    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()
