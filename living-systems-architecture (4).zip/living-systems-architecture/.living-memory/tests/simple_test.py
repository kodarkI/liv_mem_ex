#!/usr/bin/env python3
"""Simple test without hanging"""
import json
from pathlib import Path

memory_root = Path(__file__).parent.parent
# Test 1: List what exists
print("📂 Living Memory Contents:")
print(f"Entities: {len(list((memory_root / 'entities').glob('*.json')))}")
print(f"Experiences: {len(list((memory_root / 'experiences').glob('*.json')))}")
print(f"Relationships: {len(list((memory_root / 'relationships').glob('*.json')))}")
print(f"Directions: {len(list((memory_root / 'directions').glob('*.json')))}")

# Test 2: Load bootstrap context
bootstrap_file = memory_root / "bootstrap_context.json"
if bootstrap_file.exists():
    with open(bootstrap_file, 'r') as f:
        bootstrap = json.load(f)
    print(f"\n✅ Bootstrap loaded: {bootstrap['bootstrapped_at']}")
    print(f"   Entities: {list(bootstrap['entities'].keys())}")
    print(f"   Direction: {bootstrap['direction']}")
else:
    print("\n❌ No bootstrap context found")

# Test 3: Load one entity
entities_dir = memory_root / "entities"
first_entity_file = list(entities_dir.glob("*.json"))[0]
with open(first_entity_file, 'r') as f:
    entity = json.load(f)
print(f"\n👤 Sample Entity:")
print(f"   Type: {entity['type']}")
print(f"   ID: {entity['id']}")
print(f"   Status: {entity['lifecycle_status']}")

print("\n✅ Living Memory is operational!")
