#!/usr/bin/env python3
"""
Test: Truth Categories and Retention Lifecycle
Validates:
1. Truth progression: ASSERTED -> VALIDATED -> SUPPORTED -> EFFECTIVE -> HISTORICAL
2. ARCHIVED retention state
3. Retention decision history with supersession
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / "core"))

from memory_control import MemoryControl
from memory_governance import MemoryGovernance
import json
import tempfile
import shutil

def test_truth_and_retention_lifecycle():
    """Test truth categories and retention lifecycle"""
    
    temp_root = Path(tempfile.mkdtemp())
    
    try:
        print("[TEST] Truth Categories and Retention Lifecycle")
        print("=" * 60)
        
        mc = MemoryControl(temp_root)
        mg = MemoryGovernance(temp_root)
        
        # Test 1: Truth Status Progression
        print("\n[1] Testing: ASSERTED -> VALIDATED -> SUPPORTED -> EFFECTIVE")
        
        # Create experience
        exp_id = mc.receive_experience(
            source="user",
            content={"type": "message", "text": "I'm working on the payment module"},
            source_entity_id="user-123"
        )
        
        exp = mc.get_experience(exp_id)
        print(f"    Initial truth_status: {exp['truth_status']}")
        assert exp['truth_status'] == 'asserted', "Should start as ASSERTED"
        
        # Route it (should advance to VALIDATED)
        mc.route_experience(exp_id)
        exp = mc.get_experience(exp_id)
        print(f"    After routing: {exp['truth_status']}")
        assert exp['truth_status'] == 'validated', "Should advance to VALIDATED after routing"
        
        # Apply retention (DURABLE should advance to SUPPORTED then EFFECTIVE)
        retention = mg.decide_retention(exp)
        mc.update_retention(exp_id, retention)
        exp = mc.get_experience(exp_id)
        print(f"    After retention ({retention['level']}): {exp['truth_status']}")
        
        if retention['level'] == 'durable':
            assert exp['truth_status'] == 'effective', "DURABLE should make it EFFECTIVE"
        elif retention['level'] == 'retained':
            assert exp['truth_status'] == 'supported', "RETAINED should make it SUPPORTED"
        
        print("    [PASS] Truth status progresses correctly")
        
        # Test 2: HISTORICAL status
        print("\n[2] Testing: EFFECTIVE -> HISTORICAL when superseded")
        
        # Mark as historical
        mc.mark_as_historical(exp_id, "Superseded by newer state")
        exp = mc.get_experience(exp_id)
        print(f"    Truth status after supersession: {exp['truth_status']}")
        assert exp['truth_status'] == 'historical', "Should become HISTORICAL when superseded"
        assert 'historical_reason' in exp, "Should have reason for becoming historical"
        print(f"    Reason: {exp['historical_reason']}")
        print("    [PASS] Experiences can become HISTORICAL")
        
        # Test 3: ARCHIVED retention level
        print("\n[3] Testing: ARCHIVED retention state")

        # Test the logic directly without relying on recency window
        # Create a fake experience with old retention that should archive
        fake_exp = {
            "id": "fake-exp-123",
            "source": "system",  # Use system to avoid recency window
            "content": {"type": "test"},
            "routed_to": []  # No routing
        }

        # Previous retention decision that has expired
        old_retention = {
            "level": "retained",
            "reason": "Was retained for review",
            "decided_at": "2026-01-01T00:00:00Z",
            "decided_by": "memory_governance",
            "next_review_at": "2026-01-02T00:00:00Z",  # In the past
            "decision_id": "ret-old-001"
        }

        # Re-evaluate (should move to ARCHIVED since review time passed and not in recency)
        retention_new = mg.decide_retention(fake_exp, current_retention=old_retention)

        print(f"    Previous retention: {old_retention['level']}")
        print(f"    After aging out: {retention_new['level']}")
        print(f"    Reason: {retention_new['reason']}")

        assert retention_new['level'] == 'archived', f"Should move to ARCHIVED after aging out, got {retention_new['level']}"
        assert 'supersedes' in retention_new, "Should have supersession link to previous decision"
        print(f"    Supersedes decision: {retention_new['supersedes']}")
        print("    [PASS] ARCHIVED state working")
        
        print("\n" + "=" * 60)
        print("[PASS] ALL TESTS PASSED")
        print("\nImplemented:")
        print("  1. Truth progression: ASSERTED->VALIDATED->SUPPORTED->EFFECTIVE->HISTORICAL")
        print("  2. ARCHIVED retention state (aged out but preserved)")
        print("  3. Retention decision supersession (audit trail)")
        
        return True
        
    finally:
        shutil.rmtree(temp_root, ignore_errors=True)

if __name__ == "__main__":
    try:
        success = test_truth_and_retention_lifecycle()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\n[FAIL] TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
