#!/usr/bin/env python3
"""
Test Relationship Lifecycle Implementation
Tests governance pipeline: possible → candidate → supported → established → active
"""
import sys
import io
from pathlib import Path

if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

from memory_control import MemoryControl
from memory_governance import MemoryGovernance

print("=" * 80)
print("RELATIONSHIP LIFECYCLE TEST")
print("=" * 80)
print()

memory_root = Path(__file__).parent.parent
mc = MemoryControl(memory_root)
mg = MemoryGovernance(memory_root)

# Create initial experiences
exp1 = mc.receive_experience(source="test", content={"type": "observation", "text": "User A worked on Project X"})
exp2 = mc.receive_experience(source="test", content={"type": "observation", "text": "User A committed code to Project X"})
exp3 = mc.receive_experience(source="test", content={"type": "observation", "text": "User A reviewed PR for Project X"})
exp4 = mc.receive_experience(source="test", content={"type": "observation", "text": "User A deployed Project X"})

print("Created 4 test experiences")
print()

# Create relationship at "possible" status
print("STEP 1: Create Relationship (possible)")
print("-" * 80)

rel_id = mg.propose_relationship(
    subject_id="user_a",
    predicate="CONTRIBUTES_TO",
    object_id="project_x",
    origin_experience_id=exp1
)

print(f"Relationship ID: {rel_id[:8]}...")
print(f"Initial status: possible")
print(f"Evidence count: 1")
print()

# Apply governance with 2nd evidence
print("STEP 2: Add Evidence #2 (should advance to candidate)")
print("-" * 80)

result1 = mg.apply_relationship_governance(rel_id, exp2)
print(f"Advanced: {result1['advanced']}")
print(f"Status: {result1['from_status']} -> {result1['to_status']}")
print(f"Reason: {result1['reason']}")
print()

# Apply governance with 3rd evidence
print("STEP 3: Add Evidence #3 (should advance to supported)")
print("-" * 80)

result2 = mg.apply_relationship_governance(rel_id, exp3)
print(f"Advanced: {result2['advanced']}")
print(f"Status: {result2['from_status']} -> {result2['to_status']}")
print(f"Reason: {result2['reason']}")
print()

# Apply governance with 4th evidence
print("STEP 4: Add Evidence #4 (should advance to established)")
print("-" * 80)

result3 = mg.apply_relationship_governance(rel_id, exp4)
print(f"Advanced: {result3['advanced']}")
print(f"Status: {result3['from_status']} -> {result3['to_status']}")
print(f"Reason: {result3['reason']}")
print()

# Manual activation decision
print("STEP 5: Manual Activation (established -> active)")
print("-" * 80)

exp5 = mc.receive_experience(source="agent", content={"type": "assertion", "text": "User A is active contributor to Project X"})
mg.advance_relationship(rel_id, "active", exp5)

print(f"Relationship manually activated")
print(f"Final status: active")
print()

# Validation
print("=" * 80)
print("VALIDATION")
print("=" * 80)
print()

# Check final relationship state
rel_file = memory_root / "relationships" / f"{rel_id}.json"
import json
with open(rel_file, 'r') as f:
    final_rel = json.load(f)

print(f"Final Relationship State:")
print(f"  Status: {final_rel['status']}")
print(f"  Evidence count: {len(final_rel['evidence'])}")
print(f"  Predicate: {final_rel['predicate']}")
print(f"  Status changed at: {final_rel.get('status_changed_at', 'N/A')}")
print()

# Test progression
expected_progression = ["possible", "candidate", "supported", "established", "active"]
if final_rel['status'] == "active":
    print("[PASS] Relationship advanced through full governance pipeline")
    print(f"  Progression: {' -> '.join(expected_progression)}")
else:
    print(f"[FAIL] Expected 'active', got '{final_rel['status']}'")

print()
print("=" * 80)
print("RELATIONSHIP LIFECYCLE: COMPLETE")
print("=" * 80)
