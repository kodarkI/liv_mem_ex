#!/usr/bin/env python3
"""
Test: Recency-based retention policy
Validates that user messages and recent agent responses become DURABLE
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / "core"))

from memory_control import MemoryControl
from memory_governance import MemoryGovernance
import json
import tempfile
import shutil

def test_recency_retention():
    """Test that recency rules work correctly"""
    
    # Create temp memory root
    temp_root = Path(tempfile.mkdtemp())
    
    try:
        mc = MemoryControl(temp_root)
        mg = MemoryGovernance(temp_root)
        
        print("[TEST] Recency-based Retention Policy")
        print("=" * 60)
        
        # Test 1: Recent user message should be RETAINED (not DURABLE unless it establishes something)
        print("\n[1] Testing: Recent user message -> RETAINED (recency window)")
        user_exp_id = mc.receive_experience(
            source="user",
            content={"type": "text", "text": "This is a user question"},
            source_entity_id="user-123",
            occurred_at="2026-08-14T12:00:00Z"
        )

        # Route and govern
        mc.route_experience(user_exp_id)
        user_exp = mc.get_experience(user_exp_id)
        retention = mg.decide_retention(user_exp)
        mc.update_retention(user_exp_id, retention)

        user_exp = mc.get_experience(user_exp_id)
        user_retention = user_exp["retention_level"]
        print(f"    User message retention: {user_retention}")
        print(f"    Reason: {user_exp['retention_decision']['reason']}")
        assert user_retention == "retained", f"Expected retained, got {user_retention}"
        print("    [PASS] Recent user message is RETAINED")

        # Test 2: First 5 agent responses should be RETAINED (recency window)
        print("\n[2] Testing: First 5 agent responses -> RETAINED (recency window)")
        agent_exp_ids = []
        for i in range(5):
            exp_id = mc.receive_experience(
                source="agent",
                content={"type": "text", "text": f"Agent response {i+1}"},
                source_entity_id="agent-001",
                occurred_at="2026-08-14T12:00:00Z"
            )
            # Route and govern
            mc.route_experience(exp_id)
            exp = mc.get_experience(exp_id)
            retention = mg.decide_retention(exp)
            mc.update_retention(exp_id, retention)

            agent_exp_ids.append(exp_id)

        for i, exp_id in enumerate(agent_exp_ids):
            exp = mc.get_experience(exp_id)
            retention = exp["retention_level"]
            print(f"    Agent response {i+1} retention: {retention} - {exp['retention_decision']['reason']}")
            assert retention == "retained", f"Expected retained for response {i+1}, got {retention}"

        print("    [PASS] First 5 agent responses are RETAINED")

        # Test 3: Create many more responses to push earlier ones out of window
        print("\n[3] Testing: Experiences outside recency window -> EPHEMERAL")
        # Create 10 more experiences to push the first ones out of the top-10 window
        import time
        for i in range(10):
            time.sleep(0.01)  # Small delay to ensure different timestamps
            exp_id = mc.receive_experience(
                source="agent",
                content={"type": "text", "text": f"Agent response {6+i}"},
                source_entity_id="agent-001",
                occurred_at=f"2026-08-14T12:00:{10+i:02d}Z"  # Incremental timestamps
            )
            mc.route_experience(exp_id)
            exp = mc.get_experience(exp_id)
            retention = mg.decide_retention(exp)
            mc.update_retention(exp_id, retention)

        # Now check if the FIRST agent message (not user) is still recent or aged out
        # Re-evaluate the first AGENT response (not user, since user messages are rare)
        first_agent_exp = mc.get_experience(agent_exp_ids[0])
        retention_old = mg.decide_retention(first_agent_exp)

        print(f"    First agent message after 10 new experiences: {retention_old['level']}")
        print(f"    Reason: {retention_old['reason']}")
        # Total = 1 user + 5 agent (initial) + 10 agent (new) = 16 experiences
        # First agent response is at position 2 (after 1 user message)
        # So it's outside top 10, and it's the 16th agent message, so outside top 5 agents
        # Should be EPHEMERAL
        assert retention_old["level"] == "ephemeral", f"Expected ephemeral, got {retention_old['level']}"
        print("    [PASS] Old experiences outside recency window become EPHEMERAL")

        # Test 4: User message with intent should be DURABLE
        print("\n[4] Testing: User message establishing direction -> DURABLE")
        user_exp_id_2 = mc.receive_experience(
            source="user",
            content={"type": "message", "text": "Let's build a new feature for tracking metrics"},
            source_entity_id="user-123",
            occurred_at="2026-08-14T12:01:00Z"
        )

        # Route and govern (this should route to "establish_intent")
        mc.route_experience(user_exp_id_2)
        user_exp_2 = mc.get_experience(user_exp_id_2)
        retention = mg.decide_retention(user_exp_2)
        mc.update_retention(user_exp_id_2, retention)

        user_exp_2 = mc.get_experience(user_exp_id_2)
        user_retention_2 = user_exp_2["retention_level"]
        print(f"    User message retention: {user_retention_2}")
        print(f"    Reason: {user_exp_2['retention_decision']['reason']}")
        assert user_retention_2 == "durable", f"Expected durable, got {user_retention_2}"
        print("    [PASS] User message establishing direction is DURABLE")

        print("\n" + "=" * 60)
        print("[PASS] ALL TESTS PASSED: Living Memory retention working correctly")
        print("\nCorrect Retention Policy:")
        print("  - Recent messages (last 5-10): RETAINED (accessible)")
        print("  - Messages establishing identity/state/relationship/direction: DURABLE")
        print("  - Older unimportant messages: EPHEMERAL (pruned)")
        print("\nRecency makes things ACCESSIBLE, not automatically PERMANENT.")
        
        return True
        
    finally:
        # Cleanup
        shutil.rmtree(temp_root, ignore_errors=True)

if __name__ == "__main__":
    try:
        success = test_recency_retention()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\n[FAIL] TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
