#!/usr/bin/env python3
"""Simple test to verify loading works"""
import sys
from pathlib import Path
import io

# Force UTF-8 encoding for stdout
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
if sys.stderr.encoding != 'utf-8':
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

print("Python version:", sys.version)
print("Script location:", __file__)
print("Current working dir:", Path.cwd())

sys.path.insert(0, str(Path(__file__).parent.parent / 'core'))

try:
    from agent_interface import AgentMemoryInterface
    print("[OK] Successfully imported AgentMemoryInterface")

    memory_root = Path(__file__).parent.parent
    print(f"Memory root: {memory_root.absolute()}")

    agent = AgentMemoryInterface(memory_root)
    print("[OK] Created AgentMemoryInterface instance")

    context = agent.initialize_continuity()
    print("[OK] Loaded continuity context")

    print(f"\nLoaded {len(context['entities'])} entities")
    print(f"Loaded {len(context['relationships'])} relationships")
    print(f"Loaded {len(context['directions'])} directions")

    print("\n[PASS] TEST PASSED - Auto-activation works!")

except Exception as e:
    print(f"\n[FAIL] ERROR: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
