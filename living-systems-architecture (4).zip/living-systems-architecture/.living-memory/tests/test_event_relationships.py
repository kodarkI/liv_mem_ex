#!/usr/bin/env python3
"""
Test Event-to-Event Typed Relationships
Per ref 11: Event relationship semantics and chains
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.historical_integration import HistoricalIntegration
from core.memory_control import MemoryControl
import json

def test_event_relationships():
    """Test typed Event relations per ref 11"""

    memory_root = Path(__file__).parent.parent
    hist_int = HistoricalIntegration(memory_root)
    mem_ctrl = MemoryControl(memory_root)

    print("\n" + "="*70)
    print("[TEST] Event-to-Event Typed Relationships")
    print("="*70)

    # Create test experiences
    exp1_id = mem_ctrl.receive_experience(
        source="user",
        content={"type": "statement", "text": "Started working on authentication feature"},
        source_entity_id=None
    )

    exp2_id = mem_ctrl.receive_experience(
        source="user",
        content={"type": "statement", "text": "Authentication feature is now complete"},
        source_entity_id=None
    )

    exp3_id = mem_ctrl.receive_experience(
        source="user",
        content={"type": "statement", "text": "Deployment failed due to authentication bug"},
        source_entity_id=None
    )

    print(f"\n[1] Testing: 15 Typed Predicates")
    print(f"    Architecture: 'Preserve as distinct typed Event relations'")

    # Test 1: Temporal relation (NOT causal)
    rel1_id = hist_int.create_event_relation(
        source_event_id=exp1_id,
        predicate="OCCURS_BEFORE",
        target_event_id=exp2_id,
        evidence="Timestamps show exp1 occurred before exp2",
        source="agent"
    )
    print(f"    Created OCCURS_BEFORE: {rel1_id}")
    assert rel1_id is not None, "Temporal relation should be created"

    # Test 2: Causal relation (requires evidence)
    rel2_id = hist_int.create_event_relation(
        source_event_id=exp2_id,
        predicate="CAUSES",
        target_event_id=exp3_id,
        evidence="The authentication bug introduced in exp2 directly caused the deployment failure in exp3",
        source="agent"
    )
    print(f"    Created CAUSES: {rel2_id}")
    assert rel2_id is not None, "Causal relation with evidence should be created"

    # Test 3: Causal without sufficient evidence should fail
    rel3_id = hist_int.create_event_relation(
        source_event_id=exp1_id,
        predicate="CAUSES",
        target_event_id=exp2_id,
        evidence="short",  # Too short
        source="agent"
    )
    print(f"    Causal without evidence rejected: {rel3_id is None}")
    assert rel3_id is None, "Causal relation without evidence should be rejected"

    print(f"    [PASS] Typed predicates enforce causal evidence requirement")

    # Test 4: Multi-valued relations (same pair, different predicates)
    print(f"\n[2] Testing: Multi-Valued Relations")
    print(f"    Architecture: 'Multiple relations may share the same Event pair'")

    rel4_id = hist_int.create_event_relation(
        source_event_id=exp1_id,
        predicate="PROVIDES_EVIDENCE_FOR",
        target_event_id=exp2_id,
        evidence="Exp1 provides evidence that work was started",
        source="agent"
    )

    # Same source/target, different predicate
    rels = hist_int.get_event_relations(exp1_id, direction="outgoing")
    exp1_to_exp2_rels = [r for r in rels if r.get("target") == exp2_id]

    print(f"    Relations from exp1 to exp2: {len(exp1_to_exp2_rels)}")
    predicates = [r.get("predicate") for r in exp1_to_exp2_rels]
    print(f"    Predicates: {predicates}")

    assert len(exp1_to_exp2_rels) >= 2, "Should have multiple relations between same event pair"
    assert "OCCURS_BEFORE" in predicates, "Should have temporal relation"
    assert "PROVIDES_EVIDENCE_FOR" in predicates, "Should have evidential relation"

    print(f"    [PASS] Multi-valued relations working (not flattened to 'related_to')")

    # Test 5: Causal vs Temporal distinction
    print(f"\n[3] Testing: Causal vs Temporal Distinction")
    print(f"    Architecture: 'Temporal order never proves causality' (ref 11, line 119)")

    analysis = hist_int.detect_causal_vs_temporal(exp1_id, exp2_id)

    print(f"    Temporal relation: {analysis['temporal_relation']}")
    print(f"    Causal relation: {analysis['causal_relation']}")
    print(f"    Interpretation: {analysis['interpretation']}")

    assert analysis['temporal_relation'] is not None, "Should detect temporal relation"
    assert analysis['temporal_relation']['note'] == "Temporal order only - does not prove causality"

    print(f"    [PASS] Temporal and causal kept distinct")


    # Test 6: Chain traversal with predicate filtering
    print(f"\n[4] Testing: Chain Traversal with Predicate Labels")
    print(f"    Architecture: 'Preserve predicate labels at every step'")

    chain = hist_int.traverse_event_chain(exp1_id, max_depth=5)

    print(f"    Events in chain: {len(chain['events'])}")
    print(f"    Relations in chain: {len(chain['relations'])}")

    for rel in chain['relations']:
        print(f"      {rel['source_event'][:8]}... --{rel['predicate']}--> {rel['target'][:8]}...")

    assert len(chain['events']) >= 2, "Should traverse chain"
    assert len(chain['relations']) >= 1, "Should include relations"

    # Verify predicate labels preserved
    predicates_in_chain = [r['predicate'] for r in chain['relations']]
    assert "OCCURS_BEFORE" in predicates_in_chain or "CAUSES" in predicates_in_chain

    print(f"    [PASS] Chain traversal preserves predicate labels")

    # Test 7: Governance flag for critical predicates
    print(f"\n[5] Testing: Governance Routing for Critical Predicates")
    print(f"    Architecture: 'Route causality, contradiction, state effect through Governance'")

    # Load a CAUSES relation
    causal_rel_file = hist_int.event_relations_dir / f"{rel2_id}.json"
    with open(causal_rel_file, 'r') as f:
        causal_rel = json.load(f)

    print(f"    Predicate: {causal_rel['predicate']}")
    print(f"    Governed: {causal_rel['governed']}")
    print(f"    Status: {causal_rel['status']}")

    assert causal_rel['governed'] == True, "CAUSES should be flagged for governance"
    assert causal_rel['status'] in ['asserted', 'validated', 'supported', 'effective']

    print(f"    [PASS] Critical predicates flagged for governance routing")

    print("\n" + "="*70)
    print("[PASS] Event-to-Event Typed Relationships test complete")
    print("="*70)

    print("\nImplemented (per ref 11):")
    print("  [OK] 15 typed predicates (CAUSES, OCCURS_BEFORE, PROVIDES_EVIDENCE_FOR, etc.)")
    print("  [OK] Causal evidence requirement enforced")
    print("  [OK] Temporal vs causal distinction preserved")
    print("  [OK] Multi-valued relations (same pair, different predicates)")
    print("  [OK] First-class directed typed records")
    print("  [OK] Governance routing for critical predicates")
    print("  [OK] Chain traversal with predicate label preservation")
    print()

if __name__ == "__main__":
    test_event_relationships()
