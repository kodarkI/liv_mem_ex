#!/usr/bin/env python3
"""
Test Attention Control System
Per ref 10: Attention and activation policy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.attention_control import AttentionControl
from core.memory_control import MemoryControl

def test_attention_control():
    """Test attention states, priorities, and focus budget per ref 10"""

    memory_root = Path(__file__).parent.parent
    attn = AttentionControl(memory_root)
    mem_ctrl = MemoryControl(memory_root)

    print("\n" + "="*70)
    print("[TEST] Attention Control System")
    print("="*70)

    # Create test experience to use as triggering event
    trigger_exp = mem_ctrl.receive_experience(
        source="user",
        content={"type": "statement", "text": "Critical bug found in production"},
        source_entity_id=None
    )

    print(f"\n[1] Testing: Attention States")
    print(f"    Architecture: 'Separate retention/activation from attention/focus'")

    # Test NOT_ATTENDING -> MONITOR
    alloc1 = attn.allocate_attention(
        target_id="entity-123",
        target_type="bug",
        state="MONITOR",
        priority="NORMAL",
        reason="Watch for updates on this bug",
        triggering_event_id=trigger_exp,
        scope="production"
    )
    print(f"    Created MONITOR allocation: {alloc1}")
    assert alloc1 is not None, "Should create MONITOR allocation"

    # Test FOCUSED
    alloc2 = attn.allocate_attention(
        target_id="entity-456",
        target_type="bug",
        state="FOCUSED",
        priority="HIGH",
        reason="Actively investigating this bug",
        triggering_event_id=trigger_exp,
        scope="production"
    )
    print(f"    Created FOCUSED allocation: {alloc2}")
    assert alloc2 is not None, "Should create FOCUSED allocation"

    print(f"    [PASS] Attention states working")

    # Test 2: Focus Budget
    print(f"\n[2] Testing: Focus Budget (1 FOCUSED per scope)")
    print(f"    Architecture: 'Baseline: one FOCUSED allocation per scope'")

    # Try to create second FOCUSED in same scope - should be queued instead
    alloc3 = attn.allocate_attention(
        target_id="entity-789",
        target_type="bug",
        state="FOCUSED",
        priority="HIGH",
        reason="Another critical bug",
        triggering_event_id=trigger_exp,
        scope="production"
    )

    # Load the allocation to check actual state
    import json
    alloc3_file = attn.attention_dir / f"{alloc3}.json"
    with open(alloc3_file, 'r') as f:
        alloc3_data = json.load(f)

    actual_state = alloc3_data.get("state")
    print(f"    Requested: FOCUSED, Actual: {actual_state}")
    assert actual_state == "QUEUED", "Should be queued when budget exceeded"

    print(f"    [PASS] Focus budget enforced")

    # Test 3: Priority Assessment
    print(f"\n[3] Testing: Priority Assessment")
    print(f"    Architecture: 'URGENT when affects current State/Relationship'")

    priority1 = attn.assess_priority(
        target_id="entity-123",
        target_type="bug",
        affects_current_state=True,
        is_contested=True
    )

    # Test 4: Trigger Evaluation
    print(f"\n[4] Testing: Activation Triggers")
    print(f"    Architecture: 'Triggers make re-evaluation permissible, not automatic focus'")

    recommendations = attn.evaluate_triggers(
        event_id=trigger_exp,
        event_type="contradiction",
        related_targets=[
            {"id": "claim-123", "type": "claim", "is_effective": True, "affects_current_context": True}
        ]
    )

    print(f"    Recommendations: {len(recommendations)}")
    if recommendations:
        rec = recommendations[0]
        print(f"    State: {rec['recommended_state']}, Priority: {rec['recommended_priority']}")
        assert rec['recommended_priority'] == "URGENT", "Contradiction with effective claim should be URGENT"

    print(f"    [PASS] Trigger evaluation working")

    # Test 5: Attention Release
    print(f"\n[5] Testing: Attention Release")
    print(f"    Architecture: 'Release when purpose met; memory stays retained'")

    released = attn.release_attention(alloc1, reason="Bug fixed and deployed")
    assert released == True, "Should release attention"

    # Verify it's marked inactive but still exists
    alloc1_file = attn.attention_dir / f"{alloc1}.json"
    with open(alloc1_file, 'r') as f:
        alloc1_data = json.load(f)

    print(f"    Active: {alloc1_data.get('active')}")
    print(f"    Release reason: {alloc1_data.get('release_reason')}")

    assert alloc1_data.get("active") == False, "Should be inactive"
    assert alloc1_data.get("release_reason") is not None, "Should have release reason"

    print(f"    [PASS] Attention release preserves record")

    # Test 6: Get Active Allocations
    print(f"\n[6] Testing: Query Active Allocations")

    active = attn.get_active_allocations(scope="production")
    print(f"    Active allocations in 'production' scope: {len(active)}")

    # Should have alloc2 and alloc3 (alloc1 was released)
    assert len(active) >= 2, "Should have at least 2 active allocations"

    focused = attn.get_active_allocations(scope="production", state_filter="FOCUSED")
    print(f"    FOCUSED allocations: {len(focused)}")
    assert len(focused) == 1, "Should have exactly 1 FOCUSED (budget limit)"

    print(f"    [PASS] Allocation queries working")

    print("\n" + "="*70)
    print("[PASS] Attention Control System test complete")
    print("="*70)

    print("\nImplemented (per ref 10):")
    print("  [OK] 5 attention states (NOT_ATTENDING, MONITOR, QUEUED, FOCUSED, URGENT)")
    print("  [OK] 4 priority levels (URGENT, HIGH, NORMAL, LOW)")
    print("  [OK] Focus budget enforcement (1 FOCUSED, 1 URGENT per scope)")
    print("  [OK] Priority assessment based on impact")
    print("  [OK] Trigger evaluation (doesn't auto-allocate focus)")
    print("  [OK] Attention release (preserves record, ends work)")
    print("  [OK] Allocation queries by scope and state")
    print()

if __name__ == "__main__":
    test_attention_control()
