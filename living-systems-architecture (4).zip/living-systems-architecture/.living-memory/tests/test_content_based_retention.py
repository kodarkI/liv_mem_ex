#!/usr/bin/env python3
"""
Test content-based retention evaluation.

Validates that Memory Governance correctly identifies important content
and promotes it to DURABLE, even when not explicitly routed to durable operations.
"""
import sys
import json
from pathlib import Path
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'core'))

from memory_control import MemoryControl
from memory_governance import MemoryGovernance

def apply_governance(mc, mg, exp_id):
    """Apply full governance cycle to experience"""
    mc.route_experience(exp_id)
    exp = mc.get_experience(exp_id)
    retention = mg.decide_retention(exp)
    mc.update_retention(exp_id, retention)

def test_user_shares_experiments():
    """Test that user sharing experiment details gets marked DURABLE"""
    print("\n" + "="*80)
    print("TEST 1: User shares 5 experiments (detailed descriptions)")
    print("="*80)

    mc = MemoryControl('.living-memory')
    mg = MemoryGovernance('.living-memory')

    experiments = [
        "Experiment 1: Build my living memory - Test that the system can capture and preserve user context across sessions.",
        "Experiment 2: Adversarial testing - Use challenge suite to validate that system preserves history without rewriting.",
        "Experiment 3: Skill emergence - Observe whether repeated patterns lead to extractable, reusable capabilities.",
        "Experiment 4: Multi-conversation continuity - Verify that a new AI instance can reconstruct context from Living Memory alone.",
        "Experiment 5: Relationship evolution - Test that relationships can transition between POSSIBLE→ACTIVE→DORMANT→HISTORICAL without losing history."
    ]
    
    exp_ids = []
    for exp_text in experiments:
        exp_id = mc.receive_experience(
            source='user',
            source_entity_id='user-test-001',
            content={
                'type': 'message',
                'text': exp_text
            }
        )
        apply_governance(mc, mg, exp_id)
        exp_ids.append(exp_id)
        print(f"\n[Recorded] {exp_text[:60]}...")

    # Check retention levels
    print("\n" + "-"*80)
    print("RETENTION EVALUATION:")
    print("-"*80)
    
    durable_count = 0
    for i, exp_id in enumerate(exp_ids, 1):
        exp = mc.get_experience(exp_id)
        retention = exp.get('retention_level', 'unknown')
        reason = exp.get('retention_decision', {}).get('reason', 'N/A')
        
        print(f"\nExperiment {i}:")
        print(f"  Retention: {retention}")
        print(f"  Reason: {reason}")
        
        if retention == 'durable':
            durable_count += 1
    
    # Validate
    print("\n" + "="*80)
    if durable_count == 5:
        print("[PASS] All 5 experiments marked DURABLE")
        return True
    else:
        print(f"[FAIL] Only {durable_count}/5 experiments marked DURABLE")
        return False

def test_user_correction():
    """Test that user corrections get marked DURABLE"""
    print("\n" + "="*80)
    print("TEST 2: User correction (important clarification)")
    print("="*80)
    
    mc = MemoryControl('.living-memory')
    mg = MemoryGovernance('.living-memory')

    # Original statement
    exp1_id = mc.receive_experience(
        source='user',
        content={'type': 'message', 'text': 'I am working on authentication feature'}
    )
    apply_governance(mc, mg, exp1_id)

    # Correction
    exp2_id = mc.receive_experience(
        source='user',
        content={'type': 'message', 'text': 'Actually I am not working on authentication, I am working on payment'}
    )
    apply_governance(mc, mg, exp2_id)

    exp1 = mc.get_experience(exp1_id)
    exp2 = mc.get_experience(exp2_id)
    
    print(f"\nOriginal: {exp1.get('retention_level')}")
    print(f"Correction: {exp2.get('retention_level')}")
    print(f"Correction reason: {exp2.get('retention_decision', {}).get('reason')}")

    if exp2.get('retention_level') == 'durable':
        print("\n[PASS] User correction marked DURABLE")
        return True
    else:
        print("\n[FAIL] User correction NOT marked DURABLE")
        return False

def test_short_question_not_durable():
    """Test that short questions remain EPHEMERAL"""
    print("\n" + "="*80)
    print("TEST 3: Short question (should be EPHEMERAL)")
    print("="*80)
    
    mc = MemoryControl('.living-memory')
    mg = MemoryGovernance('.living-memory')

    exp_id = mc.receive_experience(
        source='user',
        content={'type': 'message', 'text': 'what is the status?'}
    )
    apply_governance(mc, mg, exp_id)

    exp = mc.get_experience(exp_id)
    retention = exp.get('retention_level')
    
    print(f"\nRetention: {retention}")

    if retention in ['ephemeral', 'retained']:
        print("\n[PASS] Short question correctly NOT marked DURABLE")
        return True
    else:
        print("\n[FAIL] Short question incorrectly marked DURABLE")
        return False

if __name__ == "__main__":
    print("="*80)
    print("CONTENT-BASED RETENTION EVALUATION TESTS")
    print("="*80)
    
    results = []
    results.append(("User shares experiments", test_user_shares_experiments()))
    results.append(("User correction", test_user_correction()))
    results.append(("Short question", test_short_question_not_durable()))
    
    print("\n" + "="*80)
    print("SUMMARY")
    print("="*80)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "[PASS]" if result else "[FAIL]"
        print(f"{status}: {name}")

    print(f"\nTotal: {passed}/{total} tests passed")

    if passed == total:
        print("\nALL TESTS PASSED - Content-based retention working correctly")
    else:
        print(f"\n{total - passed} test(s) failed")
