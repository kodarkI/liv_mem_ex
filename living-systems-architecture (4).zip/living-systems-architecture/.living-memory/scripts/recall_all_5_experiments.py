#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Find all 5 experiments using governed recall"""
import sys
import io
from pathlib import Path
import json

if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

sys.path.insert(0, str(Path(__file__).parent.parent / 'core'))

from memory_control import MemoryControl

print("=" * 80)
print("GOVERNED RECALL: Find ALL 5 Experiments")
print("=" * 80)

# The 5 experiments from user's proposal
experiments_to_find = {
    1: "Build My Living Memory System",
    2: "Adversarial Memory Testing", 
    3: "Skill Emergence & Evolution",
    4: "Multi-Conversation Continuity",
    5: "Relationship Evolution"
}

print("\nLooking for these 5 experiments:")
for num, name in experiments_to_find.items():
    print(f"  Experiment {num}: {name}")

mc = MemoryControl('.living-memory')

# Broader query to catch all experiment mentions
query_context = {
    'type': 'user_question',
    'text': 'all experiments build adversarial testing skill emergence continuity relationship evolution',
    'entities': [],
    'topics': ['experiment', 'build', 'adversarial', 'skill', 'emergence', 'continuity', 'relationship', 'evolution']
}

print(f"\n[Governed Recall Query]")
print(f"  Topics: {query_context['topics']}")

results = mc.recall_relevant_experiences(
    query_context=query_context,
    current_directions=[],
    retention_levels=['durable'],
    limit=100
)

print(f"\n[Results]")
print(f"  Candidates: {results['candidates_considered']}")
print(f"  Returned: {results['results_returned']}")

# Check which experiments are mentioned
found_experiments = {i: [] for i in range(1, 6)}

for exp in results['experiences']:
    content = exp['content']
    text = content.get('text', content.get('observation_type', '')).lower()
    
    # Check for each experiment
    if 'experiment 1' in text or 'build my living memory' in text:
        found_experiments[1].append(exp)
    if 'experiment 2' in text or 'adversarial' in text:
        found_experiments[2].append(exp)
    if 'experiment 3' in text or 'skill emergence' in text:
        found_experiments[3].append(exp)
    if 'experiment 4' in text or 'multi-conversation continuity' in text:
        found_experiments[4].append(exp)
    if 'experiment 5' in text or 'relationship evolution' in text:
        found_experiments[5].append(exp)

print(f"\n{'=' * 80}")
print("EXPERIMENTS FOUND:")
print('=' * 80)

for num in range(1, 6):
    print(f"\nExperiment {num}: {experiments_to_find[num]}")
    if found_experiments[num]:
        print(f"  ✅ Found {len(found_experiments[num])} mention(s)")
        for exp in found_experiments[num]:
            print(f"     - {exp['occurred_at'][:19]} | {exp['source']} | {exp['content'].get('type', 'N/A')}")
            print(f"       ID: {exp['id'][:8]} | Retention: {exp['retention_level']}")
            # Check if it's a test_execution record
            if exp['content'].get('type') == 'test_execution':
                print(f"       ⭐ TEST EXECUTION RECORD")
                if 'challenges_run' in exp['content']:
                    print(f"       Challenges: {exp['content']['challenges_run']}")
                if 'results' in exp['content']:
                    print(f"       Results: {exp['content']['results']}")
    else:
        print(f"  ❌ NOT FOUND by governed recall")

# Summary
print(f"\n{'=' * 80}")
print("SUMMARY")
print('=' * 80)

test_exec_count = 0
for num in range(1, 6):
    for exp in found_experiments[num]:
        if exp['content'].get('type') == 'test_execution':
            test_exec_count += 1

found_count = sum(1 for num in range(1, 6) if found_experiments[num])

print(f"Experiments with mentions: {found_count} / 5")
print(f"Experiments with test_execution records: {test_exec_count} / 5")
print(f"\nMissing from Living Memory:")
for num in range(1, 6):
    if not found_experiments[num]:
        print(f"  - Experiment {num}: {experiments_to_find[num]}")

print(f"\n{'=' * 80}")
print("SOURCE: Living Memory (Governed Recall Only)")
print('=' * 80)
