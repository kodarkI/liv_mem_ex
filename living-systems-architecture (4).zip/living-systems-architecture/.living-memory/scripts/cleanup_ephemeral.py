#!/usr/bin/env python3
"""
Automated cleanup of EPHEMERAL experiences that have aged out
Per ref 08: EPHEMERAL → archive or prune under policy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.memory_governance import MemoryGovernance
import json
from datetime import datetime

def cleanup_ephemeral_experiences(memory_root: Path, dry_run: bool = True):
    """
    Clean up EPHEMERAL experiences that have exceeded their review time
    
    Policy:
    - EPHEMERAL with next_review_at > 24 hours ago → PRUNE (with tombstone)
    - EPHEMERAL with next_review_at > 1 hour ago → re-evaluate (might become ARCHIVED)
    
    Args:
        memory_root: Path to .living-memory/
        dry_run: If True, only report what would be cleaned, don't actually clean
    """
    mg = MemoryGovernance(memory_root)
    experiences_dir = memory_root / "data" / "experiences"
    tombstones_dir = memory_root / "data" / "tombstones"
    tombstones_dir.mkdir(parents=True, exist_ok=True)
    
    now = datetime.utcnow()
    
    stats = {
        "total_scanned": 0,
        "ephemeral_found": 0,
        "ready_for_archive": 0,
        "ready_for_prune": 0,
        "archived": 0,
        "pruned": 0,
        "errors": 0
    }
    
    print("="*70)
    print("EPHEMERAL Experience Cleanup")
    print("="*70)
    print(f"Mode: {'DRY RUN (no changes)' if dry_run else 'LIVE (will modify files)'}")
    print(f"Time: {now.isoformat()}Z\n")
    
    for exp_file in experiences_dir.glob("*.json"):
        stats["total_scanned"] += 1
        
        try:
            with open(exp_file, 'r', encoding='utf-8') as f:
                exp = json.load(f)
            
            retention = exp.get("retention_decision", {})
            level = retention.get("level")
            
            if level != "ephemeral":
                continue
            
            stats["ephemeral_found"] += 1
            
            next_review = retention.get("next_review_at")
            if not next_review:
                continue
            
            # Parse review time
            if next_review.endswith('Z'):
                next_review = next_review[:-1]
            review_time = datetime.fromisoformat(next_review)
            
            age_hours = (now - review_time).total_seconds() / 3600
            
            # Policy: Prune if > 24 hours past review
            if age_hours > 24:
                stats["ready_for_prune"] += 1
                print(f"[PRUNE] {exp['id'][:8]}... - {age_hours:.1f}h past review")
                
                if not dry_run:
                    # Create tombstone
                    tombstone = {
                        "id": exp["id"],
                        "type": "experience",
                        "original_retention_level": "ephemeral",
                        "pruned_at": now.isoformat() + 'Z',
                        "pruned_reason": f"EPHEMERAL aged out ({age_hours:.1f} hours past review)",
                        "original_source": exp.get("source"),
                        "original_received_at": exp.get("received_at"),
                        "original_content_type": exp.get("content", {}).get("type")
                    }
                    
                    tombstone_file = tombstones_dir / f"{exp['id']}.json"
                    with open(tombstone_file, 'w') as f:
                        json.dump(tombstone, f, indent=2)
                    
                    # Delete original
                    exp_file.unlink()
                    stats["pruned"] += 1
            
            # Policy: Archive if > 1 hour past review
            elif age_hours > 1:
                stats["ready_for_archive"] += 1
                print(f"[ARCHIVE] {exp['id'][:8]}... - {age_hours:.1f}h past review")
                
                if not dry_run:
                    exp["retention_level"] = "archived"
                    exp["retention_decision"] = {
                        "level": "archived",
                        "reason": "EPHEMERAL aged out of review period",
                        "decided_at": now.isoformat() + 'Z',
                        "decided_by": "automated_cleanup",
                        "supersedes": retention.get("decision_id"),
                        "next_review_at": None
                    }
                    
                    with open(exp_file, 'w') as f:
                        json.dump(exp, f, indent=2)
                    stats["archived"] += 1
        
        except Exception as e:
            stats["errors"] += 1
            print(f"[ERROR] {exp_file.name}: {e}")
    
    print("\n" + "="*70)
    print("CLEANUP SUMMARY")
    print("="*70)
    print(f"Total experiences scanned: {stats['total_scanned']}")
    print(f"EPHEMERAL found: {stats['ephemeral_found']}")
    print(f"Ready for ARCHIVE: {stats['ready_for_archive']}")
    print(f"Ready for PRUNE: {stats['ready_for_prune']}")
    
    if not dry_run:
        print(f"\nACTIONS TAKEN:")
        print(f"  Archived: {stats['archived']}")
        print(f"  Pruned (with tombstone): {stats['pruned']}")
    else:
        print(f"\nDRY RUN - No changes made. Run with --live to execute cleanup.")
    
    print(f"Errors: {stats['errors']}")
    print()

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Clean up EPHEMERAL experiences")
    parser.add_argument("--live", action="store_true", help="Actually perform cleanup (default is dry run)")
    args = parser.parse_args()
    
    memory_root = Path(__file__).parent.parent
    cleanup_ephemeral_experiences(memory_root, dry_run=not args.live)
