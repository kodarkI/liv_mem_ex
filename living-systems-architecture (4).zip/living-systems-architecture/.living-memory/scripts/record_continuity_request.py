#!/usr/bin/env python3
"""
Record user's continuity check request - testing cross-conversation memory
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from memory_control import MemoryControl
from continuity_loader import ContinuityLoader
import json

# Load living memory context
loader = ContinuityLoader(Path(__file__).parent)
context = loader.load_bootstrap_context()

user_id = context['entities']['user']
agent_id = context['entities']['agent']
conversation_id = context['entities']['conversation']

mc = MemoryControl(Path(__file__).parent)

# Record user's continuity check request
user_message = """let see what we are talking last time and what is left to do? 
follow the protocol or rule and concept from my living memory. not just see md and check on doc and violent my protocol"""

exp_id = mc.receive_experience({
    'type': 'user_message',
    'from_entity': user_id,
    'to_entity': agent_id,
    'in_context': conversation_id,
    'text': user_message,
    'intent': 'continuity_check',
    'tags': ['cross_conversation', 'protocol_emphasis', 'living_memory_validation']
})

print(f"✅ Recorded user continuity check request: {exp_id}")

# Load the experience to see governance decision
exp_file = Path(__file__).parent / 'experiences' / f'{exp_id}.json'
if exp_file.exists():
    with open(exp_file, 'r') as f:
        exp = json.load(f)
    print(f"\nGovernance Decision: {exp['governance_decision']['retention_level']}")
    print(f"Reasoning: {exp['governance_decision']['reasoning']}")
