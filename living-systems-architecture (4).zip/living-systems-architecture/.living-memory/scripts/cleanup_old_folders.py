#!/usr/bin/env python3
"""
Clean up old empty folders after reorganization
"""
import os
import shutil
from pathlib import Path

def safe_remove_if_empty(folder: Path):
    """Remove folder only if it's empty"""
    if not folder.exists():
        print(f"  [SKIP] {folder.name}/ - doesn't exist")
        return False
    
    if not folder.is_dir():
        print(f"  [SKIP] {folder.name} - not a directory")
        return False
    
    # Check if empty
    contents = list(folder.iterdir())
    if contents:
        print(f"  [SKIP] {folder.name}/ - not empty ({len(contents)} items)")
        return False
    
    # Try to remove
    try:
        folder.rmdir()
        print(f"  [OK] Removed {folder.name}/")
        return True
    except (PermissionError, OSError) as e:
        print(f"  [ERROR] {folder.name}/ - {e}")
        return False

def main():
    root = Path(__file__).parent.parent
    
    print("=" * 80)
    print("Cleaning Up Old Empty Folders")
    print("=" * 80)
    
    # Old data folders that should now be in data/
    old_folders = [
        "entities",
        "experiences", 
        "relationships",
        "directions",
        "states",
        "schemas"
    ]
    
    removed_count = 0
    
    print("\nChecking old data folders in root...")
    for folder_name in old_folders:
        folder_path = root / folder_name
        if safe_remove_if_empty(folder_path):
            removed_count += 1
    
    # Also check for core/data/ duplicate
    core_data = root / "core" / "data"
    if core_data.exists():
        print("\nChecking core/data/ duplicate...")
        if safe_remove_if_empty(core_data):
            removed_count += 1
    
    print("\n" + "=" * 80)
    print(f"[COMPLETE] Removed {removed_count} empty folders")
    print("=" * 80)
    
    # Verify structure
    print("\nCurrent structure:")
    for item in sorted(root.iterdir()):
        if item.is_dir() and not item.name.startswith('__'):
            print(f"  {item.name}/")

if __name__ == "__main__":
    main()
