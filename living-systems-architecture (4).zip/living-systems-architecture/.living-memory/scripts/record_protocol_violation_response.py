#!/usr/bin/env python3
"""
Record user's protocol violation call-out and my corrected response
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from memory_control import MemoryControl
from continuity_loader import ContinuityLoader
import json

loader = ContinuityLoader(Path(__file__).parent)
context = loader.load_bootstrap_context()

user_id = context['entities']['user']
agent_id = context['entities']['agent']
conversation_id = context['entities']['conversation']

mc = MemoryControl(Path(__file__).parent)

# Record user's correction
user_correction = "don't you have records of our last conversations? even when follow protocol?"

exp_id = mc.receive_experience({
    'type': 'user_message',
    'from_entity': user_id,
    'to_entity': agent_id,
    'in_context': conversation_id,
    'text': user_correction,
    'intent': 'protocol_violation_callout',
    'tags': ['correction', 'protocol_enforcement', 'teaching_moment']
})

print(f"✅ Recorded user protocol correction: {exp_id}")

# Load and show governance decision
exp_file = Path(__file__).parent / 'experiences' / f'{exp_id}.json'
if exp_file.exists():
    with open(exp_file, 'r') as f:
        exp = json.load(f)
    print(f"\nGovernance Decision: {exp['governance_decision']['retention_level']}")
    print(f"Reasoning: {exp['governance_decision']['reasoning']}")
    
    # This should be DURABLE - user is teaching AI about protocol compliance
    if exp['governance_decision']['retention_level'] != 'durable':
        print("\n⚠️  GOVERNANCE ERROR: This should be DURABLE")
        print("   User is correcting AI behavior - critical learning moment")
