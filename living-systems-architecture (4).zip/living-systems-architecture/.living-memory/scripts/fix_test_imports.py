#!/usr/bin/env python3
"""
Fix import paths in all test files to point to core/
"""
import re
from pathlib import Path

def fix_test_file(filepath: Path):
    """Fix import paths in a test file"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        original = content
        
        # Pattern 1: sys.path.insert(0, str(Path(__file__).parent))
        # Replace with: sys.path.insert(0, str(Path(__file__).parent.parent / 'core'))
        content = re.sub(
            r"sys\.path\.insert\(0,\s*str\(Path\(__file__\)\.parent\)\)",
            "sys.path.insert(0, str(Path(__file__).parent.parent / 'core'))",
            content
        )
        
        # Pattern 2: self.memory_root = Path(__file__).parent
        # Replace with: self.memory_root = Path(__file__).parent.parent
        content = re.sub(
            r"self\.memory_root\s*=\s*Path\(__file__\)\.parent\s*$",
            "self.memory_root = Path(__file__).parent.parent",
            content,
            flags=re.MULTILINE
        )
        
        # Pattern 3: memory_root = Path(__file__).parent (without self)
        content = re.sub(
            r"(\s+)memory_root\s*=\s*Path\(__file__\)\.parent\s*$",
            r"\1memory_root = Path(__file__).parent.parent",
            content,
            flags=re.MULTILINE
        )
        
        if content != original:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        
        return False
        
    except Exception as e:
        print(f"  [ERROR] {filepath.name}: {e}")
        return False

def main():
    root = Path(__file__).parent.parent
    tests_dir = root / "tests"
    
    print("=" * 80)
    print("Fixing Test Import Paths")
    print("=" * 80)
    
    # Get all Python files in tests/
    test_files = list(tests_dir.glob("*.py"))
    
    print(f"\nFound {len(test_files)} test files\n")
    
    fixed_count = 0
    skipped_count = 0
    
    for test_file in sorted(test_files):
        if fix_test_file(test_file):
            print(f"  [OK] {test_file.name}")
            fixed_count += 1
        else:
            print(f"  [SKIP] {test_file.name} (no changes needed)")
            skipped_count += 1
    
    print("\n" + "=" * 80)
    print(f"[COMPLETE] Fixed {fixed_count} files, Skipped {skipped_count} files")
    print("=" * 80)

if __name__ == "__main__":
    main()
