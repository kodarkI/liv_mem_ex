#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Use ONLY governed recall to find experiment details - NO SEARCHING"""
import sys
import io
from pathlib import Path
import json

# Fix Windows encoding
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

sys.path.insert(0, str(Path(__file__).parent.parent / 'core'))

from memory_control import MemoryControl

print("=" * 80)
print("GOVERNED RECALL: Find ALL Experiment Details")
print("=" * 80)

mc = MemoryControl('.living-memory')

# Get active directions
directions_dir = Path('.living-memory/data/directions')
active_directions = []
for d in directions_dir.glob('*.json'):
    with open(d, 'r') as f:
        direction = json.load(f)
        if direction['status'] == 'active':
            active_directions.append(direction['id'])

# Query for experiments with broad relevance
query_context = {
    'type': 'user_question',
    'text': 'find detailed information about all experiments challenges tests we did',
    'entities': [],
    'topics': ['experiment', 'challenge', 'test', 'suite', 'execution', 'result']
}

print(f"\nQuery: {query_context['text']}")
print(f"Topics: {query_context['topics']}")
print(f"Using: Governed recall through Memory Control")

# Use governed recall - ONLY method allowed
results = mc.recall_relevant_experiences(
    query_context=query_context,
    current_directions=active_directions,
    retention_levels=['durable'],
    limit=100  # High limit to get everything
)

print(f"\n[Governed Recall Results]")
print(f"  Candidates considered: {results['candidates_considered']}")
print(f"  Filtered by relevance: {results['governance_decision']['filtered_by_relevance']}")
print(f"  Results returned: {results['results_returned']}")

# Filter for experiment-related
experiments = []
for exp in results['experiences']:
    content = exp['content']
    content_type = content.get('type', '')
    text = content.get('text', content.get('observation_type', '')).lower()
    
    # Include if: test_execution type OR contains "experiment" + test-related words
    is_experiment = (
        content_type == 'test_execution' or
        ('experiment' in text and any(word in text for word in ['challenge', 'suite', 'test', 'pass', 'fail']))
    )
    
    if is_experiment:
        experiments.append(exp)

print(f"\n{'=' * 80}")
print(f"EXPERIMENTS FOUND BY GOVERNED RECALL: {len(experiments)}")
print(f"{'=' * 80}")

for i, exp in enumerate(sorted(experiments, key=lambda e: e['occurred_at']), 1):
    print(f"\n[{i}] Date: {exp['occurred_at'][:19]} | Source: {exp['source']}")
    print(f"    ID: {exp['id'][:8]}")
    print(f"    Retention: {exp['retention_level']}")
    print(f"    Truth Status: {exp.get('truth_status', 'N/A')}")
    print(f"    Relevance Score: {exp.get('relevance_score', 0):.2f}")
    
    content = exp['content']
    print(f"    Content Type: {content.get('type', 'N/A')}")
    
    # Show details based on type
    if content.get('type') == 'test_execution':
        print(f"    Test File: {content.get('test_file', 'N/A')}")
        if 'challenges_run' in content:
            print(f"    Challenges Run: {content.get('challenges_run')}")
            print(f"    Challenges Passed: {content.get('challenges_passed')}")
            print(f"    Challenges Failed: {content.get('challenges_failed')}")
        if 'results' in content:
            print(f"    Results: {content.get('results')}")
        if 'failure_reason' in content:
            print(f"    Failure Reason: {content.get('failure_reason')}")
        if 'test' in content:
            print(f"    Test: {content.get('test')}")
        if 'result' in content:
            print(f"    Result: {content.get('result')}")
        if 'demonstrates' in content:
            print(f"    Demonstrates: {content.get('demonstrates')}")
    
    # Show text (first 200 chars)
    text = content.get('text', content.get('observation_type', 'N/A'))
    print(f"    Text: {text[:200]}{'...' if len(text) > 200 else ''}")

print(f"\n{'=' * 80}")
print(f"SOURCE: Living Memory (Governed Recall)")
print(f"METHOD: memory_control.recall_relevant_experiences()")
print(f"NO FILESYSTEM SEARCH USED")
print(f"{'=' * 80}")

# Extract experiment numbers
experiment_numbers = set()
for exp in experiments:
    text = exp['content'].get('text', exp['content'].get('observation_type', ''))
    # Look for "Experiment N" pattern
    import re
    matches = re.findall(r'[Ee]xperiment\s*(\d+)', text)
    for match in matches:
        experiment_numbers.add(int(match))

if experiment_numbers:
    print(f"\nExperiment numbers mentioned: {sorted(experiment_numbers)}")

print(f"\n{'=' * 80}")
print(f"ANSWER: Living Memory shows {len([e for e in experiments if e['content'].get('type') == 'test_execution'])} test_execution records")
print(f"{'=' * 80}")
