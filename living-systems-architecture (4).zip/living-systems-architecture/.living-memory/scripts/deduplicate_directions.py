#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Deduplicate Directions

Find and remove duplicate directions based on intent text.
Keep the oldest occurrence of each unique intent.
"""

import json
import sys
from pathlib import Path
from datetime import datetime
from collections import defaultdict

def main():
    script_dir = Path(__file__).parent
    memory_root = script_dir.parent / "data"
    directions_dir = memory_root / "directions"
    
    if not directions_dir.exists():
        print(f"[ERROR] Directions directory not found: {directions_dir}", file=sys.stderr)
        sys.exit(1)
    
    print("=" * 80)
    print("DIRECTION DEDUPLICATION")
    print("=" * 80)
    print(f"[*] Directions directory: {directions_dir}\n")
    
    # Load all directions
    directions = []
    for dir_file in directions_dir.glob("*.json"):
        with open(dir_file, 'r', encoding='utf-8') as f:
            direction = json.load(f)
            direction['_filepath'] = dir_file
            directions.append(direction)
    
    print(f"[*] Found {len(directions)} direction files\n")
    
    # Group by intent text
    by_intent = defaultdict(list)
    for direction in directions:
        intent = direction.get('intent', '').strip()
        if intent:
            by_intent[intent].append(direction)
    
    print(f"[*] Found {len(by_intent)} unique intents\n")
    
    # Find duplicates
    duplicates_to_remove = []
    for intent, dups in by_intent.items():
        if len(dups) > 1:
            print(f"[DUPLICATE] Intent: {intent[:60]}...")
            print(f"            Found {len(dups)} occurrences:")
            
            # Sort by created_at (keep oldest)
            dups.sort(key=lambda d: d.get('created_at', ''))
            
            keep = dups[0]
            remove = dups[1:]
            
            print(f"            KEEP:   {keep['_filepath'].name} (created: {keep.get('created_at', 'unknown')})")
            for dup in remove:
                print(f"            REMOVE: {dup['_filepath'].name} (created: {dup.get('created_at', 'unknown')})")
                duplicates_to_remove.append(dup['_filepath'])
            print()
    
    if not duplicates_to_remove:
        print("[OK] No duplicates found. All directions are unique.\n")
        print("=" * 80)
        print("DEDUPLICATION: COMPLETE (0 removed)")
        print("=" * 80)
        sys.exit(0)
    
    # Remove duplicates
    print(f"[*] Removing {len(duplicates_to_remove)} duplicate direction files...\n")
    
    for filepath in duplicates_to_remove:
        print(f"    Removing: {filepath.name}")
        filepath.unlink()
    
    print()
    print("=" * 80)
    print(f"DEDUPLICATION: COMPLETE ({len(duplicates_to_remove)} removed)")
    print("=" * 80)
    print(f"\n[OK] Kept {len(by_intent)} unique directions")
    print(f"[OK] Removed {len(duplicates_to_remove)} duplicates")

if __name__ == '__main__':
    main()
