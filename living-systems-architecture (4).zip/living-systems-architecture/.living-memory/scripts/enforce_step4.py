#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Step 4 Enforcement Checker

This script checks if agent responses are being recorded as Experiences.
Run this AFTER agent generates a response to ensure protocol compliance.

Per SKILL.md:
- Step 4 MUST execute after agent finishes response
- Agent responses MUST be recorded as Experiences
- If not recorded, this is a CRITICAL protocol violation

Usage:
  python enforce_step4.py --check-last-n-minutes 5
  
Returns:
  Exit 0: Compliance OK
  Exit 1: Violation detected (agent response missing)
"""

import sys
import json
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Optional

def load_recent_experiences(memory_root: Path, minutes: int) -> List[Dict]:
    """Load experiences from the last N minutes."""
    exp_dir = memory_root / "experiences"
    cutoff = datetime.utcnow() - timedelta(minutes=minutes)
    
    recent = []
    for exp_file in exp_dir.glob("*.json"):
        with open(exp_file, 'r', encoding='utf-8') as f:
            exp = json.load(f)
            received_at = exp.get('received_at', '')
            if not received_at:
                continue
            
            exp_time = datetime.fromisoformat(received_at.replace('Z', ''))
            if exp_time > cutoff:
                recent.append(exp)
    
    # Sort by time (oldest first)
    recent.sort(key=lambda x: x.get('received_at', ''))
    return recent

def check_step4_compliance(experiences: List[Dict]) -> tuple[bool, str]:
    """
    Check if Step 4 is being followed.
    
    Rule: For every user message, there should be a corresponding agent response.
    Exception: The most recent message might be a user message awaiting response.
    
    Returns: (is_compliant, reason)
    """
    if not experiences:
        return True, "No recent experiences"
    
    # Count user vs agent messages
    user_messages = [e for e in experiences if e.get('source') == 'user']
    agent_messages = [e for e in experiences if e.get('source') == 'agent']
    
    # If we have user messages but NO agent messages, that's a violation
    if user_messages and not agent_messages:
        return False, f"Found {len(user_messages)} user message(s) but 0 agent responses - Step 4 not executed"
    
    # Check if agent responses are linked to user messages
    unlinked_user_messages = []
    for user_msg in user_messages:
        user_id = user_msg.get('id')
        
        # Look for agent response that references this user message
        linked = False
        for agent_msg in agent_messages:
            if agent_msg.get('content', {}).get('in_response_to') == user_id:
                linked = True
                break
        
        # Exception: Most recent user message might not have response yet
        if not linked and user_msg != user_messages[-1]:
            unlinked_user_messages.append(user_id[:8])
    
    if unlinked_user_messages:
        return False, f"User messages without agent responses: {', '.join(unlinked_user_messages)}"
    
    return True, f"Compliance OK: {len(agent_messages)} agent responses for {len(user_messages)} user messages"

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Enforce Step 4 protocol compliance")
    parser.add_argument('--check-last-n-minutes', type=int, default=5,
                       help='Check experiences from last N minutes (default: 5)')
    parser.add_argument('--memory-root', type=str, default=None,
                       help='Path to .living-memory/data (default: auto-detect)')
    args = parser.parse_args()
    
    # Find memory root
    if args.memory_root:
        memory_root = Path(args.memory_root)
    else:
        # Auto-detect
        script_dir = Path(__file__).parent
        memory_root = script_dir.parent / "data"
    
    if not memory_root.exists():
        print(f"[ERROR] Memory root not found: {memory_root}", file=sys.stderr)
        sys.exit(1)
    
    print("=" * 80)
    print("STEP 4 ENFORCEMENT CHECK")
    print("=" * 80)
    print(f"[*] Memory root: {memory_root}")
    print(f"[*] Checking last {args.check_last_n_minutes} minutes")
    print()
    
    # Load recent experiences
    experiences = load_recent_experiences(memory_root, args.check_last_n_minutes)
    print(f"[*] Found {len(experiences)} recent experiences")
    
    # Check compliance
    is_compliant, reason = check_step4_compliance(experiences)
    
    if is_compliant:
        print(f"[OK] {reason}")
        print()
        print("=" * 80)
        print("STEP 4 COMPLIANCE: PASS")
        print("=" * 80)
        sys.exit(0)
    else:
        print(f"[VIOLATION] {reason}")
        print()
        print("=" * 80)
        print("STEP 4 COMPLIANCE: FAIL")
        print("=" * 80)
        print()
        print("REQUIRED ACTION:")
        print("  Execute: python record_conversation_turn.py --agent \"<your_response>\" --in-response-to \"<user_exp_id>\"")
        print()
        
        # Record this violation as an experience
        violation_exp = {
            "id": f"violation-{datetime.utcnow().isoformat().replace(':', '-')}",
            "source": "system",
            "source_entity_id": None,
            "occurred_at": datetime.utcnow().isoformat() + 'Z',
            "received_at": datetime.utcnow().isoformat() + 'Z',
            "content": {
                "type": "protocol_violation",
                "violation_type": "step_4_not_executed",
                "description": reason,
                "severity": "critical"
            },
            "interpretation_status": "raw",
            "routed_to": [],
            "retention_level": "durable",
            "retention_decision": {
                "level": "durable",
                "reason": "Protocol violations must be preserved for learning",
                "decided_at": datetime.utcnow().isoformat() + 'Z',
                "decided_by": "enforcement_checker",
                "next_review_at": None
            }
        }
        
        violation_file = memory_root / "experiences" / f"{violation_exp['id']}.json"
        with open(violation_file, 'w', encoding='utf-8') as f:
            json.dump(violation_exp, f, indent=2, ensure_ascii=False)
        
        print(f"[*] Violation recorded as Experience: {violation_exp['id']}")
        
        sys.exit(1)

if __name__ == '__main__':
    main()
