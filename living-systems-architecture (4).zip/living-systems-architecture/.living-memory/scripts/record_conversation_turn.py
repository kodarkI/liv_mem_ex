#!/usr/bin/env python3
"""
Record Conversation Turn
Enforces protocol: every user message and agent response becomes an Experience
Usage:
  python record_conversation_turn.py --user "message text"
  python record_conversation_turn.py --agent "response text" --in-response-to "exp_id"
"""
import argparse
import json
import sys
from pathlib import Path

# Add core to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'core'))

from agent_interface import AgentMemoryInterface

def main():
    parser = argparse.ArgumentParser(description="Record conversation turn in Living Memory")
    parser.add_argument("--user", type=str, help="User message text")
    parser.add_argument("--agent", type=str, help="Agent response text")
    parser.add_argument("--in-response-to", type=str, help="Experience ID this responds to")
    parser.add_argument("--observation", type=str, help="Agent observation (not conversational message)")
    parser.add_argument("--observation-type", type=str, default="general", help="Type of observation")
    
    args = parser.parse_args()
    
    # Initialize agent interface
    agent = AgentMemoryInterface()
    agent.initialize_continuity()
    
    if args.user:
        # Record user message
        exp_id = agent.receive_user_message(args.user)
        print(f"[OK] Recorded user message as Experience: {exp_id}")
        print(f"   Text: {args.user[:100]}{'...' if len(args.user) > 100 else ''}")
        return exp_id

    elif args.agent:
        # Record agent response
        if not args.in_response_to:
            print("[ERROR] --in-response-to required when recording agent response")
            sys.exit(1)
        exp_id = agent.record_my_response(args.agent, args.in_response_to)
        print(f"[OK] Recorded agent response as Experience: {exp_id}")
        print(f"   In response to: {args.in_response_to}")
        print(f"   Text: {args.agent[:100]}{'...' if len(args.agent) > 100 else ''}")
        return exp_id

    elif args.observation:
        # Record observation
        exp_id = agent.record_observation(args.observation, args.observation_type)
        print(f"[OK] Recorded observation as Experience: {exp_id}")
        print(f"   Type: {args.observation_type}")
        print(f"   Text: {args.observation[:100]}{'...' if len(args.observation) > 100 else ''}")
        return exp_id

    else:
        print("[ERROR] Must provide --user, --agent, or --observation")
        parser.print_help()
        sys.exit(1)

if __name__ == "__main__":
    main()
