#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Governed Recall: Query Past Experiences Through Architecture

Routes recall through: Memory Control → Historical Integration → Relevance → Governance

Per ref 02: "Memory Control is first point of contact for all operations"
Per GOVERNED_RECALL_DESIGN.md: Must route through governed architecture

Usage:
  python governed_recall.py --query "what experiments did I share?"
  python governed_recall.py --query "what did we complete?" --topics "completion,fix,implementation"
"""

import sys
import json
from pathlib import Path
from datetime import datetime

# Fix encoding
sys.stdout.reconfigure(encoding='utf-8')

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent / "core"))

from memory_control import MemoryControl

def extract_topics_from_query(query_text: str) -> list:
    """Extract topic keywords from natural language query"""
    # Common question words to remove
    stopwords = {'what', 'when', 'where', 'why', 'how', 'did', 'do', 'does', 
                 'is', 'are', 'was', 'were', 'the', 'a', 'an', 'we', 'i', 
                 'you', 'me', 'my', 'your', 'about', 'from', 'to'}
    
    words = query_text.lower().replace('?', '').split()
    topics = [w for w in words if w not in stopwords and len(w) > 2]
    return topics

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Recall past experiences through governed architecture")
    parser.add_argument('--query', type=str, required=True,
                       help='Natural language query (e.g., "what experiments did I share?")')
    parser.add_argument('--topics', type=str, default=None,
                       help='Comma-separated topics to focus on (optional)')
    parser.add_argument('--limit', type=int, default=20,
                       help='Maximum results to return (default: 20)')
    parser.add_argument('--retention', type=str, default='durable',
                       help='Retention levels to search (durable, retained, ephemeral)')
    args = parser.parse_args()
    
    print("=" * 80)
    print("GOVERNED RECALL: Query Past Experiences")
    print("=" * 80)
    print()
    print(f"Query: {args.query}")
    print()
    
    script_dir = Path(__file__).parent
    memory_root = script_dir.parent
    
    mc = MemoryControl(memory_root)
    
    # Extract topics from query
    if args.topics:
        topics = [t.strip() for t in args.topics.split(',')]
    else:
        topics = extract_topics_from_query(args.query)
    
    print(f"[*] Extracted topics: {', '.join(topics)}")
    
    # Build query context
    query_context = {
        'type': 'user_question',
        'text': args.query,
        'entities': [],  # Could extract entity references
        'topics': topics
    }
    
    # Load current directions
    directions_dir = memory_root / "data" / "directions"
    current_directions = []
    for dir_file in directions_dir.glob("*.json"):
        with open(dir_file, 'r', encoding='utf-8') as f:
            direction = json.load(f)
            current_directions.append(direction.get('id'))
    
    print(f"[*] Current directions: {len(current_directions)}")
    print()
    
    # GOVERNED RECALL
    print("[*] Routing through governed architecture...")
    print("    Memory Control → Historical Integration → Relevance → Governance")
    print()
    
    retention_levels = args.retention.split(',')
    
    result = mc.recall_relevant_experiences(
        query_context=query_context,
        current_directions=current_directions,
        retention_levels=retention_levels,
        limit=args.limit
    )
    
    # Display results
    print("=" * 80)
    print("RECALL RESULTS")
    print("=" * 80)
    print()
    
    filtered_out = result['governance_decision']['filtered_by_relevance']
    relevant_count = result['candidates_considered'] - filtered_out

    print(f"Candidates considered: {result['candidates_considered']}")
    print(f"Filtered OUT (not relevant): {filtered_out}")
    print(f"Passed relevance filter: {relevant_count}")
    print(f"Results returned: {result['results_returned']}")
    print()
    
    if result['results_returned'] == 0:
        print("[INFO] No relevant experiences found for this query")
        print()
        print("Try:")
        print("  - Broadening your query")
        print("  - Adding more topics with --topics")
        print("  - Including 'retained' experiences with --retention durable,retained")
        return
    
    print("-" * 80)
    print("RELEVANT EXPERIENCES:")
    print("-" * 80)
    print()
    
    for i, exp in enumerate(result['experiences'], 1):
        exp_id = exp.get('id', 'unknown')
        received_at = exp.get('received_at', '')[:19]
        source = exp.get('source', 'unknown')
        content = exp.get('content', {}).get('text', 'N/A')
        retention = exp.get('retention_level', 'unknown')
        
        print(f"[{i}] {exp_id[:8]} | {received_at} | {source} | {retention}")
        
        # Show first 150 chars
        if len(content) > 150:
            print(f"    {content[:150]}...")
        else:
            print(f"    {content}")
        print()
    
    print("=" * 80)
    print("GOVERNED RECALL COMPLETE")
    print("=" * 80)
    print()
    print("[OK] Routed through Memory Control → Historical Integration → Governance")
    print("[OK] Relevance-filtered based on query context and current Directions")
    print()
    print("ARCHITECTURAL COMPLIANCE:")
    print("  Per ref 02: 'Memory Control is first point of contact'")
    print("  Per GOVERNED_RECALL_DESIGN.md: Recall must route through architecture")
    print("  ✓ Did NOT bypass governance with direct filesystem search")

if __name__ == '__main__':
    main()
