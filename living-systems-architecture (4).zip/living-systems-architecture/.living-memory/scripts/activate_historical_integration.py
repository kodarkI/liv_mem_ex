#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Activate Historical Integration for Current Conversation

Analyze recent DURABLE experiences and create typed event relationships:
- User corrections CONTRADICT prior statements
- Agent fixes PROVIDE_EVIDENCE_FOR problems
- Completions RESULT_FROM prior work
- Protocol violations CAUSE corrections

This activates Historical Integration per ref 11.
"""

import sys
import json
from pathlib import Path
from datetime import datetime, timedelta

# Fix encoding for Windows console
sys.stdout.reconfigure(encoding='utf-8')

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent / "core"))

from historical_integration import HistoricalIntegration

def load_recent_durable(memory_root: Path, hours: int = 2) -> list:
    """Load DURABLE experiences from last N hours."""
    exp_dir = memory_root / "data" / "experiences"
    cutoff = datetime.utcnow() - timedelta(hours=hours)
    
    durables = []
    for exp_file in exp_dir.glob("*.json"):
        with open(exp_file, 'r', encoding='utf-8') as f:
            exp = json.load(f)
            
            if exp.get('retention_level') != 'durable':
                continue
            
            received_at = exp.get('received_at', '')
            if not received_at:
                continue
            
            exp_time = datetime.fromisoformat(received_at.replace('Z', ''))
            if exp_time > cutoff:
                durables.append(exp)
    
    durables.sort(key=lambda x: x.get('received_at', ''))
    return durables

def main():
    print("=" * 80)
    print("ACTIVATING HISTORICAL INTEGRATION")
    print("=" * 80)
    print()
    
    script_dir = Path(__file__).parent
    memory_root = script_dir.parent
    
    hi = HistoricalIntegration(memory_root)
    
    # Load recent DURABLE experiences
    durables = load_recent_durable(memory_root, hours=2)
    print(f"[*] Loaded {len(durables)} DURABLE experiences from last 2 hours\n")
    
    relationships_created = 0
    
    # Pattern 1: User says "Actually..." → CONTRADICTS prior statement
    print("[1] Detecting CONTRADICTS relationships...")
    for i, exp in enumerate(durables):
        if exp.get('source') != 'user':
            continue
        
        text = exp.get('content', {}).get('text', '').lower()
        if 'actually' in text or 'wrong' in text or 'not working on' in text:
            # Find prior user statement to contradict
            for j in range(i-1, max(i-5, 0), -1):
                prior = durables[j]
                if prior.get('source') == 'user':
                    rel_id = hi.create_event_relation(
                        source_event_id=exp['id'],
                        predicate="CONTRADICTS",
                        target_event_id=prior['id'],
                        evidence=f"User correction: '{text[:50]}...' contradicts prior statement",
                        source="system",
                        status="effective"
                    )
                    if rel_id:
                        print(f"    Created CONTRADICTS: {exp['id'][:8]} → {prior['id'][:8]}")
                        relationships_created += 1
                    break
    
    # Pattern 2: Agent fixes/implements → PROVIDES_EVIDENCE_FOR problem
    print("\n[2] Detecting PROVIDES_EVIDENCE_FOR relationships...")
    for i, exp in enumerate(durables):
        if exp.get('source') != 'agent':
            continue
        
        text = exp.get('content', {}).get('text', '').lower()
        if 'fix' in text or 'implemented' in text or 'complete' in text:
            # This provides evidence for a problem or direction
            for j in range(max(0, i-3), i):
                prior = durables[j]
                prior_text = prior.get('content', {}).get('text', '').lower()
                if 'missing' in prior_text or 'gap' in prior_text or 'need' in prior_text:
                    rel_id = hi.create_event_relation(
                        source_event_id=exp['id'],
                        predicate="PROVIDES_EVIDENCE_FOR",
                        target_event_id=prior['id'],
                        evidence=f"Agent completion provides evidence of addressing identified need",
                        source="system",
                        status="supported"
                    )
                    if rel_id:
                        print(f"    Created PROVIDES_EVIDENCE_FOR: {exp['id'][:8]} → {prior['id'][:8]}")
                        relationships_created += 1
                    break
    
    # Pattern 3: Temporal order (OCCURS_AFTER)
    print("\n[3] Creating temporal OCCURS_AFTER relationships...")
    for i in range(1, min(10, len(durables))):
        current = durables[i]
        prior = durables[i-1]
        
        rel_id = hi.create_event_relation(
            source_event_id=current['id'],
            predicate="OCCURS_AFTER",
            target_event_id=prior['id'],
            evidence=f"Timestamp order: {current.get('received_at')} > {prior.get('received_at')}",
            source="system",
            status="effective"
        )
        if rel_id:
            relationships_created += 1
    print(f"    Created {min(9, len(durables)-1)} temporal relationships")
    
    # Pattern 4: Agent response → in_response_to (CONTINUES)
    print("\n[4] Detecting CONTINUES relationships...")
    for exp in durables:
        if exp.get('source') != 'agent':
            continue
        
        in_response_to = exp.get('content', {}).get('in_response_to')
        if in_response_to:
            rel_id = hi.create_event_relation(
                source_event_id=exp['id'],
                predicate="CONTINUES",
                target_event_id=in_response_to,
                evidence="Agent response continues conversation from user message",
                source="system",
                status="effective"
            )
            if rel_id:
                relationships_created += 1
    print(f"    Created CONTINUES relationships for agent responses")
    
    print()
    print("=" * 80)
    print(f"HISTORICAL INTEGRATION ACTIVATED")
    print(f"Total relationships created: {relationships_created}")
    print("=" * 80)
    print()
    print("[OK] Event relationships now connect experiences")
    print("[OK] Use traverse_event_chain() to reconstruct causal chains")
    print("[OK] Use analyze_event_relationship() to distinguish temporal vs causal")

if __name__ == '__main__':
    main()
