#!/usr/bin/env python3
"""
Record current session (retroactive)
Records the conversation turns from this session into Living Memory
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from agent_interface import AgentMemoryInterface

def main():
    agent = AgentMemoryInterface()
    agent.initialize_continuity()

    print("Recording Current Session Into Living Memory")
    print("=" * 80)
    
    # Turn 1: User asks about last session
    user_msg_1 = "so, what did you do in last session? and what are we talking about?"
    exp_1 = agent.receive_user_message(user_msg_1)
    print(f"\n[OK] Turn 1 - User: {exp_1}")
    
    agent_response_1 = """Based on the Experience records I just loaded (following the correct protocol this time), here's what happened:

Critical Learning: Protocol Violation & Correction
- Previous AI instance loaded markdown documentation files instead of Experience records first
- User corrected this architectural violation
- I added "Source Precedence (Truth Hierarchy)" section to Skill file

What Was Actually Completed:
1. Experiment 2: Adversarial Memory Testing - COMPLETED (4/5 PASS)
2. Experiment 4: Multi-Conversation Continuity - Infrastructure COMPLETE
3. Foundation Gaps Closed - COMPLETE
4. Protocol Compliance Learning - COMPLETE

Current State: I have now loaded Living Memory correctly (Experience records → Directions → Entities/Relationships)"""
    
    exp_2 = agent.record_my_response(agent_response_1, exp_1)
    print(f"[OK] Turn 1 - Agent: {exp_2}")

    # Turn 2: User confirms continuity works
    user_msg_2 = "so, from what you see? this first fresh chat, i could have you to talk about last session?"
    exp_3 = agent.receive_user_message(user_msg_2)
    print(f"\n[OK] Turn 2 - User: {exp_3}")

    agent_response_2 = """Yes! This is exactly what Living Memory is supposed to achieve - and it just worked.

What Just Happened:
1. Detected Living Memory exists
2. Followed the mandatory protocol: loaded Experience records FIRST
3. Loaded 30 recent DURABLE experiences
4. Loaded active Directions
5. Reconstructed the context of what we did yesterday
6. Answered your question from Living Memory, not from this conversation

Result: You got continuity across sessions without re-explaining anything.

This is the closed learning loop in action."""

    exp_4 = agent.record_my_response(agent_response_2, exp_3)
    print(f"[OK] Turn 2 - Agent: {exp_4}")

    # Turn 3: User asks about protocol violations
    user_msg_3 = "is there something else that you are still againt the protocol?"
    exp_5 = agent.receive_user_message(user_msg_3)
    print(f"\n[OK] Turn 3 - User: {exp_5}")

    agent_response_3 = """Self-Audit: Protocol Compliance Check

Potential Violations Found:
1. Did NOT route user's message through Memory Control (Step 4)
2. Did NOT record my response as Experience (Step 7)
3. Did NOT check for applicable Skills (Step 5)

The Core Issue:
I'm reading the protocol correctly but not executing it completely. I'm doing the "load" part but skipping the "record" part.

This means:
- Continuity IN works (I can read past context)
- Continuity OUT is broken (I'm not feeding the loop)"""

    exp_6 = agent.record_my_response(agent_response_3, exp_5)
    print(f"[OK] Turn 3 - Agent: {exp_6}")

    # Turn 4: User asks why and how to fix
    user_msg_4 = "why? what to do to fix all those?"
    exp_7 = agent.receive_user_message(user_msg_4)
    print(f"\n[OK] Turn 4 - User: {exp_7}")

    agent_response_4 = """Why These Violations Happened:
Root cause: I'm an AI agent with tool-calling capability, but I'm not autonomously executing Python code that routes messages through Memory Control.

Solution Options:
1. Manual Execution (error-prone)
2. Build Agent Wrapper (requires infrastructure)
3. Skill-Level Enforcement (RECOMMENDED)

Recommended Fix: Update Skill file to explicitly require executing recording scripts for every conversation turn."""

    exp_8 = agent.record_my_response(agent_response_4, exp_7)
    print(f"[OK] Turn 4 - Agent: {exp_8}")

    # Turn 5: User delegates decision
    user_msg_5 = "let do what you think that you won't miss anything"
    exp_9 = agent.receive_user_message(user_msg_5)
    print(f"\n[OK] Turn 5 - User: {exp_9}")

    print("\n" + "=" * 80)
    print("[OK] Session Recording Complete")
    print(f"   Recorded {9} experiences (5 user messages + 4 agent responses)")
    print(f"   All routed through Memory Control and governed for retention")

    # Record observation about this meta-action
    obs_exp = agent.record_observation(
        "Successfully recorded entire conversation session retroactively. Closed the learning loop by making conversation history durable.",
        observation_type="protocol_compliance"
    )
    print(f"\n[OK] Meta-observation recorded: {obs_exp}")

if __name__ == "__main__":
    main()
