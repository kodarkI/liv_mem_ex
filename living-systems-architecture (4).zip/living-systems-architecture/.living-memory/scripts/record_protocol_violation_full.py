#!/usr/bin/env python3
"""
Record protocol violation and user's teaching moment
This becomes DURABLE evidence for future AI instances
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from memory_control import MemoryControl
from continuity_loader import ContinuityLoader
import json
from datetime import datetime

loader = ContinuityLoader(Path(__file__).parent)
context = loader.load_bootstrap_context()

user_id = context['entities']['user']
agent_id = context['entities']['agent']
conversation_id = context['entities']['conversation']

mc = MemoryControl(Path(__file__).parent)

print("=" * 80)
print("RECORDING PROTOCOL VIOLATION AND CORRECTION")
print("=" * 80)

# 1. User's first call-out
exp1_id = mc.receive_experience({
    'type': 'user_message',
    'from_entity': user_id,
    'to_entity': agent_id,
    'in_context': conversation_id,
    'text': "don't you have records of our last conversations? even when follow protocol?",
    'intent': 'protocol_violation_callout',
    'tags': ['correction', 'protocol_enforcement', 'AI_failure_pattern']
})

mc.update_retention(exp1_id, {
    'level': 'durable',
    'reason': 'User caught AI violating Source Precedence protocol. AI read markdown files '
              'instead of Experience records as primary truth. Critical teaching moment.',
    'decided_at': datetime.utcnow().isoformat() + 'Z',
    'decided_by': 'agent_governance',
    'next_review_at': None
})

print(f"✅ Recorded first call-out: {exp1_id[:8]}")

# 2. User's critical question about FUTURE instances
exp2_id = mc.receive_experience({
    'type': 'user_message',
    'from_entity': user_id,
    'to_entity': agent_id,
    'in_context': conversation_id,
    'text': "how can i say for you to look at experience records? you only follow one even "
            "when i ask to check on protocal? and not to check md first? do i have to mention "
            "that you have to get experience records if not, just check it until finding one? "
            "not to go to md when records failed?",
    'intent': 'requirement_for_future_behavior',
    'tags': ['protocol_requirement', 'cross_conversation_behavior', 'AI_learning']
})

mc.update_retention(exp2_id, {
    'level': 'durable',
    'reason': 'User identifies SYSTEMIC problem: AI needs to load Experience records FIRST without '
              'being told. User should NOT have to re-explain Source Precedence every conversation. '
              'This defines required AI behavior for ALL future conversations.',
    'decided_at': datetime.utcnow().isoformat() + 'Z',
    'decided_by': 'agent_governance',
    'next_review_at': None
})

print(f"✅ Recorded behavior requirement: {exp2_id[:8]}")

# 3. User's question about re-explaining
exp3_id = mc.receive_experience({
    'type': 'user_message',
    'from_entity': user_id,
    'to_entity': agent_id,
    'in_context': conversation_id,
    'text': "i don't ask you just this time but i ask how to do with new you? "
            "do i have to explain to you again about violent the protocol?",
    'intent': 'cross_conversation_continuity_requirement',
    'tags': ['protocol_compliance', 'future_AI_instances', 'no_re_explanation']
})

mc.update_retention(exp3_id, {
    'level': 'durable',
    'reason': 'User defines SUCCESS criteria: Future AI instances must follow protocol WITHOUT '
              're-explanation. User should NOT have to teach the same lesson twice. This is a test '
              'of Living Memory effectiveness - does learning persist across conversations?',
    'decided_at': datetime.utcnow().isoformat() + 'Z',
    'decided_by': 'agent_governance',
    'next_review_at': None
})

print(f"✅ Recorded re-explanation question: {exp3_id[:8]}")

print("\n" + "=" * 80)
print("GOVERNANCE SUMMARY")
print("=" * 80)
print("\nRecorded 3 DURABLE experiences:")
print("  1. Protocol violation call-out")
print("  2. Behavior requirement for future AI")
print("  3. No re-explanation expectation")
print("\nThese establish:")
print("  - AI MUST load Experience records before markdown")
print("  - User expects this WITHOUT being told")
print("  - Future AI instances must learn from this failure")
print("\n" + "=" * 80)
