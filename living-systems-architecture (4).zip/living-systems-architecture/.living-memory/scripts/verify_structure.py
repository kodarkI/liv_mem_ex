#!/usr/bin/env python3
"""Verify Living Memory structure after cleanup"""
from pathlib import Path

root = Path(__file__).parent.parent

print("=" * 80)
print("LIVING MEMORY STRUCTURE VERIFICATION")
print("=" * 80)

# Check main folders
print("\n[1] Main Folder Structure:")
expected_folders = ['core', 'data', 'tests', 'scripts', 'docs', 'archive']
for folder in expected_folders:
    exists = (root / folder).exists()
    status = "[OK]" if exists else "[MISSING]"
    print(f"  {status} {folder}/")

# Check core files
print("\n[2] Core Implementation Files:")
core_files = ['memory_control.py', 'memory_governance.py', 'continuity_loader.py', 
              'agent_interface.py', 'historical_integration.py']
for fname in core_files:
    exists = (root / 'core' / fname).exists()
    status = "[OK]" if exists else "[MISSING]"
    print(f"  {status} core/{fname}")

# Check data integrity
print("\n[3] Data Integrity:")
data_dir = root / 'data'
if data_dir.exists():
    totals = {}
    for subfolder in data_dir.iterdir():
        if subfolder.is_dir():
            count = len(list(subfolder.iterdir()))
            totals[subfolder.name] = count
            print(f"  [OK] data/{subfolder.name}/: {count} files")
    
    total_files = sum(totals.values())
    print(f"\n  TOTAL DATA FILES: {total_files}")
    
    if total_files >= 300:
        print("  [OK] All data intact (expected ~304 files)")
    else:
        print(f"  [WARNING] Expected ~304 files, found {total_files}")
else:
    print("  [ERROR] data/ folder not found!")

# Test import
print("\n[4] Import Test:")
import sys
sys.path.insert(0, str(root / 'core'))

try:
    from agent_interface import AgentMemoryInterface
    print("  [OK] Successfully imported AgentMemoryInterface")
    
    agent = AgentMemoryInterface()
    print("  [OK] Successfully created instance")
    
    context = agent.initialize_continuity()
    print("  [OK] Successfully loaded Living Memory")
    
except Exception as e:
    print(f"  [ERROR] {e}")

print("\n" + "=" * 80)
print("VERIFICATION COMPLETE")
print("=" * 80)
