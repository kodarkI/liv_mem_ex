#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Validate Tool Usage: Check if AI used appropriate tools for user questions

Per SKILL.md Step 2.5:
- RECALL_PAST questions → Must use governed_recall.py
- WHY questions → Must use explain_why.py  
- CORRECTIONS → Must use activate_truth_status_evolution.py

This script detects violations and records them as DURABLE experiences.
"""

import sys
import json
import re
from pathlib import Path
from datetime import datetime, timedelta

# Fix encoding
sys.stdout.reconfigure(encoding='utf-8')

def load_recent_experiences(memory_root: Path, minutes: int = 10):
    """Load experiences from last N minutes"""
    exp_dir = memory_root / "data" / "experiences"
    cutoff = datetime.utcnow() - timedelta(minutes=minutes)
    
    recent = []
    for exp_file in exp_dir.glob("*.json"):
        with open(exp_file, 'r', encoding='utf-8') as f:
            exp = json.load(f)
            received_at = exp.get('received_at', '')
            if not received_at:
                continue
            
            exp_time = datetime.fromisoformat(received_at.replace('Z', ''))
            if exp_time > cutoff:
                recent.append(exp)
    
    recent.sort(key=lambda x: x.get('received_at', ''))
    return recent

def classify_question(text: str) -> str:
    """Classify user question type"""
    text_lower = text.lower()
    
    # RECALL_PAST patterns
    recall_patterns = [
        r'\bwhat\b.*\b(experiment|did|share|complete|fix|implement)',
        r'\btell me about\b',
        r'\bshow me\b',
        r'\blist\b.*\b(experiment|feature|change)',
    ]
    
    # WHY_QUESTION patterns
    why_patterns = [
        r'\bwhy\b',
        r'\bhow did\b.*\bhappen\b',
        r'\bwhat caused\b',
        r'\bexplain\b',
    ]
    
    # CORRECTION patterns
    correction_patterns = [
        r'\bactually\b',
        r'\bno,?\s+i\s+(meant|am|was)\b',
        r'\bi\'?m\s+not\s+working\s+on\b',
        r'\bcorrection\b',
    ]
    
    for pattern in recall_patterns:
        if re.search(pattern, text_lower):
            return "RECALL_PAST"
    
    for pattern in why_patterns:
        if re.search(pattern, text_lower):
            return "WHY_QUESTION"
    
    for pattern in correction_patterns:
        if re.search(pattern, text_lower):
            return "CORRECTION"
    
    return "OTHER"

def check_tool_usage(experiences: list) -> list:
    """Check if appropriate tools were used"""
    violations = []
    
    for i, exp in enumerate(experiences):
        if exp.get('source') != 'user':
            continue
        
        text = exp.get('content', {}).get('text', '')
        question_type = classify_question(text)
        
        if question_type == "OTHER":
            continue  # No tool required
        
        # Find agent response
        agent_response = None
        for j in range(i+1, min(i+3, len(experiences))):
            if experiences[j].get('source') == 'agent':
                agent_response = experiences[j]
                break
        
        if not agent_response:
            continue  # No response yet
        
        response_text = agent_response.get('content', {}).get('text', '')
        
        # Check if appropriate tool was mentioned/used
        tool_used = False
        
        if question_type == "RECALL_PAST":
            if "governed_recall" in response_text or "recall_relevant_experiences" in response_text:
                tool_used = True
        
        elif question_type == "WHY_QUESTION":
            if "explain_why" in response_text or "traverse_event_chain" in response_text:
                tool_used = True
        
        elif question_type == "CORRECTION":
            if "activate_truth_status_evolution" in response_text or "QUALIFIED" in response_text:
                tool_used = True
        
        if not tool_used:
            violations.append({
                "user_exp_id": exp['id'],
                "agent_exp_id": agent_response['id'],
                "question_type": question_type,
                "user_text": text[:100],
                "expected_tool": {
                    "RECALL_PAST": "governed_recall.py",
                    "WHY_QUESTION": "explain_why.py",
                    "CORRECTION": "activate_truth_status_evolution.py"
                }[question_type]
            })
    
    return violations

def main():
    print("=" * 80)
    print("VALIDATE TOOL USAGE")
    print("=" * 80)
    print()
    
    script_dir = Path(__file__).parent
    memory_root = script_dir.parent
    
    experiences = load_recent_experiences(memory_root, minutes=10)
    print(f"[*] Checking {len(experiences)} recent experiences\n")
    
    violations = check_tool_usage(experiences)
    
    if not violations:
        print("[OK] No tool usage violations detected")
        print()
        print("=" * 80)
        print("TOOL USAGE VALIDATION: PASS")
        print("=" * 80)
        sys.exit(0)
    
    print(f"[VIOLATION] Found {len(violations)} tool usage violation(s)\n")
    
    for v in violations:
        print(f"User question ({v['question_type']}): {v['user_text']}...")
        print(f"Expected tool: {v['expected_tool']}")
        print(f"Tool was NOT used in agent response")
        print()
    
    print("=" * 80)
    print(f"TOOL USAGE VALIDATION: FAIL ({len(violations)} violations)")
    print("=" * 80)
    print()
    print("REQUIRED ACTION:")
    print("  Update response to use appropriate tool per SKILL.md Step 2.5")
    print()
    
    sys.exit(1)

if __name__ == '__main__':
    main()
