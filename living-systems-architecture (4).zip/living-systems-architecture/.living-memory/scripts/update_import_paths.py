#!/usr/bin/env python3
"""
Update import paths to reflect new structure
All scripts now import from core/ instead of root
"""
import re
from pathlib import Path

def update_file_imports(file_path: Path):
    """Update import statements in a Python file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        original_content = content
        
        # Update sys.path.insert to point to core/
        content = re.sub(
            r"sys\.path\.insert\(0, str\(Path\(__file__\)\.parent\)\)",
            "sys.path.insert(0, str(Path(__file__).parent.parent / 'core'))",
            content
        )
        
        # Update memory_root paths to use parent directory
        content = re.sub(
            r"memory_root = Path\(__file__\)\.parent",
            "memory_root = Path(__file__).parent.parent",
            content
        )
        
        # Update direct imports if needed
        patterns_to_update = [
            (r"from memory_control import", "import sys; from pathlib import Path; sys.path.insert(0, str(Path(__file__).parent.parent / 'core')); from memory_control import"),
            (r"from memory_governance import", "import sys; from pathlib import Path; sys.path.insert(0, str(Path(__file__).parent.parent / 'core')); from memory_governance import"),
            (r"from continuity_loader import", "import sys; from pathlib import Path; sys.path.insert(0, str(Path(__file__).parent.parent / 'core')); from continuity_loader import"),
            (r"from agent_interface import", "import sys; from pathlib import Path; sys.path.insert(0, str(Path(__file__).parent.parent / 'core')); from agent_interface import"),
        ]
        
        if content != original_content:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
            
    except Exception as e:
        print(f"  [ERROR] {file_path.name}: {e}")
        return False
    
    return False

def main():
    root = Path(__file__).parent.parent
    
    print("=" * 80)
    print("Updating Import Paths")
    print("=" * 80)
    
    # Update all Python files in scripts/
    scripts_dir = root / "scripts"
    updated_count = 0
    
    print("\nUpdating scripts/...")
    for py_file in scripts_dir.glob("*.py"):
        if update_file_imports(py_file):
            print(f"  [OK] {py_file.name}")
            updated_count += 1
    
    # Update all Python files in tests/
    tests_dir = root / "tests"
    print("\nUpdating tests/...")
    for py_file in tests_dir.glob("*.py"):
        if update_file_imports(py_file):
            print(f"  [OK] {py_file.name}")
            updated_count += 1
    
    print("\n" + "=" * 80)
    print(f"[COMPLETE] Updated {updated_count} files")
    print("=" * 80)

if __name__ == "__main__":
    main()
