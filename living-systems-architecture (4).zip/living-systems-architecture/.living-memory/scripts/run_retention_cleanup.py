#!/usr/bin/env python3
"""
Master retention cleanup orchestrator
Runs all cleanup policies in correct order
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import json
from datetime import datetime
from cleanup_ephemeral import cleanup_ephemeral_experiences
from cleanup_archived import cleanup_archived_experiences

def load_retention_policy(memory_root: Path) -> dict:
    """Load retention policy configuration"""
    policy_file = memory_root / "retention_policy.json"
    
    if not policy_file.exists():
        print("[WARNING] No retention_policy.json found, using defaults")
        return {
            "retention_levels": {
                "ephemeral": {"prune_after_hours": 24},
                "archived": {"prune_after_days": 90}
            }
        }
    
    with open(policy_file, 'r') as f:
        return json.load(f)

def run_full_cleanup(memory_root: Path, dry_run: bool = True):
    """
    Run complete retention cleanup cycle
    
    Order:
    1. EPHEMERAL → ARCHIVED/PRUNED (aged out)
    2. RETAINED → ARCHIVED (review time passed, no longer recent)
    3. ARCHIVED → PRUNED (retention period expired)
    """
    policy = load_retention_policy(memory_root)
    
    print("="*70)
    print("LIVING MEMORY RETENTION CLEANUP")
    print("="*70)
    print(f"Policy version: {policy.get('policy_version', 'unknown')}")
    print(f"Mode: {'DRY RUN (safe)' if dry_run else 'LIVE (destructive)'}")
    print(f"Time: {datetime.utcnow().isoformat()}Z")
    print("="*70 + "\n")
    
    # Phase 1: EPHEMERAL cleanup
    print("\n" + "="*70)
    print("PHASE 1: EPHEMERAL Experience Cleanup")
    print("="*70)
    cleanup_ephemeral_experiences(memory_root, dry_run=dry_run)
    
    # Phase 2: ARCHIVED cleanup
    print("\n" + "="*70)
    print("PHASE 2: ARCHIVED Experience Cleanup")
    print("="*70)
    archive_retention_days = policy.get("retention_levels", {}).get("archived", {}).get("prune_after_days", 90)
    cleanup_archived_experiences(memory_root, archive_retention_days, dry_run=dry_run)
    
    # Summary
    print("\n" + "="*70)
    print("RETENTION CLEANUP COMPLETE")
    print("="*70)
    
    if dry_run:
        print("\n[!] DRY RUN MODE - No files were modified")
        print("Run with --live flag to execute actual cleanup")
    else:
        print("\n[OK] LIVE MODE - Cleanup executed")
        print("Tombstones preserved in data/tombstones/")
    
    print("\nNext steps:")
    print("  1. Review tombstones to verify nothing important was pruned")
    print("  2. Monitor retention decisions to tune policy")
    print("  3. Schedule periodic cleanup (cron/Task Scheduler)")
    print()

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Run Living Memory retention cleanup",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Dry run (safe, shows what would be cleaned)
  python run_retention_cleanup.py
  
  # Live run (actually cleans files)
  python run_retention_cleanup.py --live
  
  # Dry run with custom policy check
  python run_retention_cleanup.py --policy-check
        """
    )
    parser.add_argument("--live", action="store_true", 
                       help="Actually perform cleanup (default is dry run)")
    parser.add_argument("--policy-check", action="store_true",
                       help="Show retention policy and exit")
    
    args = parser.parse_args()
    
    memory_root = Path(__file__).parent.parent
    
    if args.policy_check:
        policy = load_retention_policy(memory_root)
        print(json.dumps(policy, indent=2))
        sys.exit(0)
    
    run_full_cleanup(memory_root, dry_run=not args.live)
