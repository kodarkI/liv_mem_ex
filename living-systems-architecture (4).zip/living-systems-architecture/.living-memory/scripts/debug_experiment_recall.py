#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Debug: Why governed recall isn't finding all experiments"""
import sys
import io
from pathlib import Path
import json

# Fix Windows encoding
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

sys.path.insert(0, str(Path(__file__).parent.parent / 'core'))

from memory_control import MemoryControl
from memory_governance import MemoryGovernance

print("=" * 80)
print("DEBUG: Finding ALL experiment-related DURABLE experiences")
print("=" * 80)

# Step 1: Manually find ALL DURABLE experiences mentioning experiments
experiences_dir = Path('.living-memory/data/experiences')
all_durable = []

for exp_file in experiences_dir.glob('*.json'):
    with open(exp_file, 'r', encoding='utf-8') as f:
        exp = json.load(f)
    
    if exp.get('retention_level') == 'durable':
        all_durable.append(exp)

print(f"\nTotal DURABLE experiences: {len(all_durable)}")

# Find those mentioning "experiment" (case-insensitive, broad search)
experiment_related = []
for exp in all_durable:
    content = exp.get('content', {})
    text = content.get('text', content.get('observation_type', '')).lower()
    content_type = content.get('type', '')
    
    # Check multiple criteria
    if 'experiment' in text or content_type == 'test_execution':
        experiment_related.append(exp)

print(f"DURABLE experiences mentioning 'experiment' or type=test_execution: {len(experiment_related)}")

print("\n" + "=" * 80)
print("ALL EXPERIMENT-RELATED DURABLE EXPERIENCES:")
print("=" * 80)

for i, exp in enumerate(sorted(experiment_related, key=lambda e: e['occurred_at']), 1):
    print(f"\n[{i}] {exp['occurred_at'][:19]} | {exp['source']} | ID: {exp['id'][:8]}")
    print(f"    Retention: {exp['retention_level']}")
    print(f"    Type: {exp['content'].get('type', 'N/A')}")
    text = exp['content'].get('text', exp['content'].get('observation_type', 'N/A'))
    print(f"    Text: {text[:150]}")

# Step 2: Test governed recall with same query
print("\n\n" + "=" * 80)
print("GOVERNED RECALL TEST:")
print("=" * 80)

mc = MemoryControl('.living-memory')
governance = MemoryGovernance('.living-memory')

query_context = {
    'type': 'user_question',
    'text': 'experiments we did',
    'entities': [],
    'topics': ['experiment']  # Simplified - just 'experiment'
}

print(f"\nQuery: {query_context['text']}")
print(f"Topics: {query_context['topics']}")

# Test relevance scoring for EACH experiment-related experience
print(f"\n" + "-" * 80)
print("RELEVANCE SCORING FOR EACH:")
print("-" * 80)

for exp in experiment_related:
    relevance = governance.evaluate_relevance_for_recall(
        exp,
        query_context,
        []  # No directions filter
    )
    
    print(f"\nID: {exp['id'][:8]} | Date: {exp['occurred_at'][:19]}")
    print(f"  Is Relevant: {relevance['is_relevant']}")
    print(f"  Score: {relevance['relevance_score']:.2f}")
    print(f"  Reason: {relevance['reason']}")
    text = exp['content'].get('text', exp['content'].get('observation_type', 'N/A'))
    print(f"  Text: {text[:100]}...")

# Step 3: Run full governed recall
print(f"\n" + "=" * 80)
print("FULL GOVERNED RECALL:")
print("=" * 80)

results = mc.recall_relevant_experiences(
    query_context=query_context,
    current_directions=[],
    retention_levels=['durable'],
    limit=50
)

print(f"\nCandidates: {results['candidates_considered']}")
print(f"Filtered by relevance: {results['governance_decision']['filtered_by_relevance']}")
print(f"Returned: {results['results_returned']}")

# Count how many are experiment-related
experiment_ids = {e['id'] for e in experiment_related}
found_ids = {e['id'] for e in results['experiences']}
found_experiments = experiment_ids.intersection(found_ids)

print(f"\nExperiment-related in results: {len(found_experiments)} / {len(experiment_related)}")
print(f"Missing experiments: {len(experiment_related) - len(found_experiments)}")

if len(found_experiments) < len(experiment_related):
    missing = experiment_ids - found_ids
    print(f"\nMISSING EXPERIMENT IDs:")
    for exp_id in missing:
        missing_exp = next(e for e in experiment_related if e['id'] == exp_id)
        print(f"  {exp_id[:8]} | {missing_exp['occurred_at'][:19]}")
        print(f"    Text: {missing_exp['content'].get('text', 'N/A')[:100]}...")
