#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test if limit parameter actually bypasses governance filtering
"""
import sys
from pathlib import Path

# Fix encoding
sys.stdout.reconfigure(encoding='utf-8')

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent / "core"))

from memory_control import MemoryControl

def main():
    print("=" * 80)
    print("TEST: Limit Parameter Behavior")
    print("=" * 80)
    print()
    
    script_dir = Path(__file__).parent
    memory_root = script_dir.parent
    
    mc = MemoryControl(memory_root)
    
    # Test query with known low relevance count
    query_context = {
        'type': 'user_question',
        'text': 'test',
        'entities': [],
        'topics': ['test']
    }
    
    current_directions = []
    
    # Test 1: Low limit (should return min(relevant, limit))
    print("TEST 1: limit=5")
    result1 = mc.recall_relevant_experiences(
        query_context=query_context,
        current_directions=current_directions,
        retention_levels=["durable"],
        limit=5
    )
    
    print(f"  Candidates considered: {result1['candidates_considered']}")
    print(f"  Filtered OUT by relevance: {result1['governance_decision']['filtered_by_relevance']}")
    relevant_count_1 = result1['candidates_considered'] - result1['governance_decision']['filtered_by_relevance']
    print(f"  Relevant count (PASSED filter): {relevant_count_1}")
    print(f"  Results returned: {result1['results_returned']}")
    print(f"  Actual results in list: {len(result1['experiences'])}")
    print(f"  BUG CHECK: results_returned ({result1['results_returned']}) should be <= relevant_count ({relevant_count_1})")
    print()
    
    # Test 2: High limit (should return all relevant, not exceed)
    print("TEST 2: limit=100")
    result2 = mc.recall_relevant_experiences(
        query_context=query_context,
        current_directions=current_directions,
        retention_levels=["durable"],
        limit=100
    )
    
    print(f"  Candidates considered: {result2['candidates_considered']}")
    print(f"  Filtered by relevance: {result2['governance_decision']['filtered_by_relevance']}")
    relevant_count_2 = result2['candidates_considered'] - result2['governance_decision']['filtered_by_relevance']
    print(f"  Relevant count: {relevant_count_2}")
    print(f"  Results returned: {result2['results_returned']}")
    print(f"  Actual results in list: {len(result2['experiences'])}")
    print()
    
    # Verification
    print("=" * 80)
    print("VERIFICATION")
    print("=" * 80)
    print()
    
    # Check Test 1
    if result1['results_returned'] == len(result1['experiences']):
        print(f"✓ Test 1: Count matches actual list ({result1['results_returned']} == {len(result1['experiences'])})")
    else:
        print(f"✗ Test 1: Count MISMATCH ({result1['results_returned']} != {len(result1['experiences'])})")
    
    if result1['results_returned'] <= min(5, relevant_count_1):
        print(f"✓ Test 1: Returned <= min(limit, relevant) ({result1['results_returned']} <= {min(5, relevant_count_1)})")
    else:
        print(f"✗ Test 1: EXCEEDED expected ({result1['results_returned']} > {min(5, relevant_count_1)})")
    
    print()
    
    # Check Test 2 - THIS IS THE CRITICAL TEST
    if result2['results_returned'] == len(result2['experiences']):
        print(f"✓ Test 2: Count matches actual list ({result2['results_returned']} == {len(result2['experiences'])})")
    else:
        print(f"✗ Test 2: Count MISMATCH ({result2['results_returned']} != {len(result2['experiences'])})")
    
    if result2['results_returned'] <= relevant_count_2:
        print(f"✓ Test 2: Returned <= relevant count ({result2['results_returned']} <= {relevant_count_2})")
        print(f"  PASS: Limit did NOT bypass governance")
    else:
        print(f"✗ Test 2: EXCEEDED relevant count ({result2['results_returned']} > {relevant_count_2})")
        print(f"  FAIL: Limit BYPASSED governance!")
    
    print()
    
    # Expected behavior
    print("EXPECTED: results_returned = min(limit, relevant_count)")
    print(f"  Test 1: min(5, {relevant_count_1}) = {min(5, relevant_count_1)}, actual = {result1['results_returned']}")
    print(f"  Test 2: min(100, {relevant_count_2}) = {min(100, relevant_count_2)}, actual = {result2['results_returned']}")
    print()
    
    # Overall verdict
    test1_pass = result1['results_returned'] == len(result1['experiences']) and result1['results_returned'] <= min(5, relevant_count_1)
    test2_pass = result2['results_returned'] == len(result2['experiences']) and result2['results_returned'] <= relevant_count_2
    
    if test1_pass and test2_pass:
        print("=" * 80)
        print("✓ ALL TESTS PASS - No limit bypass detected")
        print("=" * 80)
        return 0
    else:
        print("=" * 80)
        print("✗ TESTS FAILED - Limit behavior incorrect")
        print("=" * 80)
        return 1

if __name__ == '__main__':
    exit(main())
