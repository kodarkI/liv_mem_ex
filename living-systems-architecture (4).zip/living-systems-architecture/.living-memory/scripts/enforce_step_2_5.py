#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Enforce Step 2.5: Check if AI detected question type and used appropriate tool

This script runs BEFORE the AI drafts a response to enforce protocol.
It analyzes the user's latest message and determines which tool MUST be executed.

Exit codes:
  0 = No tool required (OTHER question type)
  1 = Tool required but validation will happen after response
  
Prints to stdout the required action for the AI to take.
"""

import sys
import json
import re
from pathlib import Path
from datetime import datetime, timedelta

# Fix encoding
sys.stdout.reconfigure(encoding='utf-8')

def classify_question(text: str) -> dict:
    """Classify user question and return required action"""
    text_lower = text.lower()
    
    # RECALL_PAST patterns
    recall_patterns = [
        r'\bwhat\b.*\b(experiment|did|share|complete|fix|implement|create|build)',
        r'\btell me about\b',
        r'\bshow me\b',
        r'\blist\b',
        r'\bwhat.*we.*do\b',
        r'\bwhat.*i.*share\b',
    ]
    
    # WHY_QUESTION patterns
    why_patterns = [
        r'\bwhy\b',
        r'\bhow did\b.*\bhappen\b',
        r'\bwhat caused\b',
        r'\bexplain why\b',
    ]
    
    # CORRECTION patterns
    correction_patterns = [
        r'\bactually\b',
        r'\bno,?\s+i\s+(meant|am|was)\b',
        r'\bi\'?m\s+not\s+working\s+on\b',
        r'\bcorrection\b',
    ]
    
    for pattern in recall_patterns:
        if re.search(pattern, text_lower):
            return {
                'type': 'RECALL_PAST',
                'tool': 'governed_recall.py',
                'command': f'python .living-memory/scripts/governed_recall.py --query "{text[:100]}" --limit 10',
                'mandatory': True
            }
    
    for pattern in why_patterns:
        if re.search(pattern, text_lower):
            keywords = ' '.join([w for w in text.split() if len(w) > 3][:5])
            return {
                'type': 'WHY_QUESTION',
                'tool': 'explain_why.py',
                'command': f'python .living-memory/scripts/explain_why.py --question "{text[:80]}" --search "{keywords}"',
                'mandatory': True
            }
    
    for pattern in correction_patterns:
        if re.search(pattern, text_lower):
            return {
                'type': 'CORRECTION',
                'tool': 'activate_truth_status_evolution.py',
                'command': 'python .living-memory/scripts/activate_truth_status_evolution.py',
                'mandatory': True
            }
    
    return {
        'type': 'OTHER',
        'tool': None,
        'command': None,
        'mandatory': False
    }

def get_latest_user_message(memory_root: Path):
    """Get the most recent user message"""
    exp_dir = memory_root / "data" / "experiences"
    cutoff = datetime.utcnow() - timedelta(minutes=5)
    
    recent_user = []
    for exp_file in exp_dir.glob("*.json"):
        with open(exp_file, 'r', encoding='utf-8') as f:
            exp = json.load(f)
            if exp.get('source') != 'user':
                continue
            
            received_at = exp.get('received_at', '')
            if not received_at:
                continue
            
            exp_time = datetime.fromisoformat(received_at.replace('Z', ''))
            if exp_time > cutoff:
                recent_user.append((exp_time, exp))
    
    if not recent_user:
        return None
    
    recent_user.sort(reverse=True)
    return recent_user[0][1]

def main():
    script_dir = Path(__file__).parent
    memory_root = script_dir.parent
    
    print("=" * 80)
    print("STEP 2.5 ENFORCEMENT: Question Type Detection")
    print("=" * 80)
    print()
    
    # Get latest user message
    user_msg = get_latest_user_message(memory_root)
    
    if not user_msg:
        print("[INFO] No recent user message found")
        sys.exit(0)
    
    text = user_msg.get('content', {}).get('text', '')
    exp_id = user_msg.get('id', 'unknown')
    
    print(f"[*] User message: {text[:100]}{'...' if len(text) > 100 else ''}")
    print(f"[*] Experience ID: {exp_id}")
    print()
    
    # Classify question
    result = classify_question(text)
    
    print(f"[CLASSIFICATION] Type: {result['type']}")
    print()
    
    if result['type'] == 'OTHER':
        print("[OK] No specific tool required for this question type")
        print("[OK] AI may draft response normally")
        print()
        print("=" * 80)
        print("STEP 2.5: PASS (No tool required)")
        print("=" * 80)
        sys.exit(0)
    
    # Tool required
    print(f"[REQUIRED] Tool: {result['tool']}")
    print(f"[REQUIRED] Command: {result['command']}")
    print()
    print("=" * 80)
    print("STEP 2.5: TOOL REQUIRED")
    print("=" * 80)
    print()
    print("AI MUST execute the following command BEFORE drafting response:")
    print()
    print(f"  {result['command']}")
    print()
    print("Per SKILL.md Step 2.5:")
    print(f"  - Question type: {result['type']}")
    print(f"  - Required tool: {result['tool']}")
    print("  - MANDATORY, not optional")
    print("  - Use results in response")
    print("  - DO NOT bypass with manual search")
    print()
    
    # Exit with code 1 to signal tool is required
    # (Validation happens after response with validate_tool_usage.py)
    sys.exit(1)

if __name__ == '__main__':
    main()
