#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MANDATORY INITIALIZATION SCRIPT
This script MUST run before AI responds to ANY user message.
It enforces protocol compliance by loading Living Memory in the CORRECT order.

Usage: python .living-memory/scripts/initialize_context.py
Output: Human-readable context summary for AI to read
"""

import sys
import io
from pathlib import Path

# Fix Windows console encoding for Unicode
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

sys.path.insert(0, str(Path(__file__).parent.parent))

from core.continuity_loader import ContinuityLoader
import json
from datetime import datetime

def main():
    print("=" * 80)
    print("MANDATORY INITIALIZATION - Loading Living Memory")
    print("=" * 80)
    
    loader = ContinuityLoader('.living-memory')
    
    # Step 1: Bootstrap
    bootstrap_file = Path('.living-memory/bootstrap_context.json')
    with open(bootstrap_file, 'r') as f:
        bootstrap = json.load(f)
    print(f"\n[1] Bootstrap loaded: {bootstrap['bootstrapped_at']}")
    
    # Step 2: Active Directions
    directions_dir = Path('.living-memory/data/directions')
    directions = []
    for d in directions_dir.glob('*.json'):
        with open(d, 'r') as f:
            direction = json.load(f)
            if direction['status'] == 'active':
                directions.append(direction)
    print(f"\n[2] Active Directions ({len(directions)}):")
    for d in directions:
        print(f"    - {d['intent']}")
    
    # Step 3: DURABLE Experiences (REQUIRED - LOAD BEFORE ANYTHING ELSE)
    print(f"\n[3] DURABLE Experiences (CRITICAL - PRIMARY SOURCE OF TRUTH):")
    experiences_dir = Path('.living-memory/data/experiences')

    all_experiences = []
    for exp_file in experiences_dir.glob('*.json'):
        with open(exp_file, 'r') as f:
            exp = json.load(f)
            all_experiences.append(exp)

    # Sort by timestamp
    all_experiences.sort(key=lambda e: e['occurred_at'], reverse=True)

    # Filter DURABLE only
    durable = [e for e in all_experiences if e.get('retention_level') == 'durable']

    print(f"    Total experiences: {len(all_experiences)}")
    print(f"    DURABLE experiences: {len(durable)}")

    # Show last 10 DURABLE with FULL TEXT (no truncation)
    print(f"\n    Last 10 DURABLE experiences (FULL TEXT - NO TRUNCATION):")
    print(f"    " + "=" * 76)
    for i, exp in enumerate(durable[:10], 1):
        source = exp['source']
        timestamp = exp['occurred_at'][:19]
        exp_id = exp['id'][:8]
        content = exp['content']
        text = content.get('text', content.get('observation_type', content.get('type', 'N/A')))

        print(f"\n    [{i}] {timestamp} | {source} | ID:{exp_id}")
        print(f"    {text}")
        print(f"    " + "-" * 76)

    # Show next 10 DURABLE with truncation for overview
    if len(durable) > 10:
        print(f"\n    Next 10 DURABLE experiences (truncated overview):")
        for exp in durable[10:20]:
            source = exp['source']
            timestamp = exp['occurred_at'][:19]
            content = exp['content']
            text = content.get('text', content.get('observation_type', content.get('type', 'N/A')))
            text_display = text[:70] + "..." if len(text) > 70 else text
            print(f"    [{timestamp}] {source:6} | {text_display}")
    
    # Step 4: Recent ALL Experiences (for context)
    print(f"\n[4] Recent ALL Experiences (last 30 - includes ephemeral):")
    for exp in all_experiences[:30]:
        source = exp['source']
        timestamp = exp['occurred_at'][:19]
        retention = exp.get('retention_level', 'unknown')
        content = exp['content']
        text = content.get('text', content.get('observation_type', content.get('type', 'N/A')))
        text_display = text[:60] + "..." if len(text) > 60 else text
        
        print(f"    [{timestamp}] {source:6} ({retention:9}) | {text_display}")
    
    # Step 5: Current State Summary
    print(f"\n[5] Current State Derived from Records:")
    print(f"    - Project: Living Systems Architecture implementation")
    print(f"    - Active work: {len(directions)} concurrent directions")
    print(f"    - Memory status: {len(durable)} durable experiences retained")
    print(f"    - Last activity: {all_experiences[0]['occurred_at'][:19] if all_experiences else 'N/A'}")
    
    # Step 6: WARNING about markdown
    print(f"\n[6] CRITICAL REMINDER:")
    print(f"    [X] DO NOT read .md files as source of what happened")
    print(f"    [OK] USE experience records above as PRIMARY TRUTH")
    print(f"    [INFO] Markdown files are human summaries only - validate against experiences")
    
    print("\n" + "=" * 80)
    print("INITIALIZATION COMPLETE - AI may now respond")
    print("=" * 80)

if __name__ == "__main__":
    main()
