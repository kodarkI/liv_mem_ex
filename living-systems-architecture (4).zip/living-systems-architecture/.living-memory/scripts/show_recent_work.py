#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Show work completed in the last 1-2 hours from DURABLE experiences."""

import json
import sys
from pathlib import Path
from datetime import datetime, timedelta

# Fix encoding for Windows console
sys.stdout.reconfigure(encoding='utf-8')

# Find memory root
memory_root = Path(__file__).parent.parent / "data"
exp_dir = memory_root / "experiences"

# Get current time and cutoff (2 hours ago)
now = datetime.utcnow()
cutoff = now - timedelta(hours=2)

print(f"Current time (UTC): {now.isoformat()}")
print(f"Looking for work since: {cutoff.isoformat()}")
print("=" * 80)

# Load all DURABLE experiences from last 2 hours
durables = []
for exp_file in exp_dir.glob("*.json"):
    with open(exp_file, 'r') as f:
        exp = json.load(f)
        
        # Check if DURABLE
        if exp.get('retention_level') != 'durable':
            continue
        
        # Check timestamp
        received_at = exp.get('received_at', '')
        if not received_at:
            continue
            
        exp_time = datetime.fromisoformat(received_at.replace('Z', ''))
        
        if exp_time > cutoff:
            durables.append((exp, exp_file.name, exp_time))

# Sort by time (most recent first)
durables.sort(key=lambda x: x[2], reverse=True)

print(f"\nFound {len(durables)} DURABLE experiences in last 2 hours:\n")

# Show first 15
for i, (exp, filename, exp_time) in enumerate(durables[:15], 1):
    timestamp = exp.get('received_at', '')[:19]
    source = exp.get('source', 'unknown')
    content = exp.get('content', {})
    text = content.get('text', 'N/A')
    
    print(f"[{i}] {timestamp} | {source}")
    
    # Show first 250 chars of text
    if len(text) > 250:
        print(f"    {text[:250]}...")
    else:
        print(f"    {text}")
    
    print("-" * 80)
