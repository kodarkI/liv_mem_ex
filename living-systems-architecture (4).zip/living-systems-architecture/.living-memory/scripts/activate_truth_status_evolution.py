#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Activate Truth Status Evolution

When experiences are contradicted, truth status must change:
- Old experience marked as QUALIFIED (truth limited by later correction)
- History preserved (experience not deleted)
- Current State updated to reflect new truth

Per ref 08: Truth status lifecycle includes QUALIFIED and CONTESTED states.
"""

import sys
import json
from pathlib import Path
from datetime import datetime

# Fix encoding
sys.stdout.reconfigure(encoding='utf-8')

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent / "core"))

from memory_control import MemoryControl

def main():
    print("=" * 80)
    print("ACTIVATING TRUTH STATUS EVOLUTION")
    print("=" * 80)
    print()
    
    script_dir = Path(__file__).parent
    memory_root = script_dir.parent
    
    mc = MemoryControl(memory_root)
    
    # Load event relations directory
    event_relations_dir = memory_root / "data" / "event_relations"
    
    if not event_relations_dir.exists():
        print("[ERROR] Event relations directory not found")
        print("[INFO] Run activate_historical_integration.py first")
        sys.exit(1)
    
    # Find all CONTRADICTS relationships
    contradicts_rels = []
    for rel_file in event_relations_dir.glob("*.json"):
        with open(rel_file, 'r', encoding='utf-8') as f:
            rel = json.load(f)
            if rel.get('predicate') == 'CONTRADICTS':
                contradicts_rels.append(rel)
    
    print(f"[*] Found {len(contradicts_rels)} CONTRADICTS relationships\n")
    
    if not contradicts_rels:
        print("[INFO] No contradictions found - truth status already coherent")
        print("=" * 80)
        sys.exit(0)
    
    # For each contradiction, mark the target as QUALIFIED
    qualified_count = 0
    
    for rel in contradicts_rels:
        source_id = rel['source_event']  # New statement (correction)
        target_id = rel['target']         # Old statement (being corrected)
        evidence = rel['evidence']
        
        # Load target experience
        target_file = memory_root / "data" / "experiences" / f"{target_id}.json"
        if not target_file.exists():
            print(f"[WARNING] Target experience not found: {target_id}")
            continue
        
        with open(target_file, 'r', encoding='utf-8') as f:
            target_exp = json.load(f)
        
        # Check current truth status
        current_status = target_exp.get('truth_status', 'asserted')
        
        if current_status == 'qualified':
            print(f"[SKIP] {target_id[:8]} already QUALIFIED")
            continue
        
        # Mark as QUALIFIED
        print(f"[UPDATE] {target_id[:8]}")
        print(f"  Current status: {current_status}")
        print(f"  New status: QUALIFIED")
        print(f"  Reason: Contradicted by {source_id[:8]}")
        print(f"  Evidence: {evidence[:60]}...")
        
        mc.mark_as_qualified(
            experience_id=target_id,
            reason=f"Contradicted by experience {source_id}: {evidence}"
        )
        
        qualified_count += 1
        print(f"  ✓ Truth status updated\n")
    
    print("=" * 80)
    print(f"TRUTH STATUS EVOLUTION ACTIVATED")
    print(f"Updated {qualified_count} experiences to QUALIFIED")
    print("=" * 80)
    print()
    print("[OK] Truth hierarchy now dynamic - evolves with corrections")
    print("[OK] History preserved - old experiences not deleted")
    print("[OK] Current State reflects latest truth")
    print()
    print("ARCHITECTURAL COMPLIANCE:")
    print("  Per ref 08: Truth status lifecycle includes QUALIFIED state")
    print("  Per ref 08: 'Truth limited or corrected by later decision'")
    print("  ✓ Living Memory principle: State evolves, History preserved")

if __name__ == '__main__':
    main()
