import json
import glob
from datetime import datetime

# Load all experiences
exp_files = glob.glob('.living-memory/experiences/*.json')
experiences = []

for f in exp_files:
    with open(f, 'r', encoding='utf-8') as file:
        exp = json.load(file)
        experiences.append((exp, f))

# Sort by received_at (most recent first)
experiences.sort(key=lambda x: x[0].get('received_at', ''), reverse=True)

# Filter for DURABLE only
durable = [e for e in experiences if e[0].get('retention_level') == 'durable'][:30]

print(f"Found {len(durable)} recent DURABLE experiences:\n")
print("=" * 80)

for exp, filepath in durable:
    print(f"\nFile: {filepath}")
    print(f"Time: {exp.get('received_at')}")
    print(f"Type: {exp.get('type')}")
    print(f"Retention: {exp.get('retention_level')}")
    
    content = exp.get('content', {})
    text = content.get('text', 'N/A')
    
    # Show first 300 chars of text
    if len(text) > 300:
        print(f"Content: {text[:300]}...")
    else:
        print(f"Content: {text}")
    
    print("-" * 80)
