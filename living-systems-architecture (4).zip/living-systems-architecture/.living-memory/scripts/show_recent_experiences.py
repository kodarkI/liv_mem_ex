#!/usr/bin/env python3
"""
Show recent experiences to understand conversation flow
"""
import sys
from pathlib import Path
import json

sys.path.insert(0, str(Path(__file__).parent))

exp_dir = Path(__file__).parent / 'experiences'

# Load all experiences
experiences = []
for exp_file in exp_dir.glob('*.json'):
    with open(exp_file, 'r') as f:
        exp = json.load(f)
        experiences.append((exp_file.name, exp))

# Sort by received_at
experiences.sort(key=lambda x: x[1].get('received_at', ''), reverse=True)

print("=" * 100)
print("LAST 25 EXPERIENCES (All Types)")
print("=" * 100)

for i, (filename, exp) in enumerate(experiences[:25], 1):
    retention = exp.get('retention_level', 'NONE')
    timestamp = exp.get('received_at', '')[:19]
    exp_type = exp.get('content', {}).get('type', 'unknown')
    
    # Get description or text
    description = exp.get('description', '')
    if not description:
        description = exp.get('content', {}).get('text', '')
    
    print(f"\n{i}. [{timestamp}] {retention:10} | {exp_type:15}")
    print(f"   {description[:150]}")
    
    if exp.get('governance_decision'):
        reasoning = exp['governance_decision'].get('reasoning', '')
        if reasoning:
            print(f"   → Governance: {reasoning[:100]}")

print("\n" + "=" * 100)
print("DURABLE EXPERIENCES ONLY (Last 20)")
print("=" * 100)

durables = [(f, exp) for f, exp in experiences if exp.get('retention_level') == 'durable']

for i, (filename, exp) in enumerate(durables[:20], 1):
    timestamp = exp.get('received_at', '')[:19]
    description = exp.get('description', '') or exp.get('content', {}).get('text', '')
    
    print(f"\n{i}. [{timestamp}]")
    print(f"   {description[:200]}")
    
    if exp.get('governance_decision', {}).get('reasoning'):
        print(f"   → Why DURABLE: {exp['governance_decision']['reasoning'][:150]}")
