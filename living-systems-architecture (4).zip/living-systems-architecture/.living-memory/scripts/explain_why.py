#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Explain Why: Event Chain Traversal for Causal Reasoning

When user asks "why did X happen?", traverse event relationships
to reconstruct causal chains.

Uses Historical Integration's traverse_event_chain() to:
- Find CAUSES, RESULTS_FROM, PROVIDES_EVIDENCE_FOR relationships
- Distinguish temporal (OCCURS_BEFORE) from causal (CAUSES)
- Build provenance-backed explanations
"""

import sys
import json
from pathlib import Path
from datetime import datetime

# Fix encoding
sys.stdout.reconfigure(encoding='utf-8')

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent / "core"))

from historical_integration import HistoricalIntegration

def find_experience_by_text(hi: HistoricalIntegration, search_text: str):
    """Find experience matching search text"""
    exp_dir = hi.experiences_dir
    
    for exp_file in exp_dir.glob("*.json"):
        with open(exp_file, 'r', encoding='utf-8') as f:
            exp = json.load(f)
            content = exp.get('content', {}).get('text', '').lower()
            if search_text.lower() in content:
                return exp
    return None

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Explain why something happened using causal chains")
    parser.add_argument('--question', type=str, required=True,
                       help='Question to answer (e.g., "why did we reach 9/10?")')
    parser.add_argument('--search', type=str, required=True,
                       help='Text to search for in experiences')
    args = parser.parse_args()
    
    print("=" * 80)
    print("EXPLAIN WHY: Event Chain Traversal")
    print("=" * 80)
    print(f"\nQuestion: {args.question}")
    print(f"Searching for: {args.search}\n")
    
    script_dir = Path(__file__).parent
    memory_root = script_dir.parent
    
    hi = HistoricalIntegration(memory_root)
    
    # Find target experience
    target_exp = find_experience_by_text(hi, args.search)
    
    if not target_exp:
        print(f"[ERROR] No experience found matching '{args.search}'")
        sys.exit(1)
    
    target_id = target_exp['id']
    target_text = target_exp.get('content', {}).get('text', '')[:80]
    
    print(f"[*] Found target experience: {target_id[:8]}")
    print(f"    Text: {target_text}...\n")
    
    # Traverse causal chain
    print("[*] Traversing causal chain...\n")
    
    chain_result = hi.traverse_event_chain(
        start_event_id=target_id,
        predicate_types={'CAUSES', 'RESULTS_FROM', 'PROVIDES_EVIDENCE_FOR', 'CONTRADICTS'},
        max_depth=10
    )
    
    if not chain_result.get('chain'):
        print("[INFO] No causal chain found - this is a standalone event")
        sys.exit(0)
    
    # Build explanation
    chain = chain_result['chain']
    print(f"[OK] Found causal chain with {len(chain)} links\n")
    print("=" * 80)
    print("CAUSAL EXPLANATION")
    print("=" * 80)
    print()
    
    for i, link in enumerate(chain, 1):
        predicate = link['predicate']
        target_event = link['target_event']
        evidence = link.get('evidence', 'No evidence provided')
        status = link.get('status', 'unknown')
        
        # Load target experience for context
        target_file = hi.experiences_dir / f"{target_event}.json"
        if target_file.exists():
            with open(target_file, 'r', encoding='utf-8') as f:
                target_exp_data = json.load(f)
                target_content = target_exp_data.get('content', {}).get('text', '')[:100]
        else:
            target_content = "N/A"
        
        print(f"Step {i}: {predicate}")
        print(f"  → {target_event[:8]}: {target_content}...")
        print(f"  Evidence: {evidence[:80]}...")
        print(f"  Status: {status}")
        print()
    
    # Summary
    print("=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print(f"\nChain depth: {len(chain)} causal links")
    print(f"Predicates used: {', '.join(set(l['predicate'] for l in chain))}")
    print(f"Weakest link status: {chain_result.get('weakest_link_status', 'unknown')}")
    print()
    print("[OK] Causal chain reconstructed with full provenance")
    print("[OK] Distinguishes causal (CAUSES) from temporal (OCCURS_BEFORE)")
    print()
    print("ARCHITECTURAL COMPLIANCE:")
    print("  Per ref 11: 'Traverse typed Event relation chain'")
    print("  Per ref 11: 'Preserve predicate labels and uncertainty at every step'")
    print("  ✓ Historical Integration active for causal reasoning")

if __name__ == '__main__':
    main()
