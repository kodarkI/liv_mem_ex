#!/usr/bin/env python3
"""
Fix core module paths to use data/ subdirectories
"""
from pathlib import Path
import re

def fix_file(filepath: Path):
    """Fix data paths in a Python file"""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    original = content
    
    # Fix directory paths
    replacements = [
        ('self.memory_root / "entities"', 'self.memory_root / "data" / "entities"'),
        ('self.memory_root / "experiences"', 'self.memory_root / "data" / "experiences"'),
        ('self.memory_root / "relationships"', 'self.memory_root / "data" / "relationships"'),
        ('self.memory_root / "directions"', 'self.memory_root / "data" / "directions"'),
        ('self.memory_root / "states"', 'self.memory_root / "data" / "states"'),
        ('self.memory_root / "schemas"', 'self.memory_root / "data" / "schemas"'),
        ('self.memory_root / \'entities\'', 'self.memory_root / "data" / "entities"'),
        ('self.memory_root / \'experiences\'', 'self.memory_root / "data" / "experiences"'),
        ('self.memory_root / \'relationships\'', 'self.memory_root / "data" / "relationships"'),
        ('self.memory_root / \'directions\'', 'self.memory_root / "data" / "directions"'),
        ('self.memory_root / \'states\'', 'self.memory_root / "data" / "states"'),
        ('self.memory_root / \'schemas\'', 'self.memory_root / "data" / "schemas"'),
    ]
    
    for old, new in replacements:
        content = content.replace(old, new)
    
    if content != original:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        return True
    
    return False

def main():
    root = Path(__file__).parent.parent
    core_dir = root / "core"
    
    print("=" * 80)
    print("Fixing Core Module Paths")
    print("=" * 80)
    
    files_to_fix = [
        "memory_control.py",
        "memory_governance.py",
        "continuity_loader.py",
        "agent_interface.py",
        "historical_integration.py"
    ]
    
    fixed_count = 0
    for filename in files_to_fix:
        filepath = core_dir / filename
        if filepath.exists():
            if fix_file(filepath):
                print(f"  [OK] {filename}")
                fixed_count += 1
            else:
                print(f"  [SKIP] {filename} (no changes needed)")
    
    print("\n" + "=" * 80)
    print(f"[COMPLETE] Fixed {fixed_count} files")
    print("=" * 80)

if __name__ == "__main__":
    main()
