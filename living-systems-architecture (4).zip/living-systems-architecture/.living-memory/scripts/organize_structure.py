#!/usr/bin/env python3
"""
Organize Living Memory file structure
Creates proper folders and moves files to appropriate locations
"""
import os
import shutil
from pathlib import Path

# Define the new structure
STRUCTURE = {
    "tests": "Test files and test output",
    "scripts": "Utility scripts and tools",
    "docs": "Documentation files",
    "core": "Core implementation files (memory_control, memory_governance, etc.)",
    "data": "Living Memory data (entities, experiences, relationships, directions, states, schemas)",
    "archive": "Old/deprecated files and outputs"
}

def create_structure(root: Path):
    """Create the folder structure"""
    print("Creating folder structure...")
    for folder, description in STRUCTURE.items():
        folder_path = root / folder
        folder_path.mkdir(exist_ok=True)
        print(f"  [OK] {folder}/ - {description}")
    
    # Create data subfolders
    data_folders = ["entities", "experiences", "relationships", "directions", "states", "schemas"]
    for subfolder in data_folders:
        (root / "data" / subfolder).mkdir(parents=True, exist_ok=True)
        print(f"  [OK] data/{subfolder}/")

def categorize_files(root: Path):
    """Categorize all files in root directory"""
    
    # Test files
    test_files = [
        "test_*.py",
        "experiment_*.py",
        "*_test_result.txt",
        "*_test.txt",
        "run_test.py",
        "simple_test.py",
        "debug_*.py",
        "auto_activation_result.txt",
        "conversational_test_result.txt",
        "final_test.txt",
        "historical_test_result.txt",
        "relationship_test_result.txt",
        "state_test_result.txt",
        "test_output.txt",
        "test_result_*.txt",
        "test_run.txt"
    ]
    
    # Script files
    script_files = [
        "record_*.py",
        "show_*.py",
        "quick_status.py",
        "load_recent_durable.py",
        "bootstrap.py"
    ]
    
    # Core files
    core_files = [
        "memory_control.py",
        "memory_governance.py",
        "continuity_loader.py",
        "agent_interface.py",
        "historical_integration.py",
        "__init__.py"
    ]
    
    # Documentation files
    doc_files = [
        "*.md",
        "README.md"
    ]
    
    # Archive files (outputs, logs, debug)
    archive_files = [
        "*.txt",
        "*.log",
        "debug_output.txt",
        "output.txt",
        "output.log",
        "recording_output.txt",
        "status_output.txt",
        "final_recording.txt"
    ]
    
    return {
        "tests": test_files,
        "scripts": script_files,
        "core": core_files,
        "docs": doc_files,
        "archive": archive_files
    }

def move_files(root: Path, dry_run=False):
    """Move files to appropriate folders"""
    from fnmatch import fnmatch
    
    categories = categorize_files(root)
    moved = {}
    
    # Get all files in root (exclude folders and already in subfolders)
    all_files = [f for f in root.iterdir() if f.is_file()]
    
    for file_path in all_files:
        filename = file_path.name
        
        # Skip bootstrap_context.json (keep in root)
        if filename == "bootstrap_context.json":
            continue
            
        # Check each category
        for category, patterns in categories.items():
            matched = False
            for pattern in patterns:
                if fnmatch(filename, pattern):
                    target_dir = root / category
                    target_path = target_dir / filename
                    
                    if not dry_run:
                        shutil.move(str(file_path), str(target_path))
                    
                    moved.setdefault(category, []).append(filename)
                    matched = True
                    break
            
            if matched:
                break
    
    return moved

def move_data_folders(root: Path, dry_run=False):
    """Move data folders to data/"""
    data_folders = ["entities", "experiences", "relationships", "directions", "states", "schemas"]
    moved = []
    
    for folder_name in data_folders:
        src = root / folder_name
        dst = root / "data" / folder_name
        
        if src.exists() and src.is_dir():
            if not dry_run:
                # Move contents
                for item in src.iterdir():
                    shutil.move(str(item), str(dst))
                # Remove empty folder
                src.rmdir()
            moved.append(folder_name)
    
    return moved

if __name__ == "__main__":
    root = Path(__file__).parent.parent
    
    print("=" * 80)
    print("Living Memory Structure Organization")
    print("=" * 80)
    
    # Create structure
    create_structure(root)
    
    print("\n" + "=" * 80)
    print("Moving files (DRY RUN)")
    print("=" * 80)
    
    moved = move_files(root, dry_run=True)
    for category, files in moved.items():
        print(f"\n{category}/ ({len(files)} files):")
        for f in files[:5]:  # Show first 5
            print(f"  - {f}")
        if len(files) > 5:
            print(f"  ... and {len(files) - 5} more")
    
    data_moved = move_data_folders(root, dry_run=True)
    if data_moved:
        print(f"\ndata/ ({len(data_moved)} folders):")
        for f in data_moved:
            print(f"  - {f}/")
    
    print("\n" + "=" * 80)
    response = input("Proceed with actual move? (yes/no): ")
    
    if response.lower() == "yes":
        moved = move_files(root, dry_run=False)
        data_moved = move_data_folders(root, dry_run=False)
        print("\n[OK] Files reorganized successfully!")
    else:
        print("\n[CANCELLED] No files moved.")
