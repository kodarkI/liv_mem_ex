#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Step 1: Try governed recall FIRST
Step 2: IF incomplete, THEN search to find what's missing
Step 3: Record findings so recall works next time
"""
import sys
import io
from pathlib import Path
import json
import re

# Fix Windows encoding
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

sys.path.insert(0, str(Path(__file__).parent.parent / 'core'))

from memory_control import MemoryControl

print("=" * 80)
print("COMPREHENSIVE EXPERIMENT SEARCH")
print("=" * 80)

# STEP 1: Governed recall FIRST
print("\n[STEP 1] Using Governed Recall (Primary Method)")
print("-" * 80)

mc = MemoryControl('.living-memory')

query_context = {
    'type': 'user_question',
    'text': 'all experiments challenges tests',
    'entities': [],
    'topics': ['experiment', 'challenge', 'test', 'suite']
}

results = mc.recall_relevant_experiences(
    query_context=query_context,
    current_directions=[],
    retention_levels=['durable'],
    limit=100
)

print(f"Governed recall found: {results['results_returned']} results")

# Extract experiment numbers from governed recall
governed_experiments = {}
for exp in results['experiences']:
    content = exp['content']
    text = content.get('text', content.get('observation_type', ''))
    
    # Look for "Experiment N" pattern
    matches = re.findall(r'[Ee]xperiment\s*(\d+)', text)
    for match in matches:
        exp_num = int(match)
        if exp_num not in governed_experiments:
            governed_experiments[exp_num] = exp

print(f"Experiment numbers found via recall: {sorted(governed_experiments.keys())}")

# STEP 2: Search to find ALL experiments (to know what's missing)
print("\n[STEP 2] Comprehensive Search (to find what's missing)")
print("-" * 80)

# Search test files
test_files = list(Path('.living-memory/tests').glob('experiment*.py'))
print(f"Test files found: {len(test_files)}")
for tf in sorted(test_files):
    print(f"  - {tf.name}")

# Search markdown docs
docs = list(Path('.living-memory/docs').glob('EXPERIMENT*.md'))
print(f"Markdown docs found: {len(docs)}")
for doc in sorted(docs):
    print(f"  - {doc.name}")

# Search ALL experiences (including non-DURABLE)
print("\nSearching ALL experiences (all retention levels)...")
all_experiment_mentions = {}
experiences_dir = Path('.living-memory/data/experiences')

for exp_file in experiences_dir.glob('*.json'):
    with open(exp_file, 'r', encoding='utf-8') as f:
        exp = json.load(f)
    
    content = exp.get('content', {})
    text = content.get('text', content.get('observation_type', ''))
    
    # Find experiment numbers
    matches = re.findall(r'[Ee]xperiment\s*(\d+)', text)
    for match in matches:
        exp_num = int(match)
        if exp_num not in all_experiment_mentions:
            all_experiment_mentions[exp_num] = []
        all_experiment_mentions[exp_num].append({
            'id': exp['id'][:8],
            'date': exp['occurred_at'][:19],
            'retention': exp.get('retention_level', 'unknown'),
            'type': content.get('type', 'unknown'),
            'source': exp.get('source', 'unknown')
        })

print(f"\nAll experiment numbers mentioned in experiences: {sorted(all_experiment_mentions.keys())}")

# STEP 3: Compare and report gaps
print("\n" + "=" * 80)
print("[STEP 3] COMPARISON & GAPS")
print("=" * 80)

all_exp_numbers = sorted(all_experiment_mentions.keys())
governed_exp_numbers = sorted(governed_experiments.keys())

print(f"\nAll experiments that exist (from search): {all_exp_numbers}")
print(f"Experiments found by governed recall: {governed_exp_numbers}")

missing_from_recall = set(all_exp_numbers) - set(governed_exp_numbers)
if missing_from_recall:
    print(f"\n⚠️  MISSING from governed recall: {sorted(missing_from_recall)}")
    
    print("\nDetails of missing experiments:")
    for exp_num in sorted(missing_from_recall):
        print(f"\n  Experiment {exp_num}:")
        for mention in all_experiment_mentions[exp_num]:
            print(f"    - {mention['date']} | {mention['source']} | {mention['retention']} | {mention['type']} | ID:{mention['id']}")

# STEP 4: Detailed report on ALL experiments
print("\n" + "=" * 80)
print("[STEP 4] DETAILED REPORT ON ALL EXPERIMENTS")
print("=" * 80)

for exp_num in sorted(all_experiment_mentions.keys()):
    print(f"\n{'=' * 80}")
    print(f"EXPERIMENT {exp_num}")
    print('=' * 80)
    
    # Find the actual test_execution record
    test_exec_record = None
    for exp_file in experiences_dir.glob('*.json'):
        with open(exp_file, 'r', encoding='utf-8') as f:
            exp = json.load(f)
        
        if exp['content'].get('type') == 'test_execution':
            text = exp['content'].get('text', '')
            if f'experiment {exp_num}' in text.lower() or f'experiment_{exp_num}' in text.lower():
                test_exec_record = exp
                break
    
    if test_exec_record:
        print(f"✅ Test execution record EXISTS")
        print(f"   ID: {test_exec_record['id'][:8]}")
        print(f"   Date: {test_exec_record['occurred_at'][:19]}")
        print(f"   Retention: {test_exec_record.get('retention_level')}")
        print(f"   Text: {test_exec_record['content'].get('text', 'N/A')}")
        
        if 'test_file' in test_exec_record['content']:
            print(f"   Test File: {test_exec_record['content']['test_file']}")
        if 'challenges_run' in test_exec_record['content']:
            print(f"   Challenges: {test_exec_record['content']['challenges_run']} run, {test_exec_record['content']['challenges_passed']} passed")
        if 'results' in test_exec_record['content']:
            print(f"   Results: {test_exec_record['content']['results']}")
    else:
        print(f"❌ NO test_execution record found")
        print(f"   Only mentioned in: {len(all_experiment_mentions[exp_num])} other experiences")

print(f"\n{'=' * 80}")
print(f"SUMMARY")
print(f"{'=' * 80}")
print(f"Total experiment numbers found: {len(all_exp_numbers)}")
print(f"Experiments: {all_exp_numbers}")
print(f"Found by governed recall: {len(governed_exp_numbers)} / {len(all_exp_numbers)}")
if missing_from_recall:
    print(f"⚠️  Missing from recall: {sorted(missing_from_recall)}")
    print(f"\n→ These need to be fixed so governed recall finds them")
