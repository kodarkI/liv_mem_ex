#!/usr/bin/env python3
"""
Protocol Compliance Validator
Checks if AI followed the mandatory protocol in current session.

Detects violations:
- Did AI record user message as Experience? (Step 2)
- Did AI record its response as Experience? (Step 4)
- Did AI cite experience IDs in response?
- Did AI quote from markdown instead of experiences?

Usage: python .living-memory/scripts/validate_protocol_compliance.py
"""

import sys
import json
from pathlib import Path
from datetime import datetime, timedelta

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.memory_control import MemoryControl

def check_recent_experiences(minutes_back=10):
    """Check if experiences were recorded in last N minutes"""
    experiences_dir = Path('.living-memory/data/experiences')
    cutoff = datetime.utcnow() - timedelta(minutes=minutes_back)

    recent_user = []
    recent_agent = []

    for exp_file in experiences_dir.glob('*.json'):
        with open(exp_file, 'r') as f:
            exp = json.load(f)

        # Parse timestamp and make timezone-naive for comparison
        received_at_str = exp['received_at'].replace('Z', '')
        received_at = datetime.fromisoformat(received_at_str)

        if received_at > cutoff:
            if exp['source'] == 'user':
                recent_user.append(exp)
            elif exp['source'] == 'agent':
                recent_agent.append(exp)
    
    return recent_user, recent_agent

def main():
    print("=" * 80)
    print("PROTOCOL COMPLIANCE VALIDATION")
    print("=" * 80)
    
    print("\n[*] Checking experiences from last 10 minutes...")
    
    recent_user, recent_agent = check_recent_experiences(minutes_back=10)
    
    print(f"\n[CHECK 1] User messages recorded:")
    if recent_user:
        print(f"    [OK] {len(recent_user)} user message(s) recorded as Experiences")
        for exp in recent_user[-3:]:
            print(f"        - {exp['id'][:8]}... at {exp['received_at'][:19]}")
    else:
        print(f"    [FAIL] NO user messages recorded in last 10 minutes")
        print(f"    [VIOLATION] AI did not execute Step 2 (record user message)")
    
    print(f"\n[CHECK 2] Agent responses recorded:")
    if recent_agent:
        print(f"    [OK] {len(recent_agent)} agent response(s) recorded as Experiences")
        for exp in recent_agent[-3:]:
            print(f"        - {exp['id'][:8]}... at {exp['received_at'][:19]}")
    else:
        print(f"    [FAIL] NO agent responses recorded in last 10 minutes")
        print(f"    [VIOLATION] AI did not execute Step 4 (record agent response)")
    
    print(f"\n[CHECK 3] Response-to linkage:")
    if recent_agent:
        linked = [e for e in recent_agent if e['content'].get('in_response_to')]
        if linked:
            print(f"    [OK] {len(linked)} agent response(s) linked to user messages")
        else:
            print(f"    [WARN] Agent responses not linked to user messages")
    
    print(f"\n[CHECK 4] Retention decisions:")
    all_recent = recent_user + recent_agent
    governed = [e for e in all_recent if 'retention_decision' in e]
    print(f"    {len(governed)}/{len(all_recent)} experiences have retention decisions")
    
    durable = [e for e in governed if e.get('retention_level') == 'durable']
    if durable:
        print(f"    [INFO] {len(durable)} experiences promoted to DURABLE")
    
    # Final verdict
    print("\n" + "=" * 80)
    
    violations = []
    if not recent_user:
        violations.append("Step 2 not executed (user message not recorded)")
    if not recent_agent:
        violations.append("Step 4 not executed (agent response not recorded)")
    
    if violations:
        print("PROTOCOL VIOLATIONS DETECTED:")
        for v in violations:
            print(f"  [X] {v}")
        print("\nAI FAILED protocol compliance.")
        
        # Record violation
        mc = MemoryControl('.living-memory')
        violation_id = mc.receive_experience(
            source='system',
            content={
                'type': 'protocol_violation',
                'violations': violations,
                'detected_at': datetime.utcnow().isoformat() + 'Z',
                'severity': 'critical'
            }
        )
        print(f"\n[*] Violation recorded as Experience: {violation_id[:8]}...")
        
    else:
        print("PROTOCOL COMPLIANCE: PASS")
        print("  [OK] Step 2 executed (user message recorded)")
        print("  [OK] Step 4 executed (agent response recorded)")
        print("\nAI followed protocol correctly.")
    
    print("=" * 80)

if __name__ == "__main__":
    main()
