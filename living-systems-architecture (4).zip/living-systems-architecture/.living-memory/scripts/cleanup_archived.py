#!/usr/bin/env python3
"""
Automated cleanup of ARCHIVED experiences based on retention policy
Per ref 08: ARCHIVED → prune under explicit policy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import json
from datetime import datetime, timedelta

def cleanup_archived_experiences(memory_root: Path, 
                                 archive_retention_days: int = 90,
                                 dry_run: bool = True):
    """
    Clean up ARCHIVED experiences older than retention policy
    
    Default Policy:
    - ARCHIVED for > 90 days → PRUNE (with tombstone)
    - DURABLE experiences → NEVER prune automatically
    
    Args:
        memory_root: Path to .living-memory/
        archive_retention_days: Days to keep ARCHIVED before pruning
        dry_run: If True, only report what would be cleaned
    """
    experiences_dir = memory_root / "data" / "experiences"
    tombstones_dir = memory_root / "data" / "tombstones"
    tombstones_dir.mkdir(parents=True, exist_ok=True)
    
    now = datetime.utcnow()
    cutoff = now - timedelta(days=archive_retention_days)
    
    stats = {
        "total_scanned": 0,
        "archived_found": 0,
        "ready_for_prune": 0,
        "pruned": 0,
        "protected_durable": 0,
        "errors": 0
    }
    
    print("="*70)
    print("ARCHIVED Experience Cleanup")
    print("="*70)
    print(f"Mode: {'DRY RUN' if dry_run else 'LIVE'}")
    print(f"Policy: ARCHIVED > {archive_retention_days} days -> PRUNE")
    print(f"Cutoff date: {cutoff.isoformat()}Z\n")
    
    for exp_file in experiences_dir.glob("*.json"):
        stats["total_scanned"] += 1
        
        try:
            with open(exp_file, 'r', encoding='utf-8') as f:
                exp = json.load(f)
            
            retention = exp.get("retention_decision", {})
            level = retention.get("level")
            
            # Never prune DURABLE
            if level == "durable":
                stats["protected_durable"] += 1
                continue
            
            if level != "archived":
                continue
            
            stats["archived_found"] += 1
            
            # When was it archived?
            archived_at = retention.get("decided_at")
            if not archived_at:
                continue
            
            if archived_at.endswith('Z'):
                archived_at = archived_at[:-1]
            archived_time = datetime.fromisoformat(archived_at)
            
            # Check if past cutoff
            if archived_time < cutoff:
                age_days = (now - archived_time).days
                stats["ready_for_prune"] += 1
                
                print(f"[PRUNE] {exp['id'][:8]}... - archived {age_days} days ago")
                print(f"  Content: {exp.get('content', {}).get('text', '')[:50]}...")
                
                if not dry_run:
                    # Create tombstone
                    tombstone = {
                        "id": exp["id"],
                        "type": "experience",
                        "original_retention_level": "archived",
                        "pruned_at": now.isoformat() + 'Z',
                        "pruned_reason": f"ARCHIVED for {age_days} days (policy: {archive_retention_days} days)",
                        "original_source": exp.get("source"),
                        "original_received_at": exp.get("received_at"),
                        "original_archived_at": retention.get("decided_at"),
                        "original_content_type": exp.get("content", {}).get("type"),
                        "original_content_summary": exp.get("content", {}).get("text", "")[:200]
                    }
                    
                    tombstone_file = tombstones_dir / f"{exp['id']}.json"
                    with open(tombstone_file, 'w') as f:
                        json.dump(tombstone, f, indent=2)
                    
                    # Delete original
                    exp_file.unlink()
                    stats["pruned"] += 1
        
        except Exception as e:
            stats["errors"] += 1
            print(f"[ERROR] {exp_file.name}: {e}")
    
    print("\n" + "="*70)
    print("CLEANUP SUMMARY")
    print("="*70)
    print(f"Total experiences scanned: {stats['total_scanned']}")
    print(f"DURABLE protected from pruning: {stats['protected_durable']}")
    print(f"ARCHIVED found: {stats['archived_found']}")
    print(f"Ready for PRUNE (>{archive_retention_days} days): {stats['ready_for_prune']}")
    
    if not dry_run:
        print(f"\nACTIONS TAKEN:")
        print(f"  Pruned (with tombstone): {stats['pruned']}")
    else:
        print(f"\nDRY RUN - No changes made. Run with --live to execute.")
    
    print(f"Errors: {stats['errors']}")
    print()

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Clean up ARCHIVED experiences")
    parser.add_argument("--days", type=int, default=90, help="Days to keep ARCHIVED (default: 90)")
    parser.add_argument("--live", action="store_true", help="Actually perform cleanup")
    args = parser.parse_args()
    
    memory_root = Path(__file__).parent.parent
    cleanup_archived_experiences(memory_root, args.days, dry_run=not args.live)
