#!/usr/bin/env python3
"""
Reorganize Living Memory structure NOW
Executes the file reorganization without prompts
"""
import os
import shutil
from pathlib import Path
from fnmatch import fnmatch

def main():
    root = Path(__file__).parent.parent
    
    print("=" * 80)
    print("Living Memory Structure Reorganization")
    print("=" * 80)
    
    # 1. Create folder structure
    print("\n[1/4] Creating folder structure...")
    folders = ["tests", "scripts", "docs", "core", "archive"]
    for folder in folders:
        (root / folder).mkdir(exist_ok=True)
        print(f"  [OK] {folder}/")
    
    # Create data subfolders
    data_folders = ["entities", "experiences", "relationships", "directions", "states", "schemas"]
    (root / "data").mkdir(exist_ok=True)
    for subfolder in data_folders:
        (root / "data" / subfolder).mkdir(parents=True, exist_ok=True)
        print(f"  [OK] data/{subfolder}/")
    
    # 2. Move data folders
    print("\n[2/4] Moving data folders...")
    for folder_name in data_folders:
        src = root / folder_name
        dst = root / "data" / folder_name

        if src.exists() and src.is_dir() and src != dst:
            count = 0
            try:
                for item in src.iterdir():
                    shutil.move(str(item), str(dst))
                    count += 1
                # Try to remove, but don't fail if can't
                try:
                    src.rmdir()
                except (PermissionError, OSError):
                    # Folder might be locked, skip
                    pass
                print(f"  [OK] {folder_name}/ -> data/{folder_name}/ ({count} items)")
            except Exception as e:
                print(f"  [SKIP] {folder_name}/ - {e}")
    
    # 3. Move files
    print("\n[3/4] Moving files to appropriate folders...")
    
    # Get all files in root
    all_files = [f for f in root.iterdir() if f.is_file()]
    
    file_moves = {
        "tests": [
            "test_*.py", "experiment_*.py", "*_test_result.txt", "run_test.py",
            "simple_test.py", "debug_*.py", "auto_activation_result.txt",
            "conversational_test_result.txt", "final_test.txt",
            "historical_test_result.txt", "relationship_test_result.txt",
            "state_test_result.txt", "test_output.txt", "test_result_*.txt", "test_run.txt"
        ],
        "scripts": [
            "record_*.py", "show_*.py", "quick_status.py",
            "load_recent_durable.py", "bootstrap.py"
        ],
        "core": [
            "memory_control.py", "memory_governance.py", "continuity_loader.py",
            "agent_interface.py", "historical_integration.py"
        ],
        "docs": ["*.md"],
        "archive": [
            "*.txt", "*.log", "debug_output.txt", "output.txt", "output.log",
            "recording_output.txt", "status_output.txt", "final_recording.txt"
        ]
    }
    
    moved_counts = {cat: 0 for cat in file_moves.keys()}
    
    for file_path in all_files:
        filename = file_path.name
        
        # Skip special files
        if filename in ["bootstrap_context.json", "__init__.py"]:
            continue
        
        # Find matching category
        for category, patterns in file_moves.items():
            matched = False
            for pattern in patterns:
                if fnmatch(filename, pattern):
                    target_dir = root / category
                    target_path = target_dir / filename
                    
                    # Don't overwrite if already exists
                    if not target_path.exists():
                        shutil.move(str(file_path), str(target_path))
                        moved_counts[category] += 1
                    matched = True
                    break
            if matched:
                break
    
    for category, count in moved_counts.items():
        if count > 0:
            print(f"  [OK] {category}/ ({count} files)")
    
    # 4. Clean up __pycache__
    print("\n[4/4] Cleaning up...")
    pycache = root / "__pycache__"
    if pycache.exists():
        try:
            shutil.rmtree(pycache)
            print(f"  [OK] Removed __pycache__/")
        except (PermissionError, OSError):
            print(f"  [SKIP] __pycache__/ (in use, will clean up later)")
    
    print("\n" + "=" * 80)
    print("[COMPLETE] Living Memory structure reorganized")
    print("=" * 80)
    
    print("\nNew structure:")
    print("  .living-memory/")
    print("    - core/          - Core implementation (memory_control, agent_interface, etc.)")
    print("    - data/          - All Living Memory records")
    print("      - entities/")
    print("      - experiences/")
    print("      - relationships/")
    print("      - directions/")
    print("      - states/")
    print("      - schemas/")
    print("    - tests/         - All test files and test outputs")
    print("    - scripts/       - Utility scripts")
    print("    - docs/          - Documentation")
    print("    - archive/       - Old outputs and logs")
    print("    - bootstrap_context.json")

if __name__ == "__main__":
    main()
