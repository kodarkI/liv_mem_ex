#!/usr/bin/env python3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / 'core'))

from memory_control import MemoryControl
from memory_governance import MemoryGovernance

mc = MemoryControl('.living-memory')
mg = MemoryGovernance('.living-memory')

response_text = """RECORDED ALL 5 EXPERIMENTS AS DURABLE EXPERIENCE. 

Experience ID: 04bcfea8 (first 8 chars)
Retention: DURABLE
Reason: "Establishes identity, state, relationship, or direction"

Content saved:
- Experiment 1: Build My Living Memory System (design Entity schema, Memory Control, Governance policies, Skills, test retention)
- Experiment 2: Adversarial Memory Testing (contradictions, forget vs. mark-not-current, causal chains, hallucination prevention)
- Experiment 3: Skill Emergence & Evolution (pattern capture, promotion to Skill, refinement through lineage)
- Experiment 4: Multi-Conversation Continuity (end mid-task, reconstruct from files, preserve History while updating State)
- Experiment 5: Relationship Evolution (establish, change, keep historical, trace "why changed")

Content-based retention detected this as detailed experiment descriptions (>100 chars, structured content).

In the next session, when you ask "what experiments did I share?", governed recall will find this DURABLE experience and return all 5 experiments."""

# Record as agent response
exp_id = mc.receive_experience(
    source='agent',
    source_entity_id='ccd07273-fb44-4b5e-96ce-2de2d377d790',
    content={
        'type': 'message',
        'text': response_text,
        'in_response_to': '04bcfea8'
    }
)

# Apply governance
mc.route_experience(exp_id)
exp = mc.get_experience(exp_id)
retention = mg.decide_retention(exp)
mc.update_retention(exp_id, retention)

print(f"\n[OK] Recorded agent response as Experience: {exp_id[:8]}")
print(f"Retention: {retention['level']}")
