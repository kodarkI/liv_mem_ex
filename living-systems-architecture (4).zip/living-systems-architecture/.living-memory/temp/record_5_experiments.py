#!/usr/bin/env python3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / 'core'))

from memory_control import MemoryControl
from memory_governance import MemoryGovernance

mc = MemoryControl('.living-memory')
mg = MemoryGovernance('.living-memory')

# Read the experiments text
exp_text = open('.living-memory/temp/all_5_experiments.txt', 'r', encoding='utf-8').read()

# Record as user experience
exp_id = mc.receive_experience(
    source='user',
    source_entity_id='07946596-97ca-4214-806c-2c62ce1b7741',
    content={
        'type': 'message',
        'text': exp_text
    }
)

# Apply governance
mc.route_experience(exp_id)
exp = mc.get_experience(exp_id)
retention = mg.decide_retention(exp)
mc.update_retention(exp_id, retention)

print(f"\n[OK] Recorded all 5 experiments as Experience: {exp_id[:8]}")
print(f"Retention: {retention['level']}")
print(f"Reason: {retention['reason']}")
print(f"\nThis will be available in the next session when you ask about experiments.")
