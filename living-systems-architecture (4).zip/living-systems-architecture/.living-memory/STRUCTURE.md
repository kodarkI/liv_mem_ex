# Living Memory File Structure

**Last Updated:** 2026-08-14
**Reorganization:** Complete

---

## Directory Structure

```
.living-memory/
├── bootstrap_context.json    # Entry point: entity IDs, initial direction
├── __init__.py               # Python package marker
│
├── core/                     # Core implementation (STABLE)
│   ├── memory_control.py        # Routes experiences, detects changes
│   ├── memory_governance.py     # Retention decisions, entity/relationship lifecycle
│   ├── continuity_loader.py     # Loads Living Memory for continuity
│   ├── agent_interface.py       # AI agent interface to Living Memory
│   └── historical_integration.py # Historical relationship chains
│
├── data/                     # Living Memory records (GOVERNED)
│   ├── entities/             # Entity records (user, agent, conversation, project)
│   ├── experiences/          # Experience records (ephemeral → persistent → durable)
│   ├── relationships/        # Relationship records (proposed → active → dormant)
│   ├── directions/           # Direction records (what we're continuing toward)
│   ├── states/               # State snapshots (superseded chains)
│   └── schemas/              # JSON schemas for validation
│
├── scripts/                  # Utility scripts and tools
│   ├── record_conversation_turn.py   # Record user/agent messages as Experiences
│   ├── record_current_session.py    # Retroactively record conversation
│   ├── record_final_fix.py          # Record critical learning as DURABLE
│   ├── bootstrap.py                 # Initialize Living Memory
│   ├── quick_status.py              # Show current state summary
│   ├── show_recent_experiences.py   # Display recent DURABLE experiences
│   ├── load_recent_durable.py       # Load and display DURABLE experiences
│   ├── reorganize_now.py            # Reorganize file structure
│   └── update_import_paths.py       # Update imports after reorganization
│
├── tests/                    # Test files and outputs (ISOLATED)
│   ├── test_*.py             # Test implementation files
│   ├── experiment_*.py       # Experiment/challenge suites
│   ├── *_test_result.txt     # Test execution outputs
│   └── debug_*.py            # Debug utilities
│
├── docs/                     # Documentation (ASSERTED, not governed)
│   ├── README.md                           # Living Memory overview
│   ├── AGENT_PROTOCOL.md                   # How AI agents should behave
│   ├── PROTOCOL_COMPLIANCE_CHECKLIST.md    # Compliance verification
│   ├── PROTOCOL_EXECUTION_FIX_COMPLETE.md  # Protocol execution fix docs
│   ├── EXPERIMENT_2_RESULTS.md             # Experiment 2 summary
│   ├── EXPERIMENT_4_COMPLETE.md            # Experiment 4 summary
│   ├── FOUNDATION_GAPS_COMPLETE.md         # Foundation work completion
│   ├── STATUS_SUMMARY.md                   # Current status
│   └── [other docs]
│
└── archive/                  # Old outputs, logs, deprecated files
    ├── output.txt
    ├── output.log
    ├── debug_output.txt
    └── [other logs]
```

---

## Key Principles

### 1. **Separation of Concerns**
- **core/** = implementation (stable, reusable)
- **data/** = governed truth (immutable experiences, evolving entities/relationships)
- **scripts/** = operational tools
- **tests/** = validation (isolated from production)
- **docs/** = human summaries (NOT source of truth)
- **archive/** = historical artifacts

### 2. **Source Precedence**
When reconstructing context, respect this hierarchy:
1. `data/experiences/*.json` - EFFECTIVE truth (what happened)
2. `data/entities/*.json`, `data/relationships/*.json`, `data/directions/*.json` - EFFECTIVE truth (what is true now)
3. `docs/*.md` - ASSERTED only (human summaries, validate against records)

### 3. **Import Paths**
All scripts import from `core/`:
```python
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / 'core'))

from memory_control import MemoryControl
from agent_interface import AgentMemoryInterface
```

### 4. **Test Isolation**
- All test files go in `tests/`
- All test outputs (.txt, .log) go in `tests/`
- Tests NEVER modify production data directly
- Tests use `data/` for reading governed truth

### 5. **Data Paths**
All core modules reference `data/` subdirectories:
```python
memory_root = Path(__file__).parent.parent  # .living-memory/
entities_dir = memory_root / "data" / "entities"
experiences_dir = memory_root / "data" / "experiences"
# etc.
```

---

## File Naming Conventions

### Experiences
- UUID-based: `{uuid}.json`
- Example: `271b2391-9533-489b-8d96-a3025ff022eb.json`

### Entities
- UUID-based: `{uuid}.json`
- Example: `07946596-97ca-4214-806c-2c62ce1b7741.json`

### Scripts
- Action-based: `{verb}_{object}.py`
- Examples: `record_conversation_turn.py`, `show_recent_experiences.py`

### Tests
- Prefix with `test_`: `test_{feature}.py`
- Examples: `test_continuity.py`, `test_state_snapshots.py`

### Docs
- SCREAMING_SNAKE_CASE: `{TOPIC}.md`
- Examples: `PROTOCOL_COMPLIANCE_CHECKLIST.md`, `STATUS_SUMMARY.md`

---

## Migration Notes

**Reorganization completed:** 2026-08-14

**What moved:**
- 5 core modules → `core/`
- 292 data files → `data/` (entities, experiences, relationships, directions, states, schemas)
- 14 scripts → `scripts/`
- 22 test files → `tests/`
- 13 docs → `docs/`
- 6 logs/outputs → `archive/`

**Import path updates required:**
All scripts that import from `memory_control`, `memory_governance`, `continuity_loader`, or `agent_interface` must update their `sys.path.insert()` to point to `core/`.

---

## Next Steps

1. Update remaining scripts with new import paths
2. Remove empty old folders (entities/, experiences/, etc. in root)
3. Update SKILL.md to reference new structure
4. Test all scripts to verify they work with new paths
