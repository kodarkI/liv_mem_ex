# Severity Priority Matrix: Missing Functions by Impact

**Date:** 2026-08-14  
**Goal:** Rank missing functions by severity and implement highest-impact first

---

## 🎯 SEVERITY SCORING FORMULA

**Total Severity = Impact × Urgency × Architectural Alignment**

| Factor | Weight | Range |
|--------|--------|-------|
| **Impact** | 40% | 1-10 (how much it improves the system) |
| **Urgency** | 30% | 1-10 (how critical for current use) |
| **Architectural Alignment** | 30% | 1-10 (how core to Living Memory concept) |

---

## 📊 RANKED BY SEVERITY

| Rank | Function | Impact | Urgency | Alignment | **Total** | Effort |
|------|----------|--------|---------|-----------|-----------|--------|
| **#1** | **Truth Status Evolution** | 10 | 10 | 10 | **10.0** | LOW |
| **#2** | **Governed Recall in Conversation** | 9 | 9 | 10 | **9.3** | MEDIUM |
| **#3** | **Event Chain Traversal** | 8 | 7 | 10 | **8.3** | LOW |
| **#4** | **Relationship Advancement** | 7 | 6 | 9 | **7.3** | MEDIUM |
| **#5** | **Pattern Detection** | 10 | 5 | 10 | **8.3** | HIGH |
| **#6** | **Integration Assertions** | 6 | 4 | 7 | **5.7** | MEDIUM |

---

## 🔴 PRIORITY #1: Truth Status Evolution (Severity: 10.0) ⚡

### Why This is #1

**Impact: 10/10** - CRITICAL
- When contradictions occur, truth status MUST change
- Currently: User says "Actually payment" but old "working on auth" stays SUPPORTED
- This violates core Living Memory: truth evolves, history preserved

**Urgency: 10/10** - IMMEDIATE
- Happens EVERY TIME user corrects something
- Already have 2 CONTRADICTS relationships in current conversation
- Need to mark old experiences as QUALIFIED NOW

**Architectural Alignment: 10/10** - CORE PRINCIPLE
- Per ref 08: "Truth status lifecycle: ASSERTED → VALIDATED → SUPPORTED → EFFECTIVE → QUALIFIED/CONTESTED"
- Not using QUALIFIED/CONTESTED means truth hierarchy is static
- **This is THE defining feature of Living Memory**

### Implementation Plan

**Create:** `activate_truth_status_evolution.py`

**Logic:**
1. Scan for CONTRADICTS relationships
2. Mark source of contradiction (old experience) as QUALIFIED
3. Add qualification_reason referencing the contradiction
4. Preserve History (don't delete old experience)
5. Update current State to reflect new truth

**Effort:** LOW (1 script, ~50 lines)  
**ROI:** HIGHEST - fixes critical architectural gap

---

## 🟠 PRIORITY #2: Governed Recall in Conversation (Severity: 9.3) ⚡

### Why This is #2

**Impact: 9/10** - HIGH
- Currently bypass Memory Control → Historical Integration → Governance flow
- When user asks "what experiments?", should use `recall_relevant_experiences()`
- This is how the closed loop should work

**Urgency: 9/10** - IMMEDIATE
- You ask questions requiring recall every conversation
- Currently use `initialize_context.py` (loads everything) instead of selective recall
- Misses relevance filtering

**Architectural Alignment: 10/10** - CORE FLOW
- Per ref 02: "Memory Control is first point of contact for all operations"
- Per GOVERNED_RECALL_DESIGN.md: "Must route through Memory Control → Historical Integration → Relevance → Governance"
- We bypass this entirely

### Implementation Plan

**Create:** `governed_recall_wrapper.py` to intercept user questions

**Logic:**
1. Detect when user asks about past ("what experiments?", "what did we do?")
2. Build query_context from user question
3. Call `memory_control.recall_relevant_experiences()`
4. Return relevance-filtered, governed results

**Effort:** MEDIUM (~100 lines + integration)  
**ROI:** HIGH - enables proper recall flow

---

## 🟡 PRIORITY #3: Event Chain Traversal (Severity: 8.3)

### Why This is #3

**Impact: 8/10** - HIGH
- Created 20 event relationships but never use them
- Can't answer "why did this change?" or "what caused this?"
- Missing causal explanation capability

**Urgency: 7/10** - MODERATE
- User will ask "why?" questions eventually
- Currently can't reconstruct causal chains
- Have the data, just not using it

**Architectural Alignment: 10/10** - CORE CAPABILITY
- Per ref 11: "Traverse typed Event relation chain"
- Per ref 11: "Distinguish temporal vs causal"
- Historical Integration is half-implemented without this

### Implementation Plan

**Create:** `explain_why.py` wrapper

**Logic:**
1. When user asks "why X?"
2. Find experience(s) related to X
3. Call `traverse_event_chain(exp_id, predicate_types=['CAUSES', 'RESULTS_FROM', 'PROVIDES_EVIDENCE_FOR'])`
4. Build causal explanation from chain
5. Return with provenance

**Effort:** LOW (~60 lines)  
**ROI:** HIGH - unlocks causal reasoning

---

## 🟢 PRIORITY #4: Relationship Advancement (Severity: 7.3)

### Why This is #4

**Impact: 7/10** - MODERATE-HIGH
- Relationships stuck at initial status
- Should advance: POSSIBLE → CANDIDATE → SUPPORTED → ESTABLISHED → ACTIVE
- Lifecycle not working

**Urgency: 6/10** - MODERATE
- Not blocking current operations
- But relationships will accumulate at CANDIDATE forever

**Architectural Alignment: 9/10** - CORE GOVERNANCE
- Per ref 04: Relationship lifecycle is fundamental
- Per ref 05: "Transition guards" must be applied
- We create but don't govern advancement

### Implementation Plan

**Create:** `advance_relationships.py` background task

**Logic:**
1. Load all CANDIDATE relationships
2. Check evidence count
3. If sufficient evidence (e.g., 2+ experiences), advance to SUPPORTED
4. If more evidence (e.g., 5+ experiences), advance to ESTABLISHED
5. Mark as ACTIVE when used

**Effort:** MEDIUM (~80 lines + rules)  
**ROI:** MODERATE - completes relationship governance

---

## 🔵 PRIORITY #5: Pattern Detection (Severity: 8.3) - HIGH IMPACT, LOW URGENCY

### Why This is #5 (despite high score)

**Impact: 10/10** - CRITICAL FOR LEARNING
- Required for Skill Emergence
- Without it, Learning Loop stuck at 4/10
- System captures but doesn't LEARN

**Urgency: 5/10** - LOW (but important)
- Need recurring patterns to emerge first
- Not enough data in single conversation
- This is a multi-session capability

**Architectural Alignment: 10/10** - CORE CONCEPT
- Per SKILL.md: "Experience → Pattern Recognition → Emerging Capability → Skill Creation"
- This is THE learning mechanism
- Without it, system is just a database

### Implementation Plan

**Create:** `detect_patterns.py` analyzer

**Logic:**
1. Scan DURABLE experiences for recurring content types
2. Group by similarity (e.g., "user asks about X", "agent fixes Y")
3. Detect patterns when count > threshold (e.g., 3 occurrences)
4. Create pattern assertion
5. Promote to Emerging Capability if pattern is actionable

**Effort:** HIGH (~150 lines + pattern matching logic)  
**ROI:** CRITICAL LONG-TERM (enables Skill Emergence)

---

## 🟣 PRIORITY #6: Integration Assertions (Severity: 5.7)

### Why This is #6

**Impact: 6/10** - MODERATE
- For interpreted connections between experiences
- Adds integration layer above raw History

**Urgency: 4/10** - LOW
- Not blocking current operations
- Nice to have, not critical

**Architectural Alignment: 7/10** - DEFINED BUT OPTIONAL
- Per ref 04: "Integration assertion" is specified
- But not required for basic operation

### Implementation Plan

**Create:** `create_integrations.py`

**Logic:**
1. Find clusters of related experiences
2. Create integration assertion with interpretation
3. Mark as PROPOSED/ACCEPTED/REJECTED

**Effort:** MEDIUM (~70 lines)  
**ROI:** LOW - adds polish, not critical

---

## 🎯 EXECUTION PLAN (DO IN THIS ORDER)

| Priority | Task | Effort | Impact | Do Now? |
|----------|------|--------|--------|---------|
| **1** | Truth Status Evolution | LOW | CRITICAL | ✅ **YES - DO FIRST** |
| **2** | Governed Recall | MEDIUM | HIGH | ✅ **YES - DO SECOND** |
| **3** | Event Chain Traversal | LOW | HIGH | ✅ **YES - DO THIRD** |
| **4** | Relationship Advancement | MEDIUM | MODERATE | ⚠️ Later (after 1-3) |
| **5** | Pattern Detection | HIGH | CRITICAL | 🔵 Multi-session (save for later) |
| **6** | Integration Assertions | MEDIUM | MODERATE | 🔵 Optional polish |

---

## 📈 IMPACT ON SCORES

### Current State
- Overall Score: 9.0/10
- Function Usage: 30%
- Alignment: 65%

### After Priority 1-3
- Overall Score: **9.5/10** (+0.5)
- Function Usage: **50%** (+20%)
- Alignment: **85%** (+20%)

### After All 6
- Overall Score: **9.7/10** (+0.7)
- Function Usage: **70%** (+40%)
- Alignment: **95%** (+30%)

---

## ✅ RECOMMENDATION

**DO NOW (this session):**
1. ✅ Truth Status Evolution (15 min)
2. ✅ Event Chain Traversal (20 min)
3. ⚠️ Governed Recall (30 min) - if time permits

**DO LATER (next session):**
4. Relationship Advancement
5. Pattern Detection (requires multi-session data)
6. Integration Assertions

**Rationale:** Fix the CRITICAL architectural gap (#1) first, then add causal reasoning (#3), then improve recall (#2).
