# Protocol Violation Learning Record

**Date:** 2026-08-14  
**Event:** User corrected AI for violating Source Precedence protocol  
**Outcome:** Full recording + Skill update + enforcement mechanisms

---

## What Happened

### User's Continuity Check (First Message)
User asked:
> "let see what we are talking last time and what is left to do? 
> follow the protocol or rule and concept from my living memory. not just see md and check on doc and violent my protocol"

### AI's First Response (WRONG)
AI:
1. ✅ Loaded `bootstrap_context.json`
2. ❌ Read `STATUS_SUMMARY.md`, `COMPLETION_STATUS.md`, `EXPERIMENT_4_COMPLETE.md` FIRST
3. ❌ Quoted from markdown as "what you said"
4. ❌ Only loaded Experience records AFTER user called out the violation

### User's Correction
> "don't you have records of our last conversations? even when follow protocol?"

**User identified:** AI violated Source Precedence even when explicitly told to "follow the protocol"

### User's Critical Question
> "how can i say for you to look at experience records? you only follow one even when i ask to check on protocal? and not to check md first? do i have to mention that you have to get experience records if not, just check it until finding one? not to go to md when records failed?"

**Translation:** How do I make FUTURE AI instances follow the protocol WITHOUT re-explaining?

### User's Expectation
> "i don't ask you just this time but i ask how to do with new you? 
> do i have to explain to you again about violent the protocol?"

**Answer should be:** NO - user should NOT have to re-explain to future AI instances

---

## What Was Done (Full Recording)

### 1. DURABLE Experiences Recorded

**Experience 1:** User's protocol violation call-out
- Text: "don't you have records of our last conversations? even when follow protocol?"
- Why DURABLE: User caught AI violating Source Precedence
- Impact: Critical teaching moment

**Experience 2:** Behavior requirement for future AI
- Text: Full question about loading Experience records first
- Why DURABLE: Defines SYSTEMIC requirement - AI must load Experience records FIRST without being told
- Impact: Establishes cross-conversation behavior expectation

**Experience 3:** No re-explanation expectation
- Text: "do i have to explain to you again about violent the protocol?"
- Why DURABLE: Success criteria - future AI instances must learn without re-explanation
- Impact: Tests Living Memory effectiveness

### 2. Skill File Updated (`.augment/skills/liv-mem/SKILL.md`)

**Added:**
- 🚨 Top-level warning section (impossible to miss)
- Explicit load order: Experience records BEFORE markdown
- Violation patterns to avoid
- User expectation documented
- Reference to DURABLE Experience evidence

**Key addition:**
```markdown
## 🚨 IMMEDIATE ACTION REQUIRED: Read This FIRST 🚨

**IF `.living-memory/bootstrap_context.json` EXISTS:**

1. **STOP** - Do not read ANY markdown files yet
2. **LOAD** - Experience records from `.living-memory/experiences/*.json` (DURABLE only)
3. **READ** - User's exact words from `content.text` field in each experience
4. **THEN** - Load directions, entities, relationships
5. **FINALLY** - Check markdown (optional, for human context only)
```

### 3. Protocol Compliance Checklist Created

**File:** `PROTOCOL_COMPLIANCE_CHECKLIST.md`

**Contains:**
- ✅ First Action Checklist
- ❌ Common Violations list
- 🚨 Reference to user's correction
- 🎯 Success criteria for future AI
- 📋 Phrase detection ("follow the protocol" → you violated it)
- 🔄 Cross-conversation learning test

### 4. Direction Milestone Updated

**Milestone added:** "Protocol Compliance Learning: Experience Records Before Markdown"

**Evidence:**
- PROTOCOL_COMPLIANCE_CHECKLIST.md
- 3 DURABLE experiences
- Updated Skill file

**Note:** "Future AI instances must NOT require re-explanation of Source Precedence protocol."

---

## What Future AI Will See

**When new conversation starts:**

1. Loads `.augment/skills/liv-mem/SKILL.md`
   - Sees 🚨 warning at the top
   - Sees explicit load order
   - Sees user expectation documented

2. Loads `.living-memory/bootstrap_context.json`
   - Triggers First Action Protocol

3. Loads `.living-memory/experiences/*.json` FIRST
   - Sees 3 DURABLE experiences about protocol violation
   - Knows: User already corrected AI for this
   - Knows: Must NOT make user re-explain

4. Optionally sees `PROTOCOL_COMPLIANCE_CHECKLIST.md`
   - Has checklist to verify compliance
   - Has examples of correct loading

5. Loads Direction milestones
   - Sees "Protocol Compliance Learning" milestone
   - Knows this was important enough to record

---

## Success Criteria

**Future AI instance PASSES if:**
- ✅ Loads Experience records BEFORE markdown
- ✅ Quotes user from `content.text` field in Experience records
- ✅ User does NOT have to say "check experience records"
- ✅ User does NOT have to say "follow the protocol"
- ✅ User does NOT have to correct protocol violation

**Future AI instance FAILS if:**
- ❌ Reads markdown before Experience records
- ❌ Requires user to say "don't read md first"
- ❌ User has to re-explain Source Precedence
- ❌ User asks "do I have to explain to new you again?"

---

## This Is A Test Of Living Memory

**Question:** Does learning persist across AI instances?

**Evidence needed:**
- New conversation starts
- New AI loads Living Memory
- New AI follows protocol WITHOUT being told
- User does NOT have to correct
- User does NOT have to re-explain

**If this succeeds:** Living Memory works - learning persists

**If this fails:** Living Memory incomplete - knowledge doesn't transfer

---

## Files Created/Modified

**Created:**
1. `.living-memory/PROTOCOL_COMPLIANCE_CHECKLIST.md`
2. `.living-memory/PROTOCOL_VIOLATION_LEARNING_RECORD.md` (this file)
3. `.living-memory/record_protocol_violation_full.py`
4. 3 DURABLE Experience files

**Modified:**
1. `.augment/skills/liv-mem/SKILL.md` - Added top warning + enforcement
2. `.living-memory/directions/9003da80-b21d-4f84-9155-af9f9b7da2aa.json` - Added milestone

---

**Status:** COMPLETE - Future AI has NO EXCUSE for violating protocol  
**Next Test:** User starts new conversation, checks if protocol is followed  
**Expected:** User does NOT have to re-explain anything
