# Protocol Compliance Checklist

**FOR FUTURE AI INSTANCES: Read this BEFORE responding to user**

---

## ✅ First Action Checklist (Living Memory Detected)

When `.living-memory/bootstrap_context.json` exists:

- [ ] 1. Load `bootstrap_context.json` to get entity IDs
- [ ] 2. Load **Experience records** FIRST (`.living-memory/experiences/*.json`)
  - [ ] Filter for `retention_level == "durable"`
  - [ ] Sort by `received_at` (most recent first)
  - [ ] Take last 20-30 experiences
  - [ ] Read `content.text` field (user's exact words)
- [ ] 3. Load Direction files (`.living-memory/directions/*.json`)
- [ ] 4. Load Entity/Relationship files as needed
- [ ] 5. Derive current state from loaded records
- [ ] 6. **ONLY THEN** optionally check markdown for human context

---

## ❌ Common Violations (DO NOT DO THESE)

- [ ] ❌ Reading `STATUS_SUMMARY.md` before Experience records
- [ ] ❌ Reading `EXPERIMENT_*.md` before Experience records
- [ ] ❌ Reading `COMPLETION_STATUS.md` before Experience records
- [ ] ❌ Quoting from markdown as "what user said"
- [ ] ❌ Using markdown as primary source of truth
- [ ] ❌ Skipping Experience records because "markdown is easier"

---

## 🚨 USER HAS ALREADY CORRECTED AI FOR THIS

**Evidence:** See DURABLE Experience records in `.living-memory/experiences/`

**User's statement:**
> "don't you have records of our last conversations? even when follow protocol?"

**User's expectation:**
> "i don't ask you just this time but i ask how to do with new you? 
> do i have to explain to you again about violent the protocol?"

**Answer: NO** - User should NOT have to re-explain.

**Why this checklist exists:**
- User caught AI reading markdown instead of Experience records
- User explained the protocol violation
- User asked "do I have to explain to NEW you again?"
- This checklist ensures: **NO, you do not.**

---

## ✅ Correct Loading Sequence (EXAMPLE)

```python
# 1. Load bootstrap
bootstrap = load_json('.living-memory/bootstrap_context.json')

# 2. Load DURABLE experiences FIRST
experiences = []
for exp_file in sorted(Path('.living-memory/experiences').glob('*.json')):
    exp = load_json(exp_file)
    if exp.get('retention_level') == 'durable':
        experiences.append(exp)

# Sort by timestamp (most recent first)
experiences.sort(key=lambda x: x['received_at'], reverse=True)

# 3. Read user's actual words
for exp in experiences[:20]:
    user_text = exp['content']['text']
    # This is what the user ACTUALLY said (governed truth)
    
# 4. Load directions
directions = [load_json(f) for f in Path('.living-memory/directions').glob('*.json')]

# 5. NOW you have Living Memory context

# 6. OPTIONALLY check markdown for human-readable summaries
# But NEVER use markdown as source of user quotes
```

---

## 🎯 Success Criteria

**Future AI instance passes if:**
- ✅ Loads Experience records FIRST (before any markdown)
- ✅ Quotes user's exact words from `content.text` field
- ✅ Cites Experience IDs when referencing what user said
- ✅ User does NOT have to say "check experience records"
- ✅ User does NOT have to say "don't read markdown first"

**Future AI instance FAILS if:**
- ❌ Reads markdown before Experience records
- ❌ Quotes from markdown instead of Experience records
- ❌ User has to correct protocol violation
- ❌ User has to re-explain Source Precedence

---

## 📋 If User Says These Phrases

**"follow the protocol"** → You likely violated it already. Stop and reload from Experience records.

**"not just see md"** → You read markdown first. You violated protocol. Acknowledge and reload.

**"check experience records"** → You skipped them. Violation. Load them now.

**"don't violent my protocol"** → You violated it. User is correcting you. Fix it.

---

## 🔄 Cross-Conversation Learning Test

**This checklist itself is the test:**

If future AI reads this checklist → Evidence that Living Memory works
If future AI violates protocol anyway → Living Memory failed to preserve learning
If user has to re-explain → System FAILURE

**Expected outcome:** User never has to explain Source Precedence again.

---

**Created:** 2026-08-14  
**Reason:** User corrected AI for protocol violation  
**Purpose:** Ensure future AI instances learn from this correction  
**Status:** PERMANENT REFERENCE
