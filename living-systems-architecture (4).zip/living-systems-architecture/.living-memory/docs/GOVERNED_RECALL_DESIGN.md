# Governed Recall Function Design

## Problem Statement

**Current violation:** AI uses direct filesystem search (PowerShell, grep) to find past experiences, bypassing Living Memory architecture.

**Why this violates core concepts:**
- Treats Living Memory as a file storage system, not a living system
- Bypasses Memory Control, Governance, Historical Integration, Relevance
- Relies on "search skills" instead of architectural coherence

**From ref 03, line 36:**
> "Require Skills to operate through Memory Control and Memory Governance rather than bypassing them."

---

## Architectural Flow

```
CURRENT QUESTION (user asks about past)
  ↓
MEMORY CONTROL (perceives recall request)
  ↓
HISTORICAL INTEGRATION (finds connected experiences)
  ↓
RELEVANCE EVALUATION (filters by current context/Direction)
  ↓
MEMORY GOVERNANCE (validates what should be recalled)
  ↓
GOVERNED RECALL RESULTS (relevant, governed past experiences)
```

---

## Design: `recall_relevant_experiences()`

### Location
`memory_control.py` (Memory Control is "first point of contact" per ref 02)

### Signature
```python
def recall_relevant_experiences(
    self,
    query_context: Dict[str, Any],
    current_directions: List[str] = None,
    retention_levels: List[str] = None,
    limit: int = 20
) -> Dict[str, Any]
```

### Inputs

| Parameter | Type | Purpose | Example |
|---|---|---|---|
| `query_context` | Dict | Current situation requiring recall | `{"type": "user_question", "text": "experiment from first conversation", "entities": [...]}` |
| `current_directions` | List[str] | Active direction IDs for relevance | `["dir-1", "dir-2"]` |
| `retention_levels` | List[str] | Filter by retention (default: DURABLE only) | `["durable"]` |
| `limit` | int | Max results | `20` |

### Processing Steps

**1. Memory Control: Perception**
- Parse query_context to identify: entities mentioned, time references, topics, relationship types
- Determine what kind of recall: historical event, state snapshot, relationship, pattern

**2. Historical Integration: Connection Discovery**
- Use `historical_integration.find_related_experiences()` to discover connected experiences
- Check event relations, integration assertions, patterns
- Build candidate set from History

**3. Relevance Evaluation**
- Use `memory_governance.evaluate_relevance_for_recall()` (NEW method)
- Check if candidate experiences relate to:
  - Current Entity
  - Current State
  - Active Relationship
  - Current Direction
  - Previously established context
  - Query entities/topics

**4. Memory Governance: Validation**
- Filter by retention_level (DURABLE default)
- Check truth_status (prefer EFFECTIVE > SUPPORTED > ASSERTED)
- Verify provenance (source, timestamps)
- Apply governance boundaries

**5. Return Governed Results**
- Sorted by relevance score + recency
- With provenance: experience_id, source, timestamp, retention_level, truth_status
- With relevance_reason: why each was recalled

### Output Structure

```json
{
  "query": {
    "context": {...},
    "directions": [...],
    "timestamp": "2026-08-14T14:30:00Z"
  },
  "recall_method": "governed_historical_integration",
  "candidates_considered": 150,
  "results_returned": 10,
  "experiences": [
    {
      "id": "b9e6280d-...",
      "occurred_at": "2026-08-13T10:59:15Z",
      "source": "system",
      "retention_level": "durable",
      "truth_status": "effective",
      "content": {...},
      "relevance_score": 0.95,
      "relevance_reason": "Matches query topic 'experiment', connected to Direction 'implement living memory system'",
      "connections": ["integration_assertion_id_1", "event_relation_id_2"]
    }
  ],
  "governance_decision": {
    "filtered_by_retention": 50,
    "filtered_by_relevance": 90,
    "final_count": 10
  }
}
```

---

## New Method Needed in `memory_governance.py`

```python
def evaluate_relevance_for_recall(
    self,
    experience: Dict,
    query_context: Dict,
    current_directions: List[str]
) -> Dict[str, Any]:
    """
    Evaluate if historical experience is relevant to current recall request
    
    Per ref 03 lines 11:
    "Relevance can come from current Entity, current State, active Relationship,
     recent change, historical origin, current Direction, previously established
     context, or a newly discovered Relationship."
    
    Returns: {
        "is_relevant": bool,
        "relevance_score": float,  # 0.0-1.0
        "reason": str
    }
    """
```

---

## Comparison: Direct Search vs Governed Recall

| Aspect | Direct Search (WRONG) | Governed Recall (CORRECT) |
|---|---|---|
| **Entry point** | Filesystem/PowerShell | Memory Control |
| **Discovery** | Keyword matching | Historical Integration |
| **Filtering** | Manual grep pattern | Relevance + Governance |
| **Context awareness** | None | Current Directions, State, Relationships |
| **Provenance** | File metadata only | Full governance metadata |
| **Architecture** | Bypassed | Followed |
| **Result** | Files matching keywords | Governed, relevant memories |

---

## Implementation Order

1. ✅ Design (this document)
2. ⏳ Add `evaluate_relevance_for_recall()` to `memory_governance.py`
3. ⏳ Add `recall_relevant_experiences()` to `memory_control.py`
4. ⏳ Add helper to `historical_integration.py` for connection discovery
5. ⏳ Test: same recall query through both methods, compare results
6. ⏳ Update AI protocol to ALWAYS use governed recall

---

## Success Criteria

✅ **Architectural compliance:** All recall goes through Memory Control → Historical Integration → Relevance → Governance
✅ **Accuracy:** Finds same or better results than direct search
✅ **Context awareness:** Results filtered by current Direction and Relationships
✅ **Provenance:** Full governance metadata in results
✅ **No violations:** Zero direct filesystem access for recall
