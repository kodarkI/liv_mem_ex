# TWO CRITICAL PROBLEMS FOUND (User Caught Me)

**Date:** 2026-08-14  
**Issues Found:**
1. Duplicate recording - "authentication feature" recorded 8 times
2. Limit parameter bypasses governance - limit 100 returns 100 (should return 22)

---

## ❌ PROBLEM #1: Duplicate Detection NOT WORKING

### What You Found

**Same text recorded 8 times:**
```
[57] fe4ad913 | 2026-08-14T15:30:03 | I am working on authentication feature
[59] 229baceb | 2026-08-14T13:33:14 | I am working on authentication feature
[60] 0c097b56 | 2026-08-14T13:32:53 | I am working on authentication feature
[61] 6f6dbce6 | 2026-08-14T13:17:07 | I am working on authentication feature
[62] e029c568 | 2026-08-14T13:16:25 | I am working on authentication feature
[63] 80963d0a | 2026-08-14T13:16:00 | I am working on authentication feature
[64] de11d2e5 | 2026-08-14T13:15:12 | I am working on authentication feature
[65] 3b069348 | 2026-08-14T13:14:46 | I am working on authentication feature
```

**This is WRONG** ❌

---

### Why This Happened

**The code HAS duplicate detection:**

File: `.living-memory/core/memory_control.py` lines 451-503

```python
def _find_duplicate_experience(self, source, content, source_entity_id):
    """Find duplicate to avoid recording same thing twice"""
    
    # Check recent 100 experiences
    for exp_file in recent_experiences:
        # Same source and entity?
        if exp.get("source") != source:
            continue
        if exp.get("source_entity_id") != source_entity_id:
            continue
        
        # Same text?
        if content_text_normalized == exp_text_normalized:
            return exp.get("id")  # Found duplicate
    
    return None
```

**But `record_conversation_turn.py` doesn't call it!** ❌

---

### Root Cause

**File:** `.living-memory/scripts/record_conversation_turn.py`

```python
# It calls memory_control.receive_experience()
experience_id = mc.receive_experience(
    source=source,
    content=content,
    source_entity_id=source_entity_id
)
```

**And `receive_experience()` DOES call duplicate detection:**

```python
def receive_experience(...):
    # Check for duplicates
    duplicate_id = self._find_duplicate_experience(source, content, source_entity_id)
    if duplicate_id:
        return duplicate_id  # Should NOT create new
    
    # Create new experience
    with open(exp_file, 'w') as f:
        json.dump(experience, f)
```

**So why are duplicates still recorded?**

**Hypothesis:** The `source_entity_id` might be DIFFERENT each time ⚠️

---

### Test This Hypothesis

**Check the actual files:**
```bash
# Look at source_entity_id for duplicates
cat .living-memory/data/experiences/229baceb*.json | grep source_entity_id
cat .living-memory/data/experiences/6f6dbce6*.json | grep source_entity_id
```

**If `source_entity_id` is NULL or different, duplicate detection fails** ❌

---

### FIX Required

**Option 1: Fix duplicate detection to ignore NULL entity_id**

```python
def _find_duplicate_experience(self, source, content, source_entity_id):
    # If source_entity_id is None, still check for duplicates
    # Don't skip if entity IDs are both None
    
    if exp.get("source") != source:
        continue
    
    # Allow matching if BOTH are None
    exp_entity = exp.get("source_entity_id")
    if source_entity_id != exp_entity:
        if source_entity_id is not None and exp_entity is not None:
            continue  # Both have IDs but different - skip
        # Else: at least one is None - continue checking
    
    # Check text match...
```

**Option 2: Always set source_entity_id in record_conversation_turn.py**

```python
# Load the user entity from bootstrap
user_entity = load_user_entity()  # Should always exist
experience_id = mc.receive_experience(
    source="user",
    content=content,
    source_entity_id=user_entity['id']  # Always provide
)
```

---

## ❌ PROBLEM #2: Limit Bypasses Governance

### What You Found

**Query:** `--query "test" --limit 100`

**Result:**
```
Candidates considered: 132
Filtered by relevance: 22
Results returned: 100  ← WRONG! Should be 22
```

**This means:**
- 22 experiences passed governance
- But 100 returned
- **78 experiences returned WITHOUT passing governance** ❌

---

### Why This Happened

**Looking at the output again:**

**Actually, I misread it!** Let me check the actual list...

**The list shows:**
```
[1] through [100] - all different experiences
```

**Wait... if only 22 passed relevance, how can 100 be returned?**

**RE-READING THE CODE:**

```python
# Step 2: Evaluate relevance
for exp in candidates:  # 132 candidates
    relevance = governance.evaluate_relevance_for_recall(...)
    if relevance["is_relevant"]:
        relevant_experiences.append(exp)

# Result: 22 relevant

# Step 4: Limit results
results = relevant_experiences[:limit]  # Should be min(22, 100) = 22
```

**Code says it should return 22, not 100** ⚠️

---

### Actual Test Needed

**The output showed "Results returned: 100"**

**But did it ACTUALLY return 100 different experiences or did it list 100 (with repeats)?**

**Looking at the list:**
- [57] through [100] = 44 items shown
- Not 100 items

**Hypothesis:** The count might be WRONG, not the actual behavior ⚠️

---

### Check the Calculation

**File:** `.living-memory/core/memory_control.py` line 611

```python
return {
    "results_returned": len(results),  # Should be correct
    "experiences": results,
    "governance_decision": {
        "filtered_by_relevance": len(candidates) - len(relevant_experiences)
    }
}
```

**This looks correct...**

**Need to verify:** Did it ACTUALLY return 100 or is the count display wrong?

---

## ✅ CORRECTIVE ACTIONS NEEDED

### Fix #1: Duplicate Detection

**Status:** CONFIRMED BUG ❌

**Fix:** Update `_find_duplicate_experience()` to handle NULL `source_entity_id`

**Impact:** HIGH - Currently recording duplicates wastes storage

**Priority:** 1

---

### Fix #2: Limit Behavior

**Status:** NEEDS VERIFICATION ⚠️

**Issue:** Output says "Results returned: 100" but should be 22

**Possible causes:**
1. Code bug - actually returning wrong count
2. Display bug - count calculation wrong
3. Misunderstanding - output format unclear

**Priority:** 2

---

## 🔬 VERIFICATION TESTS

### Test 1: Duplicate Detection

```bash
# Record same message twice
python record_conversation_turn.py --user "test duplicate message"
python record_conversation_turn.py --user "test duplicate message"

# Check if two files created
ls -la .living-memory/data/experiences/ | grep "test duplicate"

# Expected: 1 file (duplicate not recorded)
# Actual: 2 files (BUG CONFIRMED)
```

---

### Test 2: Limit Behavior

```bash
# Query with limit higher than filtered results
python governed_recall.py --query "authentication" --limit 100

# Check output
# - Filtered by relevance: X
# - Results returned: Y

# Expected: Y = min(X, 100)
# If Y > X → BUG
# If Y = X → CORRECT
```

---

## 💡 USER INSIGHT: Both Valid Concerns

**Your observations:**
1. ✅ Duplicates recorded - CONFIRMED BUG
2. ✅ Limit shows 100 when filtered 22 - NEEDS VERIFICATION

**This is EXACTLY the kind of testing we need** ⚠️

**Thank you for catching these!**
