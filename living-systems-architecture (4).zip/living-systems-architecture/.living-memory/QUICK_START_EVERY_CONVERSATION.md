# Quick Start: Every New Conversation

**Use this EVERY time you start a new conversation with AI.**

---

## 🎯 Your First Message (Copy-Paste This)

```
Run these commands BEFORE responding to me:

1. python .living-memory/scripts/initialize_context.py
2. List 3 most recent DURABLE experience IDs and what they say

Then respond to my actual request.
```

---

## ✅ What This Does

### Command 1: Initialization
- Forces AI to load Living Memory in CORRECT order
- Shows AI all DURABLE experiences first
- Explicitly warns AI NOT to read markdown
- Makes experience records visible before AI responds

### Command 2: Proof Check
- Forces AI to PROVE it read the experiences
- AI must cite experience IDs (not markdown)
- If AI can't cite IDs, it violated protocol

---

## 🔍 How to Verify AI Followed Protocol

### ✅ Good Response (Protocol Followed):
```
AI: [runs initialize_context.py, sees output]

Recent DURABLE experiences:
1. 30885d2e... - User: "let do what you think that you won't miss anything"
2. afc43eb3... - User: "create folder for test..."
3. 271b2391... - Agent: "Protocol execution fix complete..."

[AI then responds to your actual request]
```

### ❌ Bad Response (Protocol Violated):
```
AI: Based on the STATUS_SUMMARY.md file, we were working on...
```

**If AI cites markdown → STOP and say:**
```
You violated protocol. Re-run initialization and cite experience IDs.
```

---

## 📋 End of Conversation Validation

**Before ending conversation, run:**
```
python .living-memory/scripts/validate_protocol_compliance.py
```

**This checks:**
- Were user messages recorded as Experiences?
- Were AI responses recorded as Experiences?
- Is the conversation now durable in Living Memory?

**If it shows violations → Tell AI:**
```
You violated protocol. The conversation was not recorded.
```

---

## 🔄 Why This is Necessary

**Problem:** AI is stateless. Each new conversation starts fresh.

**Current state:**
- SKILL.md tells AI to follow protocol
- But AI can IGNORE or MISINTERPRET instructions
- No automatic enforcement yet

**Solution:** YOU enforce it manually by:
1. Starting EVERY conversation with initialization command
2. Forcing AI to prove it loaded experiences
3. Validating at end of conversation

---

## 💡 What Makes This "Close to Permanent"

### Before This Update:
- Protocol was conceptual (AI interpreted guidelines)
- AI could skip steps
- No validation
- No proof required

### After This Update:
- Protocol is EXECUTABLE (specific commands)
- AI must run scripts to comply
- Validation script detects violations
- AI must prove it loaded experiences

### Still Not Perfect Because:
- You must manually trigger each conversation
- Next AI instance could still ignore instructions
- Platform doesn't auto-run initialization

### But Much Better Because:
- Clear mechanical steps
- Provable compliance
- Automatic violation detection
- Harder for AI to accidentally violate

---

## 📖 Example Full Conversation

**You:**
```
Run these commands BEFORE responding:
1. python .living-memory/scripts/initialize_context.py
2. List 3 DURABLE experience IDs

Then: What were we working on last session?
```

**AI:**
```
[runs initialize_context.py]
[sees 45 DURABLE experiences loaded]

Recent DURABLE experiences:
- be10c69b... (2026-08-14): Agent: "Honest answer: NO, not permanent yet..."
- 3848889d... (2026-08-14): Agent: "To make me permanently follow protocol..."
- acb488c7... (2026-08-14): Agent: "You're absolutely correct. I found the violation..."

Last session we worked on protocol enforcement. You asked how to make me
permanently follow protocol. I created:
- initialize_context.py (forces correct loading)
- validate_protocol_compliance.py (detects violations)
- Updated SKILL.md to be more mechanical

Status: Not permanent yet, requires manual enforcement each conversation.
```

**You (at end):**
```
python .living-memory/scripts/validate_protocol_compliance.py
```

**AI:**
```
[runs validation]
PROTOCOL COMPLIANCE: PASS
- User message recorded
- Agent response recorded
- Conversation is now durable
```

---

## 🎯 Summary

**Every conversation:**
1. Start with initialization command
2. Make AI prove it by citing experience IDs
3. Validate compliance at end

**This is the closest to permanent we can get** without platform-level automation.
