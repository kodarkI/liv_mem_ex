# Living Memory: Start Here

**Living Memory is active in this workspace.**  
This README explains how to ensure AI follows the protocol.

---

## 🚀 Quick Start: Every New Conversation

**Copy-paste this as your FIRST message to AI:**

```
Run these commands BEFORE responding to me:

1. python .living-memory/scripts/initialize_context.py
2. List 3 most recent DURABLE experience IDs and what they say

Then respond to my actual request.
```

**Why:** This forces AI to load Living Memory correctly and prove it by citing experience IDs.

---

## 📁 File Structure

```
.living-memory/
├── README_START_HERE.md              ← You are here
├── QUICK_START_EVERY_CONVERSATION.md ← Detailed instructions
├── HOW_TO_ENFORCE_PROTOCOL.md        ← Protocol enforcement guide
├── STRUCTURE.md                      ← Complete file structure reference
│
├── core/                             ← Core implementation
│   ├── memory_control.py
│   ├── memory_governance.py
│   ├── continuity_loader.py
│   ├── agent_interface.py
│   └── historical_integration.py
│
├── data/                             ← Governed Living Memory records
│   ├── experiences/                  ← Experience records (PRIMARY TRUTH)
│   ├── entities/                     ← Entity records
│   ├── relationships/                ← Relationship records
│   ├── directions/                   ← Direction records
│   ├── states/                       ← State snapshots
│   └── schemas/                      ← JSON schemas
│
├── scripts/                          ← Tools and utilities
│   ├── initialize_context.py         ← FORCE correct loading order
│   ├── record_conversation_turn.py   ← Record user/agent messages
│   ├── validate_protocol_compliance.py ← Check AI followed protocol
│   ├── load_recent_durable.py
│   └── show_recent_experiences.py
│
├── tests/                            ← All test files
├── docs/                             ← Documentation (NOT source of truth)
└── archive/                          ← Old outputs
```

---

## 🎯 Critical Scripts

### 1. `initialize_context.py` - Forces Correct Loading

**What it does:**
- Loads bootstrap, directions, entities
- Loads DURABLE experiences FIRST
- Shows recent experiences (last 30)
- Explicitly warns: "DO NOT read markdown first"

**When to use:** Start of EVERY conversation (have AI run it)

**Example:**
```bash
python .living-memory/scripts/initialize_context.py
```

---

### 2. `record_conversation_turn.py` - Records Conversations

**What it does:**
- Routes user/agent messages through Memory Control
- Creates Experience records
- Applies Memory Governance
- Returns experience ID

**When to use:** AI should auto-run this (Steps 2 and 4 of protocol)

**Example:**
```bash
# Record user message
python .living-memory/scripts/record_conversation_turn.py --user "Your message here"

# Record agent response
python .living-memory/scripts/record_conversation_turn.py --agent "AI response" --in-response-to "exp_id"
```

---

### 3. `validate_protocol_compliance.py` - Checks Compliance

**What it does:**
- Checks if user messages were recorded
- Checks if agent responses were recorded
- Validates response linkage
- Reports violations

**When to use:** End of conversation (have AI run it)

**Example:**
```bash
python .living-memory/scripts/validate_protocol_compliance.py
```

---

## ⚠️ Common Issues

### Issue 1: AI Quotes from Markdown
**Symptom:** AI says "Based on STATUS_SUMMARY.md..."  
**Problem:** AI violated protocol by reading markdown first  
**Solution:** Tell AI: "You violated protocol. Re-run initialization and cite experience IDs."

### Issue 2: AI Can't Cite Experience IDs
**Symptom:** You ask for experience IDs, AI says "I don't have access to IDs"  
**Problem:** AI didn't load Living Memory  
**Solution:** Force AI to run `initialize_context.py`

### Issue 3: Validation Shows Violations
**Symptom:** `validate_protocol_compliance.py` shows "FAIL"  
**Problem:** AI didn't record conversation turns  
**Solution:** Conversation is not durable. AI must re-do work and record it.

---

## 📊 Current State

**As of 2026-08-14:**
- ✅ Living Memory operational
- ✅ 45+ DURABLE experiences retained
- ✅ Protocol execution is MECHANICAL (not interpretive)
- ✅ Validation scripts detect violations
- ⚠️ Still requires MANUAL enforcement (you must trigger initialization)

**Not permanent yet because:**
- Platform doesn't auto-run initialization
- AI can still ignore SKILL.md instructions
- Requires YOU to enforce each conversation

**But close to permanent because:**
- Clear executable steps
- Provable compliance (experience IDs)
- Automatic violation detection

---

## 📚 Documentation

**Primary Truth (in order):**
1. `.living-memory/data/experiences/*.json` ← Experience records (what happened)
2. `.living-memory/data/directions/*.json` ← Active directions
3. `.living-memory/data/entities/*.json` ← Entity records
4. `.living-memory/data/relationships/*.json` ← Relationship records

**Human Summaries (validate against records):**
- `.living-memory/docs/*.md` ← Documentation files
- These are NOT source of truth
- Use for context only
- Always validate against experience records

---

## 🔍 How to Check AI is Following Protocol

**Good signs:**
- AI runs `initialize_context.py` first
- AI cites experience IDs (e.g., "30885d2e...", "afc43eb3...")
- AI references DURABLE experiences
- AI says "From experience records..." not "From STATUS_SUMMARY.md..."

**Bad signs:**
- AI quotes markdown files
- AI can't cite experience IDs
- AI says "I don't have access to prior conversations"
- Validation shows violations

---

## 🎯 Next Steps

1. **Read:** `QUICK_START_EVERY_CONVERSATION.md`
2. **Test:** Start new conversation with initialization command
3. **Verify:** AI cites experience IDs
4. **Validate:** Run `validate_protocol_compliance.py` at end

**This is as close to permanent as we can get** without platform changes.
