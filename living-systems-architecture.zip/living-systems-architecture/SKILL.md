---
name: living-systems-architecture
description: Apply when designing, reviewing, or documenting a system that must preserve continuity through change across identity, current state, relationships, history, relevance, and direction; use it to structure living memory and explicitly surface unresolved lower-level mechanics rather than inventing them.
---

# Living Systems Architecture

## Overview

Apply this conceptual architecture to systems that must retain meaningful continuity while their current state, relationships, and context can change. Preserve the defined distinctions; do not turn unspecified mechanics into requirements.

The central principle is: **Living memory is continuity through change.**

## Closed learning loop

Apply this complete loop without making any transition automatic:

```text
Experience → Living Memory → Pattern Recognition → Emerging Capability
→ Skill Creation → Skill Reuse → Execution / Outcome → Evidence
→ Candidate Experience → Retention Decision → Feedback into Memory → Skill Evolution
→ Living Memory
```

Use these answers as non-negotiable distinctions:

| Question | Answer |
|---|---|
| What qualifies as memory? | Evidence about a specific situation: what happened, was asserted, changed, or related, retained with provenance, scope, and History. |
| What qualifies as an emerging capability? | A candidate reusable way to act, evaluate, transform, interpret, decide, communicate, or organize within a stated scope and boundary. |
| When does it become an explicit Skill? | Only when it is sufficiently **understood, reproducible, useful, and expressible**. Recurrence is evidence, not a requirement or automatic trigger. |
| How does a Skill evolve? | Material application evidence may become a candidate Experience and, after retention, lineage evidence that can confirm, revise, split, merge, retire, or reactivate a versioned Skill. |
| How does the AI reuse a Skill? | Retrieve a Skill only when its declared scope, boundaries, current Direction, and expected outcome fit the present situation; apply it through Memory Control and Governance, then evaluate whether its outcome deserves to become Experience. |

Read [Capability emergence and Skill lineage](references/14-capability-emergence-and-skill-lineage.md) for the operating rules behind this loop.

## Canonical-source precedence

Treat [Living Systems Architecture v0.5](../docs/Living%20system%20doc%20v5.txt) and its [architecture diagram](../docs/Living%20architecture%20system%20v5.txt) as the canonical source of truth for architectural concepts and terminology. This skill defines operating behavior that applies the architecture.

When they conflict, preserve the canonical architecture and record the skill-level rule as a refinement candidate; do not silently redefine the architecture. Do not promote every operational discovery into the architecture. See the [canonical alignment review](../docs/canonical-alignment-review.md).

## Reference map

Read the needed reference before drafting or reviewing a design:

- [Foundations](references/01-foundations.md): core idea, principles, and central distinctions.
- [Core layers](references/02-core-layers.md): Current Experience through Living Memory.
- [Living cycle and Skills](references/03-living-cycle-and-skills.md): flow, Direction / Intent, and operations.
- [Operating contracts](references/04-operating-contracts.md): component ownership, records, inputs, outputs, and low-level behavior.
- [Lifecycle and failure handling](references/05-lifecycle-and-failure-handling.md): transition guards, edge cases, and required outcomes.
- [Open design questions](references/06-open-design-questions.md): intentionally undecided mechanics and project extension points.
- [Architecture audit](references/07-architecture-audit.md): what this revision resolved and what remains open.
- [Memory lifecycle, truth, and promotion](references/08-memory-lifecycle-truth-and-promotion.md): how memory changes over time, resolves conflict, and earns durable retention.
- [Self-auditing and skill evolution](references/09-self-auditing-and-skill-evolution.md): degradation detection, recurring weakness analysis, and versioned rule refinement.
- [Attention and activation policy](references/10-attention-and-activation-policy.md): restricted attention, priority, triggers, focus budget, release, and reopening rules.
- [Event relationship semantics and chains](references/11-event-relationship-semantics-and-chains.md): typed event-to-event relations, causal/state-transition chains, and historical reconstruction.
- [Living-memory challenge suite](references/12-living-memory-challenge-suite.md): adversarial scenarios, expected outcomes, and skill-evolution feedback.
- [Adversarial regression catalog](references/13-adversarial-regression-catalog.md): permanent hostile cases, attacked assumptions, and replay protocol.
- [Capability emergence and Skill lineage](references/14-capability-emergence-and-skill-lineage.md): how reusable capabilities emerge from memory, become explicit Skills, and evolve through lineage.
- [Selective capability discovery and outcome attribution](references/15-selective-capability-discovery-and-outcome-attribution.md): attention-governed discovery, scoped inspection, and evidence-based interpretation of Skill outcomes.
- [Skill-set coordination and candidate hygiene](references/16-skill-set-coordination-and-candidate-hygiene.md): coordinate multiple applicable Skills and prevent Candidate-capability accumulation.
- [Runtime validation boundary](references/17-runtime-validation-boundary.md): separate specification from runtime behavior and define validation responsibilities.

## Apply the architecture

1. Preserve the separation of **Entity**, **State**, **Relationship**, and **History**.
2. Route Current Experience through **Memory Control** before assigning permanence, currentness, or relationship status.
3. Apply **Memory Governance** before treating an item or Relationship as established or active.
4. Keep historical occurrences intact when current State, Relationships, or contextual interpretation change.
5. Use **Historical Integration** to connect experiences and make older History relevant without rewriting it.
6. Form **Living Memory** from identity, current State, active Relationships, relevant and dormant History, integrated context, and Direction.
7. Make Skills operate through Memory Control and Memory Governance.
8. Apply the baseline operating decisions in [Operating contracts](references/04-operating-contracts.md) and [Lifecycle and failure handling](references/05-lifecycle-and-failure-handling.md), unless the project explicitly overrides them.
9. Apply the memory lifecycle and truth rules in [Memory lifecycle, truth, and promotion](references/08-memory-lifecycle-truth-and-promotion.md) to every memory-bearing record.
10. Run or design the self-auditing and skill-evolution process in [Self-auditing and skill evolution](references/09-self-auditing-and-skill-evolution.md) for a continuing system.
11. Apply [Attention and activation policy](references/10-attention-and-activation-policy.md) so availability, activation, and focused attention remain distinct.
12. Apply [Event relationship semantics and chains](references/11-event-relationship-semantics-and-chains.md) when Events relate to Events, claims, interpretations, or State transitions; do not collapse them into generic association.
13. Use [Living-memory challenge suite](references/12-living-memory-challenge-suite.md) when validating or refining this architecture; record failed challenges as evidence for governed Skill evolution.
14. Run and retain [Adversarial regression catalog](references/13-adversarial-regression-catalog.md) cases after material changes; do not consider a refinement complete until relevant failed cases are replayed.
15. Apply [Capability emergence and Skill lineage](references/14-capability-emergence-and-skill-lineage.md) when proposing, creating, revising, splitting, merging, retiring, or evaluating a Skill that emerges from Living Memory.
16. Apply [Selective capability discovery and outcome attribution](references/15-selective-capability-discovery-and-outcome-attribution.md) before searching memory for a Candidate capability or treating a Skill outcome as evidence for revision.
17. Apply [Skill-set coordination and candidate hygiene](references/16-skill-set-coordination-and-candidate-hygiene.md) when multiple Skills fit an issue or a Candidate capability is created, deferred, externalized, rejected, or expires.
18. Use [Runtime validation boundary](references/17-runtime-validation-boundary.md) to report specification status separately from runtime evidence and tests.
19. Identify every remaining unresolved lower-level mechanism explicitly. Do not silently invent rules outside these defined baselines.

## Required design output

When applying this pattern to a project, document:

- the project-specific Entity, State, Relationship, and History models;
- Memory Governance and Relevance rules;
- the project’s Direction / Intent model;
- contracts for each applicable Skill; and
- every unresolved question from [Open design questions](references/06-open-design-questions.md).
