#!/usr/bin/env python3
"""
Test Historical Integration Implementation
Tests chain traversal, path finding, and inference without rewriting history
"""
import sys
import io
from pathlib import Path

if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

from memory_control import MemoryControl
from memory_governance import MemoryGovernance
from historical_integration import HistoricalIntegration

print("=" * 80)
print("HISTORICAL INTEGRATION TEST")
print("=" * 80)
print()

memory_root = Path(__file__).parent
mc = MemoryControl(memory_root)
mg = MemoryGovernance(memory_root)
hi = HistoricalIntegration(memory_root)

# Create test scenario: A causes B, B enables C, C produces D
print("SETUP: Creating Relationship Chain")
print("-" * 80)
print("Chain: A -> causes -> B -> enables -> C -> produces -> D")
print()

exp1 = mc.receive_experience(source="test", content={"type": "observation", "text": "A causes B"})
exp2 = mc.receive_experience(source="test", content={"type": "observation", "text": "B enables C"})
exp3 = mc.receive_experience(source="test", content={"type": "observation", "text": "C produces D"})

# Create relationships
rel1 = mg.propose_relationship("entity_a", "CAUSES", "entity_b", exp1)
rel2 = mg.propose_relationship("entity_b", "ENABLES", "entity_c", exp2)
rel3 = mg.propose_relationship("entity_c", "PRODUCES", "entity_d", exp3)

# Advance relationships to different statuses
mg.apply_relationship_governance(rel1, exp1)  # A->B: candidate
mg.apply_relationship_governance(rel2, exp2)  # B->C: candidate
mg.apply_relationship_governance(rel3, exp3)  # C->D: candidate

print(f"Created 3 relationships:")
print(f"  1. A CAUSES B (status: candidate)")
print(f"  2. B ENABLES C (status: candidate)")
print(f"  3. C PRODUCES D (status: candidate)")
print()

# TEST 1: Chain Traversal
print("TEST 1: Traverse Chain from A")
print("-" * 80)

chain = hi.traverse_chain("entity_a", max_depth=10)

print(f"Chain length: {len(chain)} relationships")
print()

for i, link in enumerate(chain):
    print(f"{i+1}. {link['subject_id']} --[{link['predicate']}]--> {link['object_id']}")
    print(f"   Status: {link['status']}, Depth: {link['depth']}")

print()

# TEST 2: Path Finding
print("TEST 2: Find Path from A to D")
print("-" * 80)

path = hi.find_path("entity_a", "entity_d")

if path:
    print(f"Path found: {len(path)} steps")
    print()
    for i, rel in enumerate(path):
        print(f"Step {i+1}: {rel['subject_id']} --[{rel['predicate']}]--> {rel['object_id']}")
else:
    print("No path found")

print()

# TEST 3: Infer Relationship
print("TEST 3: Infer Relationship between A and D")
print("-" * 80)

inference = hi.infer_relationship("entity_a", "entity_d")

print(f"Connected: {inference['connected']}")
print(f"Inference: {inference['inference']}")
print(f"Chain length: {inference['chain_length']}")
print(f"Predicates: {' -> '.join(inference['predicates'])}")
print(f"Weakest link: {inference['weakest_link']}")
print(f"Caution: {inference.get('caution', 'N/A')}")
print()

# TEST 4: Find Related Experiences
print("TEST 4: Find Experiences Related to B")
print("-" * 80)

related_exps = hi.find_related_experiences("entity_b")

print(f"Found {len(related_exps)} related experiences")
for exp_id in related_exps:
    print(f"  - {exp_id[:8]}...")
print()

# TEST 5: Reconstruct Context
print("TEST 5: Reconstruct Full Context for B")
print("-" * 80)

context = hi.reconstruct_context("entity_b")

print(f"Entity ID: {context['entity_id']}")
print(f"Direct relationships: {context['direct_relationships']}")
print(f"Related experiences: {context['related_experiences']}")
print(f"Chain depth: {context['chain_depth']}")
print()

# VALIDATION
print("=" * 80)
print("VALIDATION")
print("=" * 80)
print()

# Check chain integrity
if len(chain) == 3:
    print("[PASS] Chain traversal found all 3 relationships")
else:
    print(f"[FAIL] Expected 3 relationships in chain, got {len(chain)}")

# Check path finding
if path and len(path) == 3:
    print("[PASS] Path from A to D found (3 steps)")
else:
    print(f"[FAIL] Expected path of 3 steps, got {len(path) if path else 'None'}")

# Check inference
if inference['connected'] and inference['chain_length'] == 3:
    print("[PASS] Inference correctly identifies 3-step connection")
else:
    print(f"[FAIL] Inference failed: connected={inference['connected']}, length={inference['chain_length']}")

# Check no direct relationship created
import json
direct_a_to_d = False
for rel_file in (memory_root / "relationships").glob("*.json"):
    with open(rel_file, 'r') as f:
        rel = json.load(f)
        if rel.get("subject_id") == "entity_a" and rel.get("object_id") == "entity_d":
            direct_a_to_d = True
            break

if not direct_a_to_d:
    print("[PASS] No direct A->D relationship created (inference only)")
else:
    print("[FAIL] System incorrectly created direct A->D relationship")

# Check caution flag
if "caution" in inference and "Derived" in inference["caution"]:
    print("[PASS] Inference marked with caution flag")
else:
    print("[FAIL] Missing caution flag on derived inference")

print()
print("=" * 80)
print("HISTORICAL INTEGRATION: COMPLETE")
print("=" * 80)
