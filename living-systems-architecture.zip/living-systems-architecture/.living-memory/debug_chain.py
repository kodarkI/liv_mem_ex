#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

from pathlib import Path
import json

memory_root = Path(__file__).parent
relationships_dir = memory_root / "relationships"

print("=== DEBUG: Relationship Files ===")
print()

rel_files = list(relationships_dir.glob("*.json"))
print(f"Total relationship files: {len(rel_files)}")
print()

# Show last 3 relationships
for rel_file in sorted(rel_files, key=lambda f: f.stat().st_mtime, reverse=True)[:3]:
    with open(rel_file, 'r') as f:
        rel = json.load(f)
    
    print(f"File: {rel_file.name}")
    print(f"  Subject: {rel.get('subject', 'N/A')}")
    print(f"  Predicate: {rel.get('predicate', 'N/A')}")
    print(f"  Object: {rel.get('object', 'N/A')}")
    print(f"  Status: {rel.get('status', 'N/A')}")
    print()

# Test traversal manually
print("=== TEST: Manual Chain Traversal ===")
print()

start_id = "entity_a"
print(f"Looking for relationships starting from: {start_id}")
print()

for rel_file in rel_files:
    with open(rel_file, 'r') as f:
        rel = json.load(f)
    
    if rel.get("subject") == start_id:
        print(f"FOUND: {rel['subject']} --[{rel['predicate']}]--> {rel['object']}")
        print(f"  Status: {rel.get('status')}")
        print()
