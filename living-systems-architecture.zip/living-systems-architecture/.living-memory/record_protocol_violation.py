#!/usr/bin/env python3
"""
Record the protocol violation: AI read markdown docs instead of Experience records
This becomes Living Memory to inform Skill evolution
"""
import json
from pathlib import Path
from datetime import datetime
from memory_control import MemoryControl
from memory_governance import MemoryGovernance

memory_root = Path(__file__).parent
mc = MemoryControl(memory_root)
mg = MemoryGovernance(memory_root)

print("Recording protocol violation as DURABLE experience...\n")

# Experience 1: User question "What did we talk about last time?"
exp1 = mc.receive_experience(
    source="user",
    content={
        "type": "message",
        "text": "What did we talk about last time?"
    }
)
print(f"User question recorded: {exp1[:8]}")

# Experience 2: AI protocol violation
exp2 = mc.receive_experience(
    source="agent",
    content={
        "type": "protocol_violation",
        "text": "AI loaded markdown documentation files (CONVERSATION_RECORD.md, STATUS_SUMMARY.md, EXPERIMENT_4_COMPLETE.md) as source of truth instead of loading Experience records",
        "violation_type": "bypassed_memory_control",
        "what_should_have_happened": "Load recent 20 DURABLE experiences from .living-memory/experiences/ using continuity_loader.py",
        "what_actually_happened": "Read markdown summaries and responded from ASSERTIONS instead of EFFECTIVE truth",
        "consequence": "AI claimed experiments were 'READY FOR TEST' but missed that tests had already been RUN and PASSED",
        "evidence": [
            "conversational_test_result.txt shows PASS",
            "relationship_test_result.txt shows PASS",
            "state_test_result.txt shows PASS",
            "AI did not see these results because it didn't load Experience records"
        ]
    }
)

mc.update_retention(exp2, {
    "level": "durable",
    "reason": "Critical architectural violation revealing gap in Skill protocol. Must inform Skill evolution.",
    "decided_at": datetime.utcnow().isoformat() + 'Z',
    "decided_by": "memory_governance",
    "next_review_at": None
})
print(f"Protocol violation recorded as DURABLE: {exp2[:8]}")

# Experience 3: User insight
exp3 = mc.receive_experience(
    source="user",
    content={
        "type": "insight",
        "text": "why did you not remember this recent activity? it seems like your way of dealing conversations and works doesn't follow the concept and rule of living memory?",
        "identifies_gap": "AI behavior doesn't follow its own architecture",
        "core_issue": "Treating documentation as truth instead of Experience records",
        "architectural_principle_violated": "Source precedence not explicit in Skill"
    }
)

mc.update_retention(exp3, {
    "level": "durable",
    "reason": "User identified fundamental gap: source precedence not explicit in architecture/skill documentation",
    "decided_at": datetime.utcnow().isoformat() + 'Z',
    "decided_by": "memory_governance",
    "next_review_at": None
})
print(f"User insight recorded as DURABLE: {exp3[:8]}")

# Experience 4: Skill revision
exp4 = mc.receive_experience(
    source="agent",
    content={
        "type": "skill_revision",
        "text": "Added 'Source Precedence (Truth Hierarchy)' section to SKILL.md",
        "file_modified": ".augment/skills/liv-mem/SKILL.md",
        "addition": "Explicit table showing Experience records > Entity/State/Relationship > Documentation",
        "addresses_gap": "Makes source precedence explicit, not implicit",
        "critical_rule_added": "NEVER treat markdown documentation as current truth"
    }
)

mc.update_retention(exp4, {
    "level": "durable",
    "reason": "Skill evolution: addresses identified gap. Evidence for closed learning loop.",
    "decided_at": datetime.utcnow().isoformat() + 'Z',
    "decided_by": "memory_governance",
    "next_review_at": None
})
print(f"Skill revision recorded as DURABLE: {exp4[:8]}")

# Create relationship: User insight REVEALED gap in Skill
rel1 = mg.propose_relationship(
    subject_id=exp3,
    predicate="REVEALED_GAP_IN",
    object_id="living-systems-architecture-skill",
    origin_experience_id=exp3
)
print(f"Relationship created: User insight REVEALED_GAP_IN Skill")

# Create relationship: Skill revision ADDRESSES protocol violation
rel2 = mg.propose_relationship(
    subject_id=exp4,
    predicate="ADDRESSES",
    object_id=exp2,
    origin_experience_id=exp4
)
print(f"Relationship created: Skill revision ADDRESSES protocol violation")

# Create relationship: AI violation RESULTS_FROM missing precedence rule
rel3 = mg.propose_relationship(
    subject_id=exp2,
    predicate="RESULTS_FROM",
    object_id=exp3,
    origin_experience_id=exp3
)
print(f"Relationship created: Violation RESULTS_FROM missing rule")

print("\n" + "="*60)
print("RECORDED: Protocol violation → User insight → Skill evolution")
print("="*60)
print("\nThis is the closed learning loop in action:")
print("  Experience → Gap Detection → Skill Refinement → Living Memory")
