#!/usr/bin/env python3
"""
Historical Integration Module

Provides chain traversal and pattern discovery across experiences and relationships
Per reference/11: Event relationship semantics and chains
"""
import json
from pathlib import Path
from typing import List, Dict, Optional, Set


class HistoricalIntegration:
    """
    Connect experiences, discover relationships, traverse chains
    WITHOUT rewriting history
    """
    
    def __init__(self, memory_root: Path):
        self.memory_root = Path(memory_root)
        self.relationships_dir = self.memory_root / "relationships"
        self.experiences_dir = self.memory_root / "experiences"
    
    def traverse_chain(self, start_id: str, max_depth: int = 10) -> List[Dict]:
        """
        Traverse relationship chain from start entity/experience
        Returns: List of relationships in chain with predicates and statuses
        """
        visited = set()
        chain = []
        
        def _traverse(current_id: str, depth: int):
            if depth >= max_depth or current_id in visited:
                return
            
            visited.add(current_id)
            
            # Find relationships where current_id is subject
            for rel_file in self.relationships_dir.glob("*.json"):
                with open(rel_file, 'r') as f:
                    rel = json.load(f)

                    if rel.get("subject") == current_id:
                        chain.append({
                            "id": rel["id"],
                            "subject_id": rel["subject"],
                            "predicate": rel["predicate"],
                            "object_id": rel["object"],
                            "status": rel.get("status", "unknown"),
                            "depth": depth
                        })
                        # Recurse to object
                        _traverse(rel["object"], depth + 1)
        
        _traverse(start_id, 0)
        return chain
    
    def find_path(self, from_id: str, to_id: str, max_depth: int = 10) -> Optional[List[Dict]]:
        """
        Find path from from_id to to_id through relationships
        Returns: List of relationships forming path, or None if no path
        """
        visited = set()
        
        def _search(current_id: str, path: List[Dict], depth: int) -> Optional[List[Dict]]:
            if current_id == to_id:
                return path
            
            if depth >= max_depth or current_id in visited:
                return None
            
            visited.add(current_id)
            
            for rel_file in self.relationships_dir.glob("*.json"):
                with open(rel_file, 'r') as f:
                    rel = json.load(f)

                    if rel.get("subject") == current_id:
                        new_path = path + [rel]
                        result = _search(rel["object"], new_path, depth + 1)
                        if result is not None:
                            return result
            
            return None
        
        return _search(from_id, [], 0)
    
    def infer_relationship(self, from_id: str, to_id: str) -> Dict:
        """
        Answer: "What does to_id imply about from_id?"
        Returns inference WITHOUT creating direct relationship
        """
        path = self.find_path(from_id, to_id)
        
        if path is None:
            return {
                "connected": False,
                "inference": "No relationship path found",
                "predicates": [],
                "chain_length": 0,
                "weakest_link": "none"
            }
        
        predicates = [rel["predicate"] for rel in path]
        statuses = [rel.get("status", "unknown") for rel in path]
        
        # Analyze chain quality
        weakest_status = self._weakest_status(statuses)
        
        return {
            "connected": True,
            "inference": f"{from_id} connects to {to_id} via {len(path)}-step chain",
            "predicates": predicates,
            "chain_length": len(path),
            "weakest_link": weakest_status,
            "path": path,
            "caution": "Derived inference - not a direct established fact"
        }
    
    def _weakest_status(self, statuses: List[str]) -> str:
        """Find weakest link in chain"""
        hierarchy = ["possible", "candidate", "supported", "established", "active"]
        weakest_idx = 0
        for status in statuses:
            if status in hierarchy:
                idx = hierarchy.index(status)
                if idx < hierarchy.index(hierarchy[weakest_idx]) or weakest_idx == 0:
                    weakest_idx = idx
        return hierarchy[weakest_idx] if weakest_idx < len(hierarchy) else "unknown"
    
    def find_related_experiences(self, entity_id: str, predicate_filter: Optional[str] = None) -> List[str]:
        """
        Find experiences related to entity through relationships
        """
        experience_ids = set()
        
        # Find relationships involving entity
        for rel_file in self.relationships_dir.glob("*.json"):
            with open(rel_file, 'r') as f:
                rel = json.load(f)
                
                if predicate_filter and rel.get("predicate") != predicate_filter:
                    continue

                if rel.get("subject") == entity_id or rel.get("object") == entity_id:
                    # Get source experience
                    if "origin" in rel:
                        experience_ids.add(rel["origin"])
                    # Get evidence experiences
                    for evidence_id in rel.get("evidence", []):
                        experience_ids.add(evidence_id)
        
        return list(experience_ids)
    
    def reconstruct_context(self, entity_id: str) -> Dict:
        """
        Reconstruct full context for entity: relationships + experiences + chain insights
        """
        # Get direct relationships
        relationships = []
        for rel_file in self.relationships_dir.glob("*.json"):
            with open(rel_file, 'r') as f:
                rel = json.load(f)
                if rel.get("subject") == entity_id or rel.get("object") == entity_id:
                    relationships.append(rel)
        
        # Get related experiences
        experience_ids = self.find_related_experiences(entity_id)
        
        # Get chains
        chains = self.traverse_chain(entity_id, max_depth=5)
        
        return {
            "entity_id": entity_id,
            "direct_relationships": len(relationships),
            "related_experiences": len(experience_ids),
            "chain_depth": len(chains),
            "relationships": relationships,
            "experience_ids": experience_ids,
            "chains": chains
        }
