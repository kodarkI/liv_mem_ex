# Living Memory System

**File-based implementation of living-systems-architecture for automatic conversation continuity**

## What This Is

This is a **Living Memory** system that preserves continuity through change. Instead of starting fresh each conversation, the AI agent maintains:

- **Identity** (Entity): Who/what persists over time
- **Current State**: What is true NOW
- **Relationships**: What connects to what
- **History**: What happened (immutable)
- **Direction**: What we're continuing toward

## Architecture

```
.living-memory/
├── schemas/              # JSON schemas for all record types
├── entities/             # Persistent identities
├── states/               # Current state snapshots  
├── relationships/        # Governed connections
├── experiences/          # Immutable history
├── directions/           # Ongoing intents
├── skills/              # Versioned capabilities (future)
├── memory_control.py    # Routes experiences through governance
├── memory_governance.py # Controls what becomes truth
├── bootstrap.py         # Initial setup
└── continuity_loader.py # Reconstructs memory at conversation start
```

## Core Principles

1. **Living memory is continuity through change**
2. **History is immutable** - we never rewrite what happened
3. **State is current** - when it changes, old state becomes historical
4. **Relationships are governed** - not everything becomes truth automatically
5. **Skills evolve through evidence** - capabilities emerge from patterns

## Lifecycle

### Memory Lifecycle (per reference/08)
```
CREATE → VALIDATE → USE → UPDATE → SUPERSEDE → ARCHIVE → PRUNE
```

### Governance Progression (per reference/02)
```
POSSIBLE → CANDIDATE → SUPPORTED → ESTABLISHED → ACTIVE / DORMANT / HISTORICAL
```

### Retention Levels (per reference/08)
- **EPHEMERAL**: No continuing value, prune quickly
- **RETAINED**: May matter later, keep accessible
- **DURABLE**: Establishes identity/state/relationship/direction, preserve indefinitely
- **ARCHIVED**: Retained but outside ordinary retrieval

## Usage

### First Time: Bootstrap
```bash
python .living-memory/bootstrap.py
```

This creates:
- Entities for User, Agent, Conversation, Project
- Relationships (who works on what)
- Direction (what we're continuing toward)
- First experience

### Every Conversation: Load Continuity
```python
from continuity_loader import ContinuityLoader
from pathlib import Path

loader = ContinuityLoader(Path(".living-memory"))
living_memory = loader.load_living_memory()

# Now you have:
# - living_memory["entities"]
# - living_memory["relationships"]
# - living_memory["directions"]
# - living_memory["current_state"]
```

### Add New Experience
```python
from memory_control import MemoryControl
from memory_governance import MemoryGovernance
from pathlib import Path

mc = MemoryControl(Path(".living-memory"))
mg = MemoryGovernance(Path(".living-memory"))

# Receive experience
exp_id = mc.receive_experience(
    source="user",
    content={"type": "message", "text": "Build a new feature"},
    source_entity_id="<user_entity_id>"
)

# Route it
routing = mc.route_experience(exp_id)

# Governance decides retention
retention = mg.decide_retention(mc.get_experience(exp_id))
mc.update_retention(exp_id, retention)
```

## References

All operating contracts defined in:
- `.augment/skills/liv-mem/references/01-foundations.md` - Core principles
- `.augment/skills/liv-mem/references/02-core-layers.md` - Entity/State/Relationship/History
- `.augment/skills/liv-mem/references/04-operating-contracts.md` - Required record structure
- `.augment/skills/liv-mem/references/08-memory-lifecycle-truth-and-promotion.md` - Retention rules
- ... (17 total reference contracts)

## Status

✅ **IMPLEMENTED**:
- Entity/State/Relationship/Experience/Direction schemas
- Memory Control (routing)
- Memory Governance (retention, progression)
- Bootstrap process
- Continuity loader

🚧 **IN PROGRESS**:
- Skill emergence and evolution
- Historical Integration patterns
- Attention policy
- Self-auditing mechanisms

📋 **PLANNED** (Experiment 1-5):
- Multi-conversation continuity testing
- Adversarial memory challenges
- Skill lifecycle demonstration
- Relationship evolution scenarios
