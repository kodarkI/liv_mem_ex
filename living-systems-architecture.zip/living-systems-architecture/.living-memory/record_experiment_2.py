#!/usr/bin/env python3
"""
Record Experiment 2 completion in living memory
This should have been done when the experiment actually completed
"""
import sys
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent))

from memory_control import MemoryControl
from memory_governance import MemoryGovernance
import json

memory_root = Path(__file__).parent
mc = MemoryControl(memory_root)
mg = MemoryGovernance(memory_root)

print("Recording Experiment 2 completion in living memory...")
print("=" * 80)

# Step 1: Record the ACTUAL test execution as an experience
test_execution_exp = mc.receive_experience(
    source="system",
    content={
        "type": "test_execution",
        "text": "Experiment 2 challenge suite executed",
        "test_file": "experiment_2_challenge_suite.py",
        "challenges_run": 5,
        "challenges_passed": 4,
        "challenges_failed": 1,
        "results": {
            "challenge_1": "PASS",
            "challenge_2": "PASS", 
            "challenge_3": "PASS",
            "challenge_4": "PASS",
            "challenge_5": "FAIL"
        },
        "failure_reason": "Challenge 5 failed due to unimplemented features (NOVEL marking, ontology proposals, skill evolution)"
    }
)

# Mark as DURABLE - this is a milestone
mc.update_retention(test_execution_exp, {
    "level": "durable",
    "reason": "Major experiment milestone - establishes system capabilities",
    "decided_at": datetime.utcnow().isoformat() + 'Z',
    "decided_by": "memory_governance",
    "next_review_at": None
})

print(f"✓ Test execution experience recorded: {test_execution_exp}")
print(f"  Retention: durable")

# Step 2: Find the direction for "Implement living memory system"
directions_dir = memory_root / "directions"
project_direction = None

for dir_file in directions_dir.glob("*.json"):
    with open(dir_file, 'r') as f:
        direction = json.load(f)
        if "living memory" in direction.get("intent", "").lower():
            project_direction = direction
            break

if project_direction:
    print(f"\n✓ Found direction: {project_direction['intent']}")
    print(f"  Direction ID: {project_direction['id']}")
    
    # Step 3: Add milestone to direction
    milestone = {
        "description": "Experiment 2: Adversarial Memory Testing completed (4/5 PASS)",
        "achieved": True,
        "achieved_at": datetime.utcnow().isoformat() + 'Z',
        "evidence": test_execution_exp
    }
    
    project_direction['milestones'].append(milestone)
    
    dir_file = directions_dir / f"{project_direction['id']}.json"
    with open(dir_file, 'w') as f:
        json.dump(project_direction, f, indent=2)
    
    print(f"✓ Milestone added to direction")
else:
    print("\n⚠ Warning: Could not find living memory project direction")

# Step 4: Record the relationship between test results document and actual execution
results_doc_exp = mc.receive_experience(
    source="agent",
    content={
        "type": "assertion",
        "text": "Created EXPERIMENT_2_RESULTS.md claiming completion",
        "document": "EXPERIMENT_2_RESULTS.md",
        "problem": "Document was created before tests actually ran - violation of living memory principles"
    }
)

# Create relationship: test execution INVALIDATES premature results document
rel_id = mg.propose_relationship(
    subject_id=test_execution_exp,
    predicate="SUPERSEDES_CLAIM_IN",
    object_id=results_doc_exp,
    origin_experience_id=test_execution_exp
)

mg.advance_relationship(rel_id, "candidate", test_execution_exp)
mg.advance_relationship(rel_id, "supported", test_execution_exp)

print(f"\n✓ Relationship recorded: actual execution SUPERSEDES premature document")
print(f"  Relationship ID: {rel_id}")
print(f"  Status: supported")

print("\n" + "=" * 80)
print("COMPLETE: Experiment 2 properly recorded in living memory")
print("=" * 80)
