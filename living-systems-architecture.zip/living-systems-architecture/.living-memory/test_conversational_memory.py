#!/usr/bin/env python3
"""
Experiment 2.5: Conversational Memory

Tests whether the system can remember HOW conversations flow,
not just WHAT work was done.

This is what the user wants: "you get what i talked to you yesterday"
"""
import sys
import io
from pathlib import Path
from datetime import datetime

# Force UTF-8 encoding
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

from agent_interface import AgentMemoryInterface

print("=" * 80)
print("EXPERIMENT 2.5: CONVERSATIONAL MEMORY")
print("=" * 80)
print("\nPurpose: Test if system remembers conversational flow, not just work items")
print()

# Initialize agent
memory_root = Path(__file__).parent
agent = AgentMemoryInterface(memory_root)
context = agent.initialize_continuity()

print(f"Loaded Living Memory with {len(context['entities'])} entities")
print()

# ========================================================================
# SCENARIO: Simulating the conversation we just had
# ========================================================================

print("SCENARIO: User realizes what's missing")
print("-" * 80)

# Turn 1: User asks about experiments
print("\nTurn 1: User asks clarifying question")
exp1 = agent.receive_user_message(
    "why just to 4 not 2? any suggestion on what to do with this work?"
)
print(f"  Recorded: {exp1[:8]}...")

# Turn 2: User expresses the REAL need
print("\nTurn 2: User expresses what they actually want")
exp2 = agent.receive_user_message(
    "actually, i know that the chat can still follow the work but it doesn't "
    "remember how our last conversations was going? i don't just want work to "
    "be done. i also want something like you get what i talked to you yesterday."
)
print(f"  Recorded: {exp2[:8]}...")

# Identify this as a KEY INSIGHT about requirements
print("\n  -> This is a CRITICAL INSIGHT experience")
print("  -> Should be marked DURABLE")

# Update retention to DURABLE
agent.mc.update_retention(exp2, {
    "level": "durable",
    "reason": "Critical user requirement: wants conversational memory, not just work tracking",
    "decided_at": datetime.utcnow().isoformat() + 'Z',
    "decided_by": "governance",
    "next_review_at": None
})
print("  -> Retention: DURABLE")

# Turn 3: User preference for simplicity
print("\nTurn 3: User expresses preference")
exp3 = agent.receive_user_message(
    "maybe, just be adding skill is more easy"
)
print(f"  Recorded: {exp3[:8]}...")

# Mark as preference
agent.mc.update_retention(exp3, {
    "level": "durable",
    "reason": "User communication preference: prefers simple solutions over complex ones",
    "decided_at": datetime.utcnow().isoformat() + 'Z',
    "decided_by": "governance",
    "next_review_at": None
})
print("  -> Retention: DURABLE (user preference)")

print()
print("=" * 80)

# ========================================================================
# TEST: Can we reconstruct the conversation?
# ========================================================================

print("TEST: Conversation Reconstruction")
print("-" * 80)

# Reload memory (simulating new conversation)
agent2 = AgentMemoryInterface(memory_root)
context2 = agent2.initialize_continuity()

recent_exps = context2['recent_experiences']
durable_messages = [
    exp for exp in recent_exps 
    if exp.get('content', {}).get('type') == 'message'
]

print(f"\nFound {len(durable_messages)} durable user messages in recent memory")
print()

for exp in durable_messages[-3:]:  # Last 3
    text = exp['content']['text']
    retention = exp.get('retention_decision', {})
    reason = retention.get('reason', 'no reason')
    
    print(f"Message: \"{text[:60]}...\"")
    print(f"  Why durable: {reason}")
    print()

# ========================================================================
# VALIDATION
# ========================================================================

print("=" * 80)
print("VALIDATION: What would happen in next conversation?")
print("-" * 80)
print()

print("Scenario: New conversation starts")
print("User: 'What did I tell you yesterday?'")
print()
print("Agent should be able to say:")
print("  1. 'You said you want me to remember CONVERSATIONS, not just work'")
print("  2. 'You prefer simple solutions (like just adding skill)'")
print("  3. 'You pointed out the system tracks work but not dialogue flow'")
print()

# Check if we can answer these
insights_found = []
preferences_found = []

for exp in recent_exps:
    reason = exp.get('retention_decision', {}).get('reason', '')
    if 'conversational memory' in reason.lower():
        insights_found.append(exp['content']['text'])
    if 'preference' in reason.lower():
        preferences_found.append(exp['content']['text'])

print(f"[OK] Found {len(insights_found)} conversational insights in memory")
print(f"[OK] Found {len(preferences_found)} user preferences in memory")
print()

if insights_found and preferences_found:
    print("[PASS] System CAN reconstruct conversational context")
    print()
    print("User requirement 'you get what i talked to you yesterday' = ACHIEVABLE")
else:
    print("[FAIL] System CANNOT reconstruct conversational context")
    print("Missing: conversation recording mechanism")

print()
print("=" * 80)
