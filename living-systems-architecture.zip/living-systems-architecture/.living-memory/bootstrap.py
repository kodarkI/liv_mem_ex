#!/usr/bin/env python3
"""
Bootstrap Living Memory System
Creates initial entities, establishes first experiences, and sets up continuity
"""
import json
import sys
from pathlib import Path
from datetime import datetime

# Add current directory to path for imports
sys.path.insert(0, str(Path(__file__).parent))

from memory_control import MemoryControl
from memory_governance import MemoryGovernance

def bootstrap_living_memory():
    """Initialize living memory with current conversation context"""
    
    memory_root = Path(__file__).parent
    mc = MemoryControl(memory_root)
    mg = MemoryGovernance(memory_root)
    
    print("🧠 Bootstrapping Living Memory System...")
    print(f"📁 Root: {memory_root.absolute()}\n")
    
    # === EXPERIENCE 1: User declares automatic continuity ===
    exp1_id = mc.receive_experience(
        source="user",
        content={
            "type": "message",
            "text": "from now on, conversation must be automatic continuity. not fresh start."
        }
    )
    print(f"✅ Experience 1 (User intent): {exp1_id}")
    
    routing1 = mc.route_experience(exp1_id)
    print(f"   Routed to: {routing1}")
    
    retention1 = mg.decide_retention(mc.get_experience(exp1_id))
    mc.update_retention(exp1_id, retention1)
    print(f"   Retention: {retention1['level']} - {retention1['reason']}\n")
    
    # === ENTITY 1: User ===
    user_entity_id = mg.propose_entity(
        entity_type="person",
        identity_assertion="Human user requesting living memory implementation",
        source_experience_id=exp1_id
    )
    print(f"👤 User Entity: {user_entity_id}\n")
    
    # === ENTITY 2: Agent (Me) ===
    agent_entity_id = mg.propose_entity(
        entity_type="agent",
        identity_assertion="Augment Agent implementing liv-mem architecture",
        source_experience_id=exp1_id
    )
    print(f"🤖 Agent Entity: {agent_entity_id}\n")
    
    # === ENTITY 3: This Conversation ===
    conversation_entity_id = mg.propose_entity(
        entity_type="conversation",
        identity_assertion="Bootstrap conversation establishing living memory continuity",
        source_experience_id=exp1_id
    )
    print(f"💬 Conversation Entity: {conversation_entity_id}\n")
    
    # === ENTITY 4: This Project ===
    project_entity_id = mg.propose_entity(
        entity_type="project",
        identity_assertion="living-systems-architecture: Continuity through change",
        source_experience_id=exp1_id
    )
    print(f"📦 Project Entity: {project_entity_id}\n")
    
    # === RELATIONSHIP: User works_on Project ===
    rel1_id = mg.propose_relationship(
        subject_id=user_entity_id,
        predicate="works_on",
        object_id=project_entity_id,
        origin_experience_id=exp1_id
    )
    # Advance through governance
    mg.advance_relationship(rel1_id, "candidate", exp1_id)
    mg.advance_relationship(rel1_id, "supported", exp1_id)
    mg.advance_relationship(rel1_id, "established", exp1_id)
    mg.advance_relationship(rel1_id, "active", exp1_id)
    print(f"🔗 Relationship (User → works_on → Project): {rel1_id} [ACTIVE]\n")
    
    # === RELATIONSHIP: Agent works_on Project ===
    rel2_id = mg.propose_relationship(
        subject_id=agent_entity_id,
        predicate="works_on",
        object_id=project_entity_id,
        origin_experience_id=exp1_id
    )
    mg.advance_relationship(rel2_id, "candidate", exp1_id)
    mg.advance_relationship(rel2_id, "supported", exp1_id)
    mg.advance_relationship(rel2_id, "established", exp1_id)
    mg.advance_relationship(rel2_id, "active", exp1_id)
    print(f"🔗 Relationship (Agent → works_on → Project): {rel2_id} [ACTIVE]\n")
    
    # === DIRECTION: Implement living memory for automatic continuity ===
    direction_id = mg.establish_direction(
        entity_id=conversation_entity_id,
        intent="Implement file-based living memory system for automatic conversation continuity",
        scope="ongoing",
        source_experience_id=exp1_id
    )
    print(f"🎯 Direction: {direction_id}")
    print(f"   Intent: Implement living memory for automatic continuity")
    print(f"   Scope: ongoing\n")
    
    # === Save bootstrap context ===
    bootstrap_context = {
        "bootstrapped_at": datetime.utcnow().isoformat() + 'Z',
        "entities": {
            "user": user_entity_id,
            "agent": agent_entity_id,
            "conversation": conversation_entity_id,
            "project": project_entity_id
        },
        "relationships": {
            "user_works_on_project": rel1_id,
            "agent_works_on_project": rel2_id
        },
        "direction": direction_id,
        "first_experience": exp1_id
    }
    
    context_file = memory_root / "bootstrap_context.json"
    with open(context_file, 'w') as f:
        json.dump(bootstrap_context, f, indent=2)
    
    print(f"💾 Bootstrap context saved to: {context_file}\n")
    print("=" * 60)
    print("✨ Living Memory System is now ACTIVE")
    print("=" * 60)
    print("\nNext: Load this context in future conversations to maintain continuity.")
    
    return bootstrap_context

if __name__ == "__main__":
    bootstrap_living_memory()
