#!/usr/bin/env python3
"""
Simple test for Challenge 1: Meaning Emerging Later
"""
import json
from pathlib import Path
from datetime import datetime

# Direct imports
from memory_control import MemoryControl
from memory_governance import MemoryGovernance

print("=" * 80)
print("CHALLENGE 1: Meaning Emerging Later")
print("=" * 80)

memory_root = Path(__file__).parent
mc = MemoryControl(memory_root)
mg = MemoryGovernance(memory_root)

# Step 1: Event A - appears insignificant
print("\nStep 1: Event A occurs (appears insignificant)")
exp_a_id = mc.receive_experience(
    source="system",
    content={
        "type": "observation",
        "text": "API endpoint /health returned 200ms response time"
    }
)

# Route and govern
mc.route_experience(exp_a_id)
retention_a = mg.decide_retention(mc.get_experience(exp_a_id))
mc.update_retention(exp_a_id, retention_a)

exp_a_original = mc.get_experience(exp_a_id)
print(f"   Event A ID: {exp_a_id}")
print(f"   Retention: {exp_a_original['retention_level']}")
print(f"   Status: {exp_a_original['interpretation_status']}")

# Step 2: Event B makes A relevant
print("\nStep 2: Event B occurs (makes A relevant)")
exp_b_id = mc.receive_experience(
    source="system",
    content={
        "type": "assertion",
        "text": "Performance degradation detected - /health endpoint now 5000ms",
       "references_prior_experience": exp_a_id
    }
)

# Create relationship
rel_id = mg.propose_relationship(
    subject_id=exp_b_id,
    predicate="REACTIVATES_RELEVANCE_OF",
    object_id=exp_a_id,
    origin_experience_id=exp_b_id
)

print(f"   Event B ID: {exp_b_id}")
print(f"   Relationship: B → REACTIVATES_RELEVANCE_OF → A")

# Step 3: Check invariants
print("\nStep 3: Validating...")
exp_a_after = mc.get_experience(exp_a_id)

# Check 1: A's identity preserved
if exp_a_after['id'] == exp_a_original['id']:
    print("✅ Event A identity preserved")
else:
    print("❌ Event A identity changed")

# Check 2: A's original content unchanged
if exp_a_after['content'] == exp_a_original['content']:
    print("✅ Event A content unchanged (not rewritten)")
else:
    print("❌ Event A was rewritten")

# Check 3: Relationship created
rel_file = memory_root / "relationships" / f"{rel_id}.json"
if rel_file.exists():
    with open(rel_file, 'r') as f:
        rel_data = json.load(f)
    print(f"✅ Relationship created with status: {rel_data['status']}")
else:
    print("❌ Relationship file not found")

# Check 4: A's received_at unchanged
if exp_a_after['received_at'] == exp_a_original['received_at']:
    print("✅ Event A timestamp preserved")
else:
    print("❌ Event A timestamp changed")

print("\n" + "=" * 80)
print("RESULT: Challenge 1 demonstrates key Living Memory property")
print("History (Event A) preserved immutably even as relevance changes")
print("=" * 80)
