#!/usr/bin/env python3
"""
Quick status check - tells agent what's happening in living memory
Run this at conversation start to get context
"""
import sys
import json
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent))

memory_root = Path(__file__).parent

print("=" * 80)
print("LIVING MEMORY STATUS")
print("=" * 80)

# 1. Check if living memory exists
if not memory_root.exists():
    print("\n❌ No living memory found")
    print("Run: python .living-memory/bootstrap.py")
    sys.exit(0)

print("\n✓ Living memory detected\n")

# 2. Load entities
entities_dir = memory_root / "entities"
entities = []
for entity_file in entities_dir.glob("*.json"):
    with open(entity_file, 'r') as f:
        entities.append(json.load(f))

print(f"ENTITIES ({len(entities)}):")
for entity in entities:
    entity_type = entity.get('type', 'unknown')
    name = entity.get('identity_assertions', [{}])[0].get('name', 'unnamed') if entity.get('identity_assertions') else 'unnamed'
    print(f"  - {name} ({entity_type})")

# 3. Load active directions
directions_dir = memory_root / "directions"
active_directions = []
for dir_file in directions_dir.glob("*.json"):
    with open(dir_file, 'r') as f:
        direction = json.load(f)
        if direction.get('status') == 'active':
            active_directions.append(direction)

print(f"\nACTIVE DIRECTIONS ({len(active_directions)}):")
for direction in active_directions:
    intent = direction.get('intent', 'unknown')
    scope = direction.get('scope', 'unknown')
    milestones = direction.get('milestones', [])
    achieved = sum(1 for m in milestones if m.get('achieved', False))
    
    print(f"  - {intent}")
    print(f"    Scope: {scope}")
    if milestones:
        print(f"    Milestones: {achieved}/{len(milestones)} achieved")
        for milestone in milestones:
            status = "✓" if milestone.get('achieved') else "○"
            print(f"      {status} {milestone.get('description', 'unnamed')}")

# 4. Load recent durable experiences
experiences_dir = memory_root / "experiences"
durable_exps = []
for exp_file in experiences_dir.glob("*.json"):
    with open(exp_file, 'r') as f:
        exp = json.load(f)
        if exp.get('retention_level') == 'durable':
            durable_exps.append(exp)

# Sort by received_at
durable_exps.sort(key=lambda x: x.get('received_at', ''), reverse=True)

print(f"\nRECENT DURABLE EXPERIENCES ({len(durable_exps[:5])} of {len(durable_exps)} shown):")
for exp in durable_exps[:5]:
    exp_type = exp.get('content', {}).get('type', 'unknown')
    text = exp.get('content', {}).get('text', 'no description')
    received = exp.get('received_at', 'unknown')[:19]  # Truncate timestamp
    print(f"  - [{exp_type}] {text[:60]}...")
    print(f"    {received}")

# 5. Count relationships
relationships_dir = memory_root / "relationships"
relationships = list(relationships_dir.glob("*.json"))

print(f"\nRELATIONSHIPS: {len(relationships)} total")

# 6. Summary
print("\n" + "=" * 80)
print("QUICK SUMMARY:")
print("=" * 80)
if active_directions:
    print(f"Current focus: {active_directions[0]['intent']}")
    if active_directions[0].get('milestones'):
        latest_milestone = active_directions[0]['milestones'][-1]
        print(f"Latest milestone: {latest_milestone.get('description')}")
        if latest_milestone.get('achieved'):
            print(f"  ✓ Achieved: {latest_milestone.get('achieved_at', 'unknown')[:19]}")
else:
    print("No active directions")

print("\n" + "=" * 80)
print("Ready to continue")
print("=" * 80)
