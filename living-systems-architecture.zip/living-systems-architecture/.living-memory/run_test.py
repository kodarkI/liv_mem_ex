#!/usr/bin/env python3
"""Runner that captures output and writes to file"""
import subprocess
import sys
from pathlib import Path

# Run the test
result = subprocess.run(
    [sys.executable, "-B", "test_simple_load.py"],  # -B to not write bytecode
    cwd=Path(__file__).parent,
    capture_output=True,
    text=True,
    encoding='utf-8',
    errors='replace',
    env={**subprocess.os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}
)

# Write output
output_file = Path(__file__).parent / "test_result_captured.txt"
with open(output_file, 'w', encoding='utf-8') as f:
    f.write("=== STDOUT ===\n")
    f.write(result.stdout)
    f.write("\n=== STDERR ===\n")
    f.write(result.stderr)
    f.write(f"\n=== EXIT CODE: {result.returncode} ===\n")

print(f"Output written to {output_file}")
print(f"Exit code: {result.returncode}")
