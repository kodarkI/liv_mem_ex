#!/usr/bin/env python3
"""
Continuity Loader: Reconstructs Living Memory at conversation start
This is THE CRITICAL COMPONENT for automatic continuity
"""
import json
from pathlib import Path
from typing import Dict, List, Any
from datetime import datetime

class ContinuityLoader:
    """Loads Living Memory to maintain continuity across conversation boundaries"""
    
    def __init__(self, memory_root: Path):
        self.memory_root = Path(memory_root)
        
    def load_living_memory(self) -> Dict[str, Any]:
        """
        Reconstruct Living Memory from files
        Returns: living_memory_context
        """
        print("[*] Loading Living Memory for conversation continuity...")
        print(f"[*] Memory root: {self.memory_root.absolute()}\n")
        
        # Load bootstrap context
        bootstrap_file = self.memory_root / "bootstrap_context.json"
        if not bootstrap_file.exists():
            raise FileNotFoundError("No bootstrap context found. Run bootstrap.py first.")
        
        with open(bootstrap_file, 'r') as f:
            bootstrap = json.load(f)
        
        print(f"[OK] Bootstrap context loaded (created: {bootstrap['bootstrapped_at']})\n")
        
        # Load all entities
        entities = self._load_all_entities()
        print(f"[*] Loaded {len(entities)} entities:")
        for entity_type, count in self._count_by_type(entities, 'type').items():
            print(f"   - {entity_type}: {count}")
        print()
        
        # Load all active relationships
        relationships = self._load_active_relationships()
        print(f"[*] Loaded {len(relationships)} active relationships:")
        for pred, count in self._count_by_type(relationships, 'predicate').items():
            print(f"   - {pred}: {count}")
        print()
        
        # Load active directions
        directions = self._load_active_directions()
        print(f"[*] Loaded {len(directions)} active directions")
        for direction in directions:
            print(f"   - {direction['intent'][:60]}...")
        print()
        
        # Load recent durable experiences
        experiences = self._load_recent_durable_experiences(limit=20)
        print(f"[*] Loaded {len(experiences)} recent durable experiences\n")
        
        living_memory = {
            "loaded_at": datetime.utcnow().isoformat() + 'Z',
            "bootstrap": bootstrap,
            "entities": entities,
            "relationships": relationships,
            "directions": directions,
            "recent_experiences": experiences,
            "current_state": self._derive_current_state(entities, relationships, directions)
        }
        
        print("=" * 60)
        print("[*] Living Memory RESTORED - Continuity Active")
        print("=" * 60)
        
        return living_memory
    
    def _load_all_entities(self) -> List[Dict[str, Any]]:
        """Load all active entities"""
        entities_dir = self.memory_root / "entities"
        entities = []
        for entity_file in entities_dir.glob("*.json"):
            with open(entity_file, 'r') as f:
                entity = json.load(f)
                if entity['lifecycle_status'] == 'active':
                    entities.append(entity)
        return entities
    
    def _load_active_relationships(self) -> List[Dict[str, Any]]:
        """Load all active relationships"""
        rel_dir = self.memory_root / "relationships"
        relationships = []
        for rel_file in rel_dir.glob("*.json"):
            with open(rel_file, 'r') as f:
                rel = json.load(f)
                if rel['status'] == 'active':
                    relationships.append(rel)
        return relationships
    
    def _load_active_directions(self) -> List[Dict[str, Any]]:
        """Load all active directions"""
        dir_dir = self.memory_root / "directions"
        directions = []
        for dir_file in dir_dir.glob("*.json"):
            with open(dir_file, 'r') as f:
                direction = json.load(f)
                if direction['status'] == 'active':
                    directions.append(direction)
        return directions
    
    def _load_recent_durable_experiences(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Load recent experiences with durable retention"""
        exp_dir = self.memory_root / "experiences"
        experiences = []
        for exp_file in sorted(exp_dir.glob("*.json"), 
                              key=lambda p: p.stat().st_mtime, 
                              reverse=True)[:limit]:
            with open(exp_file, 'r') as f:
                exp = json.load(f)
                if exp.get('retention_level') == 'durable':
                    experiences.append(exp)
        return experiences[:limit]
    
    def _count_by_type(self, items: List[Dict], type_key: str) -> Dict[str, int]:
        """Count items by type field"""
        counts = {}
        for item in items:
            t = item.get(type_key, 'unknown')
            counts[t] = counts.get(t, 0) + 1
        return counts
    
    def _derive_current_state(self, entities, relationships, directions) -> Dict[str, Any]:
        """Derive current state from Living Memory"""
        entity_by_type = {}
        for entity in entities:
            entity_type = entity['type']
            if entity_type not in entity_by_type:
                entity_by_type[entity_type] = []
            entity_by_type[entity_type].append(entity['id'])
        
        return {
            "total_entities": len(entities),
            "entities_by_type": entity_by_type,
            "active_relationships": len(relationships),
            "active_directions": len(directions),
            "primary_direction": directions[0]['intent'] if directions else None
        }

if __name__ == "__main__":
    memory_root = Path(__file__).parent
    loader = ContinuityLoader(memory_root)
    living_memory = loader.load_living_memory()
    
    print("\n[*] Current State:")
    print(json.dumps(living_memory["current_state"], indent=2))
