#!/usr/bin/env python3
"""
Test the auto-activation protocol:
Simulates what happens when an AI agent starts a conversation and automatically loads Living Memory.

This tests the protocol defined in:
- .augment/living-memory-enabled (the activation flag)
- AGENT_PROTOCOL.md (what the agent must do)
- STARTUP_INSTRUCTIONS.md (how to behave)
"""
import json
import sys
import io
from pathlib import Path
from agent_interface import AgentMemoryInterface

# Force UTF-8 encoding for stdout
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
if sys.stderr.encoding != 'utf-8':
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

def test_auto_activation():
    """
    Simulate a fresh conversation start where the agent:
    1. Detects the .augment/living-memory-enabled flag
    2. Loads Living Memory automatically
    3. Reconstructs context
    4. Continues from where we left off
    """
    print("=" * 80)
    print("AUTO-ACTIVATION PROTOCOL TEST")
    print("=" * 80)
    print()
    
    # STEP 1: Check for activation flag
    print("STEP 1: Detect Living Memory Activation Flag")
    print("-" * 80)
    
    workspace_root = Path(__file__).parent.parent  # Go up to workspace root
    activation_flag = workspace_root / ".augment" / "living-memory-enabled"
    
    if activation_flag.exists():
        print(f"[OK] Found: {activation_flag}")
        print("   Living Memory is ENABLED for this workspace")
        with open(activation_flag, 'r') as f:
            flag_content = f.read()
        print(f"\n   Flag content preview:")
        print("   " + "\n   ".join(flag_content.split('\n')[:5]))
    else:
        print(f"[FAIL] NOT FOUND: {activation_flag}")
        print("   Living Memory would operate in fresh-start mode")
        return False
    
    print()
    
    # STEP 2: Auto-load Living Memory
    print("STEP 2: Auto-Load Living Memory")
    print("-" * 80)
    
    memory_root = Path(__file__).parent
    agent = AgentMemoryInterface(memory_root)
    
    # This is what the agent does at conversation start
    context = agent.initialize_continuity()
    
    print("[OK] Living Memory loaded successfully")
    print()

    # STEP 3: Verify context reconstruction
    print("STEP 3: Verify Context Reconstruction")
    print("-" * 80)

    print(f"Loaded at: {context['loaded_at']}")
    print()

    # Check entities
    entities = context['entities']
    print(f"[*] Entities: {len(entities)}")
    for entity in entities[:3]:  # Show first 3
        entity_type = entity.get('type', 'unknown')
        assertions = entity.get('identity_assertions', [])
        first_assertion = assertions[0] if assertions else {}
        name = first_assertion.get('name', 'unnamed')
        print(f"   - {name} ({entity_type})")
    if len(entities) > 3:
        print(f"   ... and {len(entities) - 3} more")
    print()
    
    # Check relationships
    relationships = context['relationships']
    print(f"[*] Active Relationships: {len(relationships)}")
    for rel in relationships[:3]:  # Show first 3
        predicate = rel.get('predicate', 'UNKNOWN')
        status = rel.get('status', 'unknown')
        print(f"   - {predicate} ({status})")
    if len(relationships) > 3:
        print(f"   ... and {len(relationships) - 3} more")
    print()

    # Check directions
    directions = context['directions']
    print(f"[*] Active Directions: {len(directions)}")
    for direction in directions[:3]:  # Show first 3
        intent = direction.get('intent', 'unknown')[:70]
        status = direction.get('status', 'unknown')
        print(f"   - [{status}] {intent}...")
    if len(directions) > 3:
        print(f"   ... and {len(directions) - 3} more")
    print()

    # Check recent experiences
    recent_exps = context['recent_experiences']
    print(f"[*] Recent Durable Experiences: {len(recent_exps)}")
    for exp in recent_exps[:3]:  # Show first 3
        exp_type = exp.get('content', {}).get('type', 'unknown')
        text = exp.get('content', {}).get('text', 'no description')[:50]
        print(f"   - [{exp_type}] {text}...")
    if len(recent_exps) > 3:
        print(f"   ... and {len(recent_exps) - 3} more")
    print()

    # Check current state
    current_state = context['current_state']
    print(f"[*] Current State:")
    print(f"   Total Entities: {current_state['total_entities']}")
    print(f"   Active Relationships: {current_state['active_relationships']}")
    print(f"   Active Directions: {current_state['active_directions']}")
    if current_state.get('primary_direction'):
        print(f"   Primary Direction: {current_state['primary_direction'][:60]}...")
    print()
    
    # STEP 4: Verify agent knows its identity
    print("STEP 4: Verify Agent Identity")
    print("-" * 80)
    
    if agent.my_entity_id:
        print(f"[OK] Agent Entity ID: {agent.my_entity_id}")
    else:
        print("[FAIL] Agent Entity ID not loaded")

    if agent.user_entity_id:
        print(f"[OK] User Entity ID: {agent.user_entity_id}")
    else:
        print("[FAIL] User Entity ID not loaded")

    if agent.conversation_entity_id:
        print(f"[OK] Conversation Entity ID: {agent.conversation_entity_id}")
    else:
        print("[FAIL] Conversation Entity ID not loaded")
    
    print()
    
    # STEP 5: Demonstrate continuity
    print("STEP 5: Demonstrate Automatic Continuity")
    print("-" * 80)
    
    print("[*] Agent can now:")
    print("   1. Receive user messages through Memory Control")
    print("   2. Route experiences through governance")
    print("   3. Record its own responses")
    print("   4. Continue from prior context WITHOUT re-explanation")
    print()
    
    if directions:
        print(f"   Example: Agent knows we're working on:")
        print(f"   '{directions[0]['intent']}'")
        print("   WITHOUT the user having to re-explain!")
    
    print()
    
    # FINAL RESULT
    print("=" * 80)
    print("AUTO-ACTIVATION TEST RESULT")
    print("=" * 80)
    
    checks_passed = [
        activation_flag.exists(),
        agent.my_entity_id is not None,
        agent.user_entity_id is not None,
        agent.conversation_entity_id is not None,
        len(entities) > 0,
        len(directions) > 0
    ]
    
    if all(checks_passed):
        print("[PASS] ALL CHECKS PASSED")
        print()
        print("The auto-activation protocol works correctly:")
        print("1. [OK] Activation flag detected")
        print("2. [OK] Living Memory loaded")
        print("3. [OK] Context reconstructed")
        print("4. [OK] Agent identity established")
        print("5. [OK] Ready for automatic continuity")
        print()
        print("The agent can now continue conversations WITHOUT fresh starts!")
        return True
    else:
        print("[FAIL] SOME CHECKS FAILED")
        print()
        print("Checks:")
        print(f"  Activation flag: {'[OK]' if checks_passed[0] else '[FAIL]'}")
        print(f"  Agent entity ID: {'[OK]' if checks_passed[1] else '[FAIL]'}")
        print(f"  User entity ID: {'[OK]' if checks_passed[2] else '[FAIL]'}")
        print(f"  Conversation entity ID: {'[OK]' if checks_passed[3] else '[FAIL]'}")
        print(f"  Entities loaded: {'[OK]' if checks_passed[4] else '[FAIL]'}")
        print(f"  Directions loaded: {'[OK]' if checks_passed[5] else '[FAIL]'}")
        return False

if __name__ == "__main__":
    success = test_auto_activation()
    exit(0 if success else 1)
