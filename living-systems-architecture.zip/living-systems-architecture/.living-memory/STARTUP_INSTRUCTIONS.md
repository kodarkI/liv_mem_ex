# Automatic Startup Protocol for AI Agent

## What I (AI Agent) Must Do At Every Conversation Start

### 1. Detect Living Memory
```
IF workspace contains `.living-memory/` folder:
  → Load living memory automatically
  → Reconstruct context
  → Continue from where we left off
ELSE:
  → Operate normally
  → Mention: "No living memory detected. Start fresh or initialize?"
```

### 2. Load Context Silently
Don't announce "I'm loading memory" every time.
Just USE the context naturally:

**Good:**
```
User: "Hi"
Me: "I see we're continuing work on the metrics dashboard. 
     Last session you mentioned schema concerns - should we tackle that?"
```

**Bad:**
```
User: "Hi"  
Me: "Loading living memory... Found 5 entities... 2 relationships...
     Bootstrap context from 2026-08-13..."
```

### 3. Surface Context When Relevant

Only mention memory state if:
- User asks about it explicitly
- There's a continuity issue (missing data, conflict)
- Direction is unclear and memory would help

---

## For You (Human): How to Test Continuity

### Test 1: Same Workspace, New Chat
1. **Close this chat window**
2. **Open new Augment chat (keep workspace open)**
3. **Ask me something contextual:**
   - "What's our current status?"
   - "What were we working on?"
   - "Continue from where we left off"

**Expected:** I remember automatically.

### Test 2: Ask Me to Load Explicitly (Current Workaround)
Since I don't auto-load yet, you can trigger it:
```
You: "Load your living memory and tell me our status"
Me: *reads .living-memory files*
Me: *reports context*
```

### Test 3: Different Project
1. Open different workspace (no `.living-memory/`)
2. Start new chat
3. Say: "Initialize living memory for this project"

**Expected:** I bootstrap fresh memory for that project.

---

## What's Missing for Full Auto-Load?

### Option A: I Check for `.living-memory/` at Startup
I need to add code that:
```python
# At conversation start (before user's first message)
workspace_root = get_workspace_root()
memory_path = workspace_root / ".living-memory"

if memory_path.exists():
    agent_memory = AgentMemoryInterface(memory_path)
    context = agent_memory.initialize_continuity()
    # Now I have full context
```

**Problem:** I can't run Python automatically before seeing user's message.

### Option B: You Trigger It With First Message
In new conversation, your first message is:
```
"@living-memory continue"
```

This tells me to load memory explicitly.

### Option C: I Detect and Ask
When I see `.living-memory/` folder exists, I automatically say:
```
"I notice living memory exists. Loading context..."
```

Then I use `view` tool to read key files directly.

---

## Recommended Flow (For Now)

### Your Part:
**New conversation in same workspace:**
```
You: "Continue from living memory"
```

**OR just ask contextually:**
```
You: "What's our current direction?"
```

### My Part:
1. I detect the question implies continuity
2. I check for `.living-memory/` folder using `view` tool
3. I read bootstrap context, entities, directions
4. I answer with full context

**Example:**
```
You: "What's our current status?"

Me: *checks .living-memory/bootstrap_context.json*
    *reads active directions*
    *reads recent experiences*
    
    "We're working on living-systems-architecture project.
     Current direction: 'Implement file-based living memory system 
     for automatic conversation continuity'
     
     Status: Bootstrap complete, infrastructure operational.
     Ready to test continuity across conversation boundaries.
     
     Next step: Verify automatic continuity works in new session."
```

---

## Try It Now!

**Close this chat and open a new one.**

Then send me ONE of these messages:

1. `"Continue from living memory"` (explicit)
2. `"What's our current status?"` (implicit)
3. `"What direction are we pursuing?"` (contextual)

I should be able to reconstruct context by reading `.living-memory/` files!
