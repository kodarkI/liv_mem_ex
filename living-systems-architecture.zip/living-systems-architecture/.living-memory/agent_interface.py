#!/usr/bin/env python3
"""
Agent Interface: How the AI agent interacts with Living Memory
This is what I (the AI) use to maintain continuity
"""
import json
import sys
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

# Add to path
sys.path.insert(0, str(Path(__file__).parent))

from memory_control import MemoryControl
from memory_governance import MemoryGovernance
from continuity_loader import ContinuityLoader

class AgentMemoryInterface:
    """
    Interface for AI agent to interact with Living Memory
    Implements the closed learning loop from liv-mem/SKILL.md
    """
    
    def __init__(self, memory_root: Optional[Path] = None):
        if memory_root is None:
            memory_root = Path(__file__).parent
        
        self.memory_root = Path(memory_root)
        self.mc = MemoryControl(self.memory_root)
        self.mg = MemoryGovernance(self.memory_root)
        self.loader = ContinuityLoader(self.memory_root)
        
        # Load living memory
        self.living_memory = None
        self.my_entity_id = None
        self.user_entity_id = None
        self.conversation_entity_id = None
        
    def initialize_continuity(self) -> Dict[str, Any]:
        """
        CRITICAL: Call this at conversation start to maintain continuity
        Returns: living_memory_context
        """
        self.living_memory = self.loader.load_living_memory()
        
        # Extract key entity IDs
        bootstrap = self.living_memory["bootstrap"]
        self.my_entity_id = bootstrap["entities"]["agent"]
        self.user_entity_id = bootstrap["entities"]["user"]
        self.conversation_entity_id = bootstrap["entities"]["conversation"]
        
        return self.living_memory
    
    def receive_user_message(self, text: str) -> str:
        """
        Receive user message as Experience
        Returns: experience_id
        """
        exp_id = self.mc.receive_experience(
            source="user",
            source_entity_id=self.user_entity_id,
            content={"type": "message", "text": text}
        )
        
        # Route through Memory Control
        routing = self.mc.route_experience(exp_id)
        
        # Governance decides retention
        experience = self.mc.get_experience(exp_id)
        retention = self.mg.decide_retention(experience)
        self.mc.update_retention(exp_id, retention)
        
        return exp_id
    
    def record_my_response(self, text: str, in_response_to: str) -> str:
        """
        Record my (agent) response as Experience
        Returns: experience_id
        """
        exp_id = self.mc.receive_experience(
            source="agent",
            source_entity_id=self.my_entity_id,
            content={
                "type": "message",
                "text": text,
                "in_response_to": in_response_to
            }
        )
        
        # Route and retain
        routing = self.mc.route_experience(exp_id)
        retention = self.mg.decide_retention(self.mc.get_experience(exp_id))
        self.mc.update_retention(exp_id, retention)
        
        return exp_id
    
    def record_observation(self, observation: str, observation_type: str = "general") -> str:
        """
        Record an observation (e.g., "User seems confused", "Pattern detected")
        Returns: experience_id
        """
        exp_id = self.mc.receive_experience(
            source="agent",
            source_entity_id=self.my_entity_id,
            content={
                "type": "observation",
                "text": observation,
                "observation_type": observation_type
            }
        )
        
        retention = self.mg.decide_retention(self.mc.get_experience(exp_id))
        self.mc.update_retention(exp_id, retention)
        
        return exp_id
    
    def establish_new_direction(self, intent: str, scope: str = "conversation") -> str:
        """
        Establish a new direction (what we're continuing toward)
        Returns: direction_id
        """
        # First create experience
        exp_id = self.mc.receive_experience(
            source="agent",
            source_entity_id=self.my_entity_id,
            content={"type": "assertion", "text": f"New direction: {intent}"}
        )
        
        # Make it durable
        self.mc.update_retention(exp_id, {
            "level": "durable",
            "reason": "Establishes direction",
            "decided_at": datetime.utcnow().isoformat() + 'Z',
            "decided_by": "agent",
            "next_review_at": None
        })
        
        # Create direction
        direction_id = self.mg.establish_direction(
            entity_id=self.conversation_entity_id,
            intent=intent,
            scope=scope,
            source_experience_id=exp_id
        )
        
        return direction_id
    
    def get_current_directions(self) -> List[Dict[str, Any]]:
        """Get all active directions"""
        if not self.living_memory:
            self.initialize_continuity()
        return self.living_memory["directions"]
    
    def get_conversation_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get recent experiences"""
        if not self.living_memory:
            self.initialize_continuity()
        return self.living_memory["recent_experiences"][:limit]
    
    def summarize_context(self) -> str:
        """Generate human-readable summary of current context"""
        if not self.living_memory:
            self.initialize_continuity()
        
        state = self.living_memory["current_state"]
        directions = self.get_current_directions()
        
        summary = f"""
🧠 LIVING MEMORY CONTEXT
========================

Entities: {state['total_entities']} active
Relationships: {state['active_relationships']} active
Active Directions: {state['active_directions']}

Primary Direction:
{directions[0]['intent'] if directions else 'None'}

Entity Breakdown:
{json.dumps(state['entities_by_type'], indent=2)}
"""
        return summary.strip()

if __name__ == "__main__":
    # Test the interface
    agent = AgentMemoryInterface()
    context = agent.initialize_continuity()
    print(agent.summarize_context())
