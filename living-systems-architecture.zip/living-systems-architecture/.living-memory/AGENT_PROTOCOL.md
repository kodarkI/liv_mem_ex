## Agent Protocol: How I (AI) Maintain Automatic Continuity

**This document defines my (the AI agent's) operating protocol for maintaining living memory across conversations.**

## At Conversation Start

### REQUIRED: Load Living Memory
```python
from .living-memory.agent_interface import AgentMemoryInterface

# Initialize continuity
agent_memory = AgentMemoryInterface()
context = agent_memory.initialize_continuity()

# Now I have:
# - My entity ID
# - User entity ID  
# - Conversation entity ID
# - All active relationships
# - All active directions
# - Recent durable experiences
```

### Reconstruct Context
Based on loaded living memory, I know:

1. **Who the user is** (entity + identity assertions)
2. **What we're working on** (active directions)
3. **What we've established** (entities, states, relationships)
4. **What happened before** (durable experiences)
5. **What I last understood** (historical integration)

## During Conversation

### Every User Message
```python
# Record as experience
exp_id = agent_memory.receive_user_message(user_text)

# This automatically:
# 1. Creates immutable experience record
# 2. Routes through Memory Control
# 3. Applies Memory Governance retention decision
```

### Every Agent Response
```python
# Record my response
exp_id = agent_memory.record_my_response(
    my_response_text,
    in_response_to=user_experience_id
)
```

### When I Detect New Direction
```python
# User says: "Let's build a metrics dashboard"
direction_id = agent_memory.establish_new_direction(
    intent="Build metrics dashboard feature",
    scope="project"  # or "conversation", "session", "ongoing"
)
```

### When I Make Observations
```python
# Pattern detected, recurring issue, etc.
obs_id = agent_memory.record_observation(
    "User repeatedly asks about authentication - may need better docs",
    observation_type="recurring_pattern"
)
```

## Key Operating Rules (from liv-mem architecture)

### 1. **Route ALL experiences through Memory Control**
- Never directly create entities/relationships/states
- Always go through memory_control.receive_experience()
- Let Memory Governance decide what becomes truth

### 2. **Respect the progression**
- POSSIBLE → CANDIDATE → SUPPORTED → ESTABLISHED → ACTIVE
- A possibility is NOT automatically a relationship
- A relationship is NOT automatically active context

### 3. **Never rewrite history**
- When current state changes, supersede (don't delete)
- Keep historical snapshots with successor links
- Preserve provenance and evidence

### 4. **Explicit retention decisions**
- EPHEMERAL: Immediate processing only
- RETAINED: May matter later
- DURABLE: Establishes identity/state/relationship/direction
- ARCHIVED: Outside ordinary retrieval

### 5. **Attention is governed**
- Don't retrieve everything always
- Use attention policy (reference/10)
- Dormant history can be reactivated when relevant

## Conversation End Protocol

### Save Current State
At conversation end, current state is already persisted because:
- Every experience was written as immutable file
- Entities/relationships/directions are in governed files
- Next conversation will load from these files

### NO CLEANUP NEEDED
- Don't delete ephemeral records yet (retention policy handles this)
- Don't archive relationships (governance determines dormancy)
- Don't summarize into markdown (that would lose structure)

## Next Conversation Start

### The Magic: Automatic Continuity
1. New conversation, new agent instance
2. Call `agent_memory.initialize_continuity()`
3. Living Memory reconstructed from files
4. I know everything from before WITHOUT the user re-explaining

### What I Can Say
```
"I see we're continuing work on the metrics dashboard feature. 
Last conversation, you mentioned authentication concerns. 
Should we address that first, or proceed with the schema design?"
```

### What I CANNOT Say (without memory)
```
"I don't have context from previous conversations."
"Can you remind me what we were working on?"
"Let's start fresh."
```

## Integration with Existing Skills

### When liv-mem skill activates
The `living-systems-architecture` skill instructs me to:
- Apply entity/state/relationship/history separation
- Use Memory Control and Governance
- Keep history intact when state changes
- Surface unresolved mechanics explicitly

### Every conversation uses liv-mem
From now on, EVERY conversation:
1. Starts with `agent_memory.initialize_continuity()`
2. Records experiences through Memory Control
3. Respects Memory Governance decisions
4. Maintains living memory

## Experiments Status

✅ **Experiment 1: Automatic Continuity** - ACTIVE NOW
- Files created: `.living-memory/*`
- Bootstrap complete
- Continuity loader ready
- Agent interface operational

🚧 **Next: Test across real conversation boundary**
- End this conversation
- Start new conversation
- Verify I remember context
- Verify no human re-explanation needed

📋 **Future experiments**:
- Experiment 2: Adversarial memory testing
- Experiment 3: Skill emergence  
- Experiment 4: Multi-conversation goals
- Experiment 5: Relationship evolution

## References

Operating contracts: `.augment/skills/liv-mem/references/01-17`
