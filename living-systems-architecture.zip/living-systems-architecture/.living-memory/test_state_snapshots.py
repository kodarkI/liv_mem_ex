#!/usr/bin/env python3
"""
Test State Snapshot Implementation
Tests state creation, supersession chain, and history preservation
"""
import sys
import io
from pathlib import Path

if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

from memory_control import MemoryControl
from memory_governance import MemoryGovernance

print("=" * 80)
print("STATE SNAPSHOT TEST")
print("=" * 80)
print()

memory_root = Path(__file__).parent
mc = MemoryControl(memory_root)
mg = MemoryGovernance(memory_root)

# Create test entity
entity_id = "test_project_123"

# Create experiences for state changes
exp1 = mc.receive_experience(source="test", content={"type": "observation", "text": "Project created"})
exp2 = mc.receive_experience(source="test", content={"type": "observation", "text": "Project in development"})
exp3 = mc.receive_experience(source="test", content={"type": "observation", "text": "Project deployed to staging"})
exp4 = mc.receive_experience(source="test", content={"type": "observation", "text": "Project in production"})

print("Created test entity and 4 state-change experiences")
print()

# State 1: Created
print("STATE 1: Project Created")
print("-" * 80)

state1_id = mg.create_state_snapshot(
    entity_id=entity_id,
    fields={"status": "created", "phase": "planning", "completion": 0},
    source_experiences=[exp1]
)

print(f"State ID: {state1_id[:8]}...")
print(f"Fields: status=created, phase=planning, completion=0%")
print(f"Status: current")
print()

# State 2: In Development
print("STATE 2: In Development (supersedes State 1)")
print("-" * 80)

state2_id = mg.create_state_snapshot(
    entity_id=entity_id,
    fields={"status": "in_development", "phase": "implementation", "completion": 25},
    source_experiences=[exp2]
)

print(f"State ID: {state2_id[:8]}...")
print(f"Fields: status=in_development, phase=implementation, completion=25%")
print(f"Supersedes: {state1_id[:8]}...")
print()

# State 3: Staging
print("STATE 3: Staging (supersedes State 2)")
print("-" * 80)

state3_id = mg.create_state_snapshot(
    entity_id=entity_id,
    fields={"status": "staging", "phase": "testing", "completion": 75},
    source_experiences=[exp3]
)

print(f"State ID: {state3_id[:8]}...")
print(f"Fields: status=staging, phase=testing, completion=75%")
print(f"Supersedes: {state2_id[:8]}...")
print()

# State 4: Production
print("STATE 4: Production (supersedes State 3)")
print("-" * 80)

state4_id = mg.create_state_snapshot(
    entity_id=entity_id,
    fields={"status": "production", "phase": "operations", "completion": 100},
    source_experiences=[exp4]
)

print(f"State ID: {state4_id[:8]}...")
print(f"Fields: status=production, phase=operations, completion=100%")
print(f"Supersedes: {state3_id[:8]}...")
print()

# Retrieve state history
print("=" * 80)
print("STATE HISTORY RECONSTRUCTION")
print("=" * 80)
print()

history = mg.get_state_history(entity_id)

print(f"Total snapshots: {len(history)}")
print()

for i, state in enumerate(history):
    status_marker = "[CURRENT]" if state.get("status") == "current" else "[HISTORICAL]"
    print(f"{i+1}. {status_marker} {state['fields'].get('status', 'unknown')}")
    print(f"   Snapshot ID: {state['id'][:8]}...")
    print(f"   Phase: {state['fields'].get('phase', 'N/A')}")
    print(f"   Completion: {state['fields'].get('completion', 0)}%")
    print(f"   Effective at: {state['effective_at'][:19]}")
    if state.get('supersedes'):
        print(f"   Supersedes: {state['supersedes'][:8]}...")
    if state.get('superseded_by'):
        print(f"   Superseded by: {state['superseded_by'][:8]}...")
    print()

# Validation
print("=" * 80)
print("VALIDATION")
print("=" * 80)
print()

# Check chain integrity
current_states = [s for s in history if s.get("status") == "current"]
historical_states = [s for s in history if s.get("status") == "historical"]

print(f"Current states: {len(current_states)}")
print(f"Historical states: {len(historical_states)}")
print()

if len(current_states) == 1 and len(historical_states) == 3:
    print("[PASS] Exactly one current state, rest are historical")
else:
    print(f"[FAIL] Expected 1 current and 3 historical, got {len(current_states)} and {len(historical_states)}")

# Check supersession chain
if current_states:
    current = current_states[0]
    if current['fields']['status'] == 'production':
        print("[PASS] Current state is latest (production)")
    else:
        print(f"[FAIL] Current state should be 'production', got '{current['fields']['status']}'")

# Check history preserved
if all(s.get('supersedes') or s == historical_states[-1] for s in historical_states):
    print("[PASS] Supersession chain intact")
else:
    print("[FAIL] Supersession chain broken")

print()
print("=" * 80)
print("STATE SNAPSHOT SYSTEM: COMPLETE")
print("=" * 80)
