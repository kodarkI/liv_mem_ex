#!/usr/bin/env python3
"""
Memory Control: Routes incoming experiences and detects changes
Reference: .augment/skills/liv-mem/references/04-operating-contracts.md
"""
import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional

class MemoryControl:
    """Routes Current Experience through governance before assigning permanence"""
    
    def __init__(self, memory_root: Path):
        self.memory_root = Path(memory_root)
        self.experiences_dir = self.memory_root / "experiences"
        self.experiences_dir.mkdir(parents=True, exist_ok=True)
        
    def receive_experience(self, 
                          source: str,
                          content: Dict[str, Any],
                          source_entity_id: Optional[str] = None,
                          occurred_at: Optional[str] = None) -> str:
        """
        Create immutable Experience record
        Returns: experience_id
        """
        experience_id = str(uuid.uuid4())
        received_at = datetime.utcnow().isoformat() + 'Z'
        
        experience = {
            "id": experience_id,
            "source": source,
            "source_entity_id": source_entity_id,
            "occurred_at": occurred_at or received_at,
            "received_at": received_at,
            "content": content,
            "interpretation_status": "raw",
            "routed_to": [],
            "retention_level": "ephemeral"  # Default until governed
        }
        
        # Write immutable experience
        exp_file = self.experiences_dir / f"{experience_id}.json"
        with open(exp_file, 'w') as f:
            json.dump(experience, f, indent=2)
            
        return experience_id
    
    def route_experience(self, experience_id: str) -> Dict[str, List[str]]:
        """
        Analyze experience and determine memory operations
        Returns: routing decisions
        """
        exp_file = self.experiences_dir / f"{experience_id}.json"
        with open(exp_file, 'r') as f:
            experience = json.load(f)
        
        routing = {
            "entity_operations": [],
            "state_operations": [],
            "relationship_operations": [],
            "direction_operations": [],
            "skill_operations": []
        }
        
        content_type = experience["content"].get("type")
        text = experience["content"].get("text", "")
        
        # Simple routing heuristics (to be refined)
        if content_type == "message":
            # Check for entity mentions, state changes, relationships
            if any(word in text.lower() for word in ["i am", "my name", "i'm"]):
                routing["entity_operations"].append("identify_source_entity")
            
            if any(word in text.lower() for word in ["build", "create", "implement"]):
                routing["direction_operations"].append("establish_intent")
            
            if any(word in text.lower() for word in ["works on", "depends on", "relates to"]):
                routing["relationship_operations"].append("propose_relationship")
                
        # Update experience with routing
        experience["interpretation_status"] = "routed"
        experience["routed_to"] = [
            op for ops in routing.values() for op in ops
        ]
        
        with open(exp_file, 'w') as f:
            json.dump(experience, f, indent=2)
            
        return routing
    
    def get_experience(self, experience_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve an experience by ID"""
        exp_file = self.experiences_dir / f"{experience_id}.json"
        if not exp_file.exists():
            return None
        with open(exp_file, 'r') as f:
            return json.load(f)
    
    def update_retention(self, experience_id: str, retention_decision: Dict[str, Any]):
        """Update experience with governance retention decision"""
        exp_file = self.experiences_dir / f"{experience_id}.json"
        with open(exp_file, 'r') as f:
            experience = json.load(f)
        
        experience["retention_level"] = retention_decision["level"]
        experience["retention_decision"] = retention_decision
        
        with open(exp_file, 'w') as f:
            json.dump(experience, f, indent=2)
