#!/usr/bin/env python3
"""
Memory Governance: Protects coherence by controlling what becomes established truth
Reference: .augment/skills/liv-mem/references/02-core-layers.md
          .augment/skills/liv-mem/references/08-memory-lifecycle-truth-and-promotion.md
"""
import json
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional

class MemoryGovernance:
    """
    Controls progression: POSSIBLE → CANDIDATE → SUPPORTED → ESTABLISHED → ACTIVE/DORMANT/HISTORICAL
    """
    
    def __init__(self, memory_root: Path):
        self.memory_root = Path(memory_root)
        self.entities_dir = self.memory_root / "entities"
        self.states_dir = self.memory_root / "states"
        self.relationships_dir = self.memory_root / "relationships"
        self.directions_dir = self.memory_root / "directions"
        
        for d in [self.entities_dir, self.states_dir, self.relationships_dir, self.directions_dir]:
            d.mkdir(parents=True, exist_ok=True)
    
    def decide_retention(self, experience: Dict[str, Any]) -> Dict[str, Any]:
        """
        Decide retention level per reference/08-memory-lifecycle-truth-and-promotion.md
        Returns retention decision
        """
        content_type = experience["content"].get("type")
        routed_to = experience.get("routed_to", [])
        
        # Default: EPHEMERAL
        level = "ephemeral"
        reason = "Received material with no established continuing value"
        next_review = datetime.utcnow() + timedelta(hours=1)
        
        # Promote to RETAINED if routed to memory operations
        if routed_to:
            level = "retained"
            reason = "Routed to memory operations; may matter later"
            next_review = datetime.utcnow() + timedelta(days=1)
        
        # Promote to DURABLE if establishes identity, state, relationship, or direction
        durable_operations = ["identify_source_entity", "establish_intent", 
                             "propose_relationship", "state_update"]
        if any(op in routed_to for op in durable_operations):
            level = "durable"
            reason = "Establishes identity, state, relationship, or direction"
            next_review = None  # Durable doesn't auto-expire
        
        return {
            "level": level,
            "reason": reason,
            "decided_at": datetime.utcnow().isoformat() + 'Z',
            "decided_by": "memory_governance",
            "next_review_at": next_review.isoformat() + 'Z' if next_review else None
        }
    
    def propose_entity(self, entity_type: str, identity_assertion: str, 
                      source_experience_id: str) -> str:
        """
        Propose new entity (not automatic - requires governance)
        Returns: entity_id
        """
        entity_id = str(uuid.uuid4())
        created_at = datetime.utcnow().isoformat() + 'Z'
        
        entity = {
            "id": entity_id,
            "type": entity_type,
            "identity_assertions": [{
                "assertion": identity_assertion,
                "source": source_experience_id,
                "asserted_at": created_at
            }],
            "lifecycle_status": "active",
            "created_at": created_at
        }
        
        entity_file = self.entities_dir / f"{entity_id}.json"
        with open(entity_file, 'w') as f:
            json.dump(entity, f, indent=2)
            
        return entity_id
    
    def propose_relationship(self, subject_id: str, predicate: str, 
                           object_id: str, origin_experience_id: str) -> str:
        """
        Propose relationship - starts at POSSIBLE, must progress through governance
        Returns: relationship_id
        """
        relationship_id = str(uuid.uuid4())
        created_at = datetime.utcnow().isoformat() + 'Z'
        
        relationship = {
            "id": relationship_id,
            "subject": subject_id,
            "predicate": predicate,
            "object": object_id,
            "status": "possible",  # Not automatic!
            "origin": origin_experience_id,
            "evidence": [origin_experience_id],
            "created_at": created_at
        }
        
        rel_file = self.relationships_dir / f"{relationship_id}.json"
        with open(rel_file, 'w') as f:
            json.dump(relationship, f, indent=2)
            
        return relationship_id
    
    def advance_relationship(self, relationship_id: str,
                           new_status: str, evidence_experience_id: str):
        """
        Advance relationship through governance pipeline
        possible → candidate → supported → established → active
        """
        valid_transitions = {
            "possible": ["candidate", "invalidated"],
            "candidate": ["supported", "invalidated"],
            "supported": ["established", "invalidated"],
            "established": ["active", "dormant"],
            "active": ["dormant", "historical", "invalidated"],
            "dormant": ["active", "historical"]
        }

        rel_file = self.relationships_dir / f"{relationship_id}.json"
        with open(rel_file, 'r') as f:
            relationship = json.load(f)

        current_status = relationship["status"]

        if new_status not in valid_transitions.get(current_status, []):
            raise ValueError(f"Invalid transition: {current_status} → {new_status}")

        relationship["status"] = new_status
        relationship["status_changed_at"] = datetime.utcnow().isoformat() + 'Z'
        if evidence_experience_id not in relationship["evidence"]:
            relationship["evidence"].append(evidence_experience_id)

        with open(rel_file, 'w') as f:
            json.dump(relationship, f, indent=2)

    def evaluate_relationship_advancement(self, relationship_id: str) -> dict:
        """
        Evaluate if relationship should advance based on evidence
        Returns: {"should_advance": bool, "to_status": str, "reason": str}
        """
        rel_file = self.relationships_dir / f"{relationship_id}.json"
        with open(rel_file, 'r') as f:
            relationship = json.load(f)

        current_status = relationship["status"]
        evidence_count = len(relationship.get("evidence", []))

        # Governance rules for advancement
        if current_status == "possible":
            if evidence_count >= 1:  # At least one supporting experience
                return {
                    "should_advance": True,
                    "to_status": "candidate",
                    "reason": f"Initial evidence present ({evidence_count} experience(s))"
                }

        elif current_status == "candidate":
            if evidence_count >= 2:  # Multiple supporting experiences
                return {
                    "should_advance": True,
                    "to_status": "supported",
                    "reason": f"Multiple evidence points ({evidence_count} experiences)"
                }

        elif current_status == "supported":
            if evidence_count >= 3:  # Consistent pattern
                return {
                    "should_advance": True,
                    "to_status": "established",
                    "reason": f"Consistent pattern ({evidence_count} experiences)"
                }

        elif current_status == "established":
            # Manual decision: activate vs keep dormant
            # Check if relationship is referenced in recent experiences
            return {
                "should_advance": False,
                "to_status": current_status,
                "reason": "Established relationships require explicit activation decision"
            }

        return {
            "should_advance": False,
            "to_status": current_status,
            "reason": f"Insufficient evidence (need more than {evidence_count})"
        }

    def apply_relationship_governance(self, relationship_id: str, new_evidence_id: str = None):
        """
        Apply governance: add evidence and auto-advance if criteria met
        Returns: {"advanced": bool, "from_status": str, "to_status": str}
        """
        rel_file = self.relationships_dir / f"{relationship_id}.json"
        with open(rel_file, 'r') as f:
            relationship = json.load(f)

        original_status = relationship["status"]

        # Add new evidence if provided
        if new_evidence_id and new_evidence_id not in relationship.get("evidence", []):
            relationship["evidence"].append(new_evidence_id)
            with open(rel_file, 'w') as f:
                json.dump(relationship, f, indent=2)

        # Evaluate advancement
        evaluation = self.evaluate_relationship_advancement(relationship_id)

        if evaluation["should_advance"]:
            self.advance_relationship(
                relationship_id,
                evaluation["to_status"],
                new_evidence_id or relationship["evidence"][-1]
            )
            return {
                "advanced": True,
                "from_status": original_status,
                "to_status": evaluation["to_status"],
                "reason": evaluation["reason"]
            }
        else:
            return {
                "advanced": False,
                "from_status": original_status,
                "to_status": original_status,
                "reason": evaluation["reason"]
            }
    
    def establish_direction(self, entity_id: str, intent: str,
                          scope: str, source_experience_id: str) -> str:
        """
        Establish Direction - what entity is continuing toward
        Returns: direction_id
        """
        direction_id = str(uuid.uuid4())
        created_at = datetime.utcnow().isoformat() + 'Z'

        direction = {
            "id": direction_id,
            "entity_id": entity_id,
            "intent": intent,
            "scope": scope,
            "status": "active",
            "created_at": created_at,
            "source_experience": source_experience_id,
            "evidence": [source_experience_id],
            "milestones": []
        }

        dir_file = self.directions_dir / f"{direction_id}.json"
        with open(dir_file, 'w') as f:
            json.dump(direction, f, indent=2)

        return direction_id

    def create_state_snapshot(self, entity_id: str, fields: dict,
                             source_experiences: list, effective_at: str = None) -> str:
        """
        Create state snapshot for entity
        Returns: state_snapshot_id
        """
        state_id = str(uuid.uuid4())
        snapshot_at = datetime.utcnow().isoformat() + 'Z'
        effective_at = effective_at or snapshot_at

        # Check for previous current state
        previous_state_id = self._get_current_state(entity_id)

        state_snapshot = {
            "id": state_id,
            "entity_id": entity_id,
            "fields": fields,
            "effective_at": effective_at,
            "snapshot_at": snapshot_at,
            "source_experiences": source_experiences,
            "status": "current"
        }

        if previous_state_id:
            state_snapshot["supersedes"] = previous_state_id

        # Write new state
        state_file = self.states_dir / f"{state_id}.json"
        with open(state_file, 'w') as f:
            json.dump(state_snapshot, f, indent=2)

        # Supersede previous state if exists
        if previous_state_id:
            self._supersede_state(previous_state_id, state_id)

        return state_id

    def _get_current_state(self, entity_id: str):
        """Find current state snapshot for entity"""
        for state_file in self.states_dir.glob("*.json"):
            with open(state_file, 'r') as f:
                state = json.load(f)
                if state["entity_id"] == entity_id and state.get("status") == "current":
                    return state["id"]
        return None

    def _supersede_state(self, old_state_id: str, new_state_id: str):
        """Mark old state as historical and link to new state"""
        old_state_file = self.states_dir / f"{old_state_id}.json"
        with open(old_state_file, 'r') as f:
            old_state = json.load(f)

        old_state["status"] = "historical"
        old_state["superseded_by"] = new_state_id
        old_state["superseded_at"] = datetime.utcnow().isoformat() + 'Z'

        with open(old_state_file, 'w') as f:
            json.dump(old_state, f, indent=2)

    def get_state_history(self, entity_id: str) -> list:
        """
        Get full state history for entity (current → historical chain)
        Returns list ordered newest to oldest
        """
        states = []
        for state_file in self.states_dir.glob("*.json"):
            with open(state_file, 'r') as f:
                state = json.load(f)
                if state["entity_id"] == entity_id:
                    states.append(state)

        # Sort by snapshot_at descending
        states.sort(key=lambda s: s["snapshot_at"], reverse=True)
        return states
