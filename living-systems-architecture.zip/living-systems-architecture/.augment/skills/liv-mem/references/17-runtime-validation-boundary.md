# Runtime validation boundary

## Rule

Treat this skill and canonical architecture as **specification**, not proof of runtime behavior. A defined contract is behaviorally unvalidated until an implementation executes it and produces inspectable evidence.

Report each mechanism separately as: `specified`, `implemented`, `tested`, `observed in operation`, or `unknown`. Do not collapse these states.

## Validation matrix

| Mechanism | Principle | Contract | Runtime responsibility | Test scenarios |
|---|---|---|---|---|
| Living Memory lifecycle | Preserve continuity through change. | Create, validate, update, supersede, archive/prune without rewriting occurrence. | Persist records, links, and projections atomically enough to preserve History. | Supersession, archival, correction, pruning tombstone, out-of-order input. |
| Truth and conflict | Preserve competing claims until governed resolution. | Separate asserted/supported/effective/contested conditions. | Compare scopes/times/evidence and retain resolution rationale. | Reversed arrival order, strong-looking false metadata, weak but later-confirmed source. |
| Attention | Retain broadly; focus selectively. | Separate availability, activation, and attention; enforce release/reopening. | Maintain context/attention allocations and budget. | Do nothing, urgent interruption, release after resolution, dormant reactivation. |
| Event chains | Preserve typed temporal, causal, evidential, and transition relations. | Do not infer causality from order or rewrite earlier Events. | Store/validate typed relations and reconstruct bounded paths. | Missing chain link, multi-meaning Event, contradiction, superseded State. |
| Capability discovery | Do not continuously mine all memory. | Start bounded inquiry only from qualifying signals; support defer/reopen. | Detect signals, manage inquiry state/scope, enforce attention budget. | No-signal no-op, recurring signal, deferred inquiry, stale Candidate. |
| Candidate capability | Do not let proposals become an invisible graveyard. | Use lifecycle through externalization, rejection, or stale/expired disposition. | Store disposition/review/reopen data while preserving underlying evidence. | Repeatedly unsupported Candidate, reactivation after new evidence, duplicate Candidate. |
| Skill reuse and coordination | Apply capabilities only when they fit and safely coordinate sets. | Test individual applicability and classify complement, overlap, conflict, prerequisite, or independence. | Produce/execute coordination plans and prevent unsafe combinations. | Complementary pair, overlapping alternatives, conflict, prerequisite failure, unresolved precedence. |
| Outcome attribution | Do not revise a Skill merely because an outcome is unfavorable. | Attribute outcome with alternatives before lineage/evolution. | Capture context, inputs, environment, concurrent Skills, and attribution status. | Expected success, out-of-scope failure, environment change, joint contribution, ambiguity, one-off failure. |
| Skill lineage/evolution | Keep Skills accountable to origin and outcomes. | Preserve internal lineage, external provenance, or unknown provenance; version changes. | Store origin classification, lineage, versions, and outcome links. | Imported Skill, unknown-origin Skill, revise/split/merge/retire, lineage-loss audit. |
| Self-auditing/regression | Detect drift and preserve learning from failure. | Audit invariants and retain failed cases for replay. | Schedule/trigger audits and run relevant regression cases after change. | Broken reference, contract bypass, reintroduced regression, stale candidate. |

## Minimum runtime evidence

Before claiming a mechanism is behaviorally validated, retain a trace showing: input/trigger, applicable policy and Skill version, decisions, resulting records/projections, and the relevant test or operational outcome. A document review, schema check, or YAML validation alone proves only specification structure.
