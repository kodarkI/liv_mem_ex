# Skill-set coordination and candidate hygiene

## Coordinate an applicable Skill set

Do not reduce an issue to “find one Skill.” When multiple Skills may fit, construct a bounded **Skill coordination plan**:

```text
issue → applicable Skill set → classify relations → coordinate
→ execute or defer → attribute outcome → feedback into Living Memory
```

Classify each material pair or set of Skills:

| Classification | Meaning | Required handling |
|---|---|---|
| Complementary | Skills address different, compatible parts of the same issue. | Compose only with a declared order, shared scope, and outcome plan. |
| Overlapping alternatives | Skills pursue the same or substantially similar outcome by different methods. | Select one under applicability/evidence/Direction; compare or test alternatives only when justified. Do not invoke both by default. |
| Conflicting | Skills prescribe incompatible actions, assumptions, commitments, or truth treatments. | Do not jointly execute. Mark conflict and request governed resolution, defer, or select only under an explicit policy. |
| Prerequisite | One Skill must establish an input, context, State, or authorization before another can safely apply. | Execute/validate prerequisite first; stop or defer dependent Skill if it fails. |
| Independent components | Skills address different parts of an issue without material interaction. | Coordinate only enough to preserve scope, attention, and shared side effects. |

### Coordination procedure

1. Retrieve only Skills whose individual applicability conditions fit the issue.
2. Identify their declared outcomes, boundaries, side effects, prerequisites, and affected Entities/States/Relationships.
3. Classify interactions; do not infer compatibility from shared keywords or a common issue.
4. Create a Skill coordination plan only when more than one Skill will materially participate.
5. Respect focus budget: coordinate the selected set, not every possible Skill.
6. If precedence cannot be determined, do not choose arbitrarily. Defer, request resolution, or perform a bounded comparison if policy permits.
7. Attribute outcomes to the plan and individual Skills using the outcome-attribution rules; preserve `JOINT_CONTRIBUTION` or `AMBIGUOUS` where effects cannot be separated.

## Candidate capability lifecycle

Candidate capabilities are not permanent waiting rooms. They follow this lifecycle:

```text
EMERGING → ACTIVE_CONSIDERATION → DEFERRED → STRENGTHENED
→ EXTERNALIZED / REJECTED / STALE_OR_EXPIRED
```

| Status | Meaning | Required next handling |
|---|---|---|
| EMERGING | A discovery signal suggests a possible reusable capability. | Create only a bounded inquiry or initial Candidate capability. |
| ACTIVE_CONSIDERATION | The Candidate is receiving justified discovery attention. | Gather bounded supporting, limiting, and counterexample evidence. |
| DEFERRED | The Candidate may matter but lacks evidence, focus, expressibility, or resolved blockers. | Preserve evidence, blocker, and reopening condition; do not keep active. |
| STRENGTHENED | New evidence materially improves the Candidate’s understanding, reproducibility, usefulness, or expressibility. | Reapply the externalization test or continue bounded review. |
| EXTERNALIZED | The Candidate became an explicit Skill after governance. | Preserve lineage and transition to Skill lifecycle. |
| REJECTED | Evidence shows it is not a reusable capability, is harmful, duplicates a better existing Skill, or belongs only as a pattern/memory. | Retain disposition and evidence; do not use as an active Candidate. |
| STALE_OR_EXPIRED | No sufficient evidence arrived by review, its context/Direction disappeared, or it repeatedly failed to strengthen. | Remove from active discovery/ordinary candidate retrieval; retain the candidate disposition and underlying memories. Reopen only on a qualifying trigger. |

### Repeatedly unsupported Candidates

When a Candidate repeatedly fails to gain sufficient evidence, do not delete or rewrite its underlying Experiences, Pattern assertions, or counterexamples. Move the Candidate to `STALE_OR_EXPIRED` or `REJECTED` with a reason and reopening condition.

The Candidate is a proposed abstraction, not the evidence itself. It can disappear from ordinary capability consideration while the evidence remains available for future Historical Integration.

## Skill lineage and provenance classes

Every explicit Skill must state one origin classification. Do not fabricate internal lineage.

| Classification | Meaning | Required handling |
|---|---|---|
| Internal lineage | The Skill emerged from material Experiences, History, Pattern assertions, Candidate capability evidence, or prior internal Skill outcomes. | Retain selective typed lineage. |
| External provenance | The Skill was authored, imported, supplied, or otherwise originated outside this Living-Memory system. | Retain source/author/version/license or other available external provenance; accumulate internal outcome evidence only as it occurs. |
| Unknown provenance | The origin is unavailable or cannot be verified. | Mark it explicitly; qualify trust and require appropriate review before high-impact or broad reuse. |

Internal lineage, external provenance, and unknown provenance are evidence conditions, not universal quality scores. An externally authored Skill need not pretend it was born from internal memory; an internally emerged Skill need not claim external authority.
