# Event relationship semantics and chains

## Purpose

Events are not merely associated nodes in a graph. An Event can cause, depend on, provide evidence about, contradict the interpretation of, reactivate relevance from, continue, recur from, or supersede the consequences of another Event. Preserve these as distinct typed Event relations.

An Event may connect to multiple other Events at the same time with different predicates. Never reduce this to one `related_to` field.

```text
Event A ── CAUSES ───────────────→ Event B
Event C ── PROVIDES_EVIDENCE_FOR → Event A
Event D ── REACTIVATES ──────────→ Event A
Event E ── SUPERSEDES_STATE_FROM → Event A / State established from A
```

Each arrow is an independent Event relation with its own evidence, origin, scope, status, and temporal claim.

## Event relation model

Represent Event relations as first-class, directed, typed records:

```text
source Event
  + predicate
  + target Event / State snapshot / claim / interpretation
  + source and evidence
  + assertion and governance status
  + scope
  + temporal claim(s), when known
```

`source Event → predicate → target` is directional. If the reverse is meaningful, record it explicitly or derive it only as a labeled inverse for retrieval; do not silently treat every predicate as symmetric.

One Event may have zero, one, or many Event relations. Multiple relations may share the same Event pair when they express distinct meanings. For example, Event B may both `OCCUR_AFTER` and `RESULT_FROM` Event A; these are not duplicates.

## Typed relation vocabulary

Use the following baseline vocabulary. A project may add predicates but must define their endpoint types, direction, evidence requirements, and interaction with truth/State.

| Predicate | Source → target meaning | Endpoint / guard |
|---|---|---|
| `OCCURS_BEFORE` | Source Event occurred before target Event. | Event → Event. Requires known/asserted temporal basis. Does not assert cause. |
| `OCCURS_AFTER` | Source Event occurred after target Event. | Event → Event. Inverse of `OCCURS_BEFORE`; does not assert cause. |
| `CAUSES` | Source Event was a cause of target Event. | Event → Event. Requires causal evidence or governed causal judgment; temporal order alone is insufficient. |
| `RESULTS_FROM` | Source Event resulted from target Event. | Event → Event. Inverse meaning of `CAUSES`; record/derive with explicit provenance. |
| `DEPENDS_ON` | Source Event could not occur, become effective, or be interpreted as it is without target Event/condition. | Event → Event/State/claim. Must declare dependency type if project distinguishes precondition from enabling context. |
| `HAS_CONSEQUENCE` | Source Event produced a named consequence. | Event → Event/State/Relationship/claim. Must name the consequence target; do not use for vague influence. |
| `PROVIDES_EVIDENCE_FOR` | Source Event supplies evidence concerning target Event, claim, State, or interpretation. | Event → Event/claim/State/interpretation. Evidence affects support, not occurrence or causality by itself. |
| `CONTRADICTS` | Source Event conflicts with a target claim, State, Relationship, or interpretation. | Event → claim/State/Relationship/interpretation. Creates conflict handling; it does not erase target occurrence. |
| `CONTINUES` | Source Event continues a process, interaction, or condition represented by target Event. | Event → Event/process. Requires declared continuity basis. |
| `SUPERSEDES_STATE_FROM` | Source Event led to a governed State transition that supersedes the State established by target Event or transition. | Event → Event/State transition. Requires the actual predecessor/successor State links. |
| `REACTIVATES_RELEVANCE_OF` | Source Event caused a prior target Event/record to be reconsidered as relevant. | Event → Event/record. Requires a new Attention allocation or relevance evaluation; does not itself restore current truth. |
| `RECURS_FROM` | Source Event is a recurrence of a pattern or event type represented by target Event/pattern. | Event → Event/pattern. Requires recurrence criteria; it does not imply identical cause. |
| `CONTEXTUALLY_ASSOCIATED_WITH` | Source and target share a declared context without a stronger known relation. | Event → Event/record. Use only when the common context is named. Never substitute it for cause, evidence, or transition. |
| `INITIATES_TRANSITION` | Source Event initiated a proposed or accepted transition to target State/Relationship condition. | Event → State/Relationship transition. Does not make the target effective without Governance. |
| `CONFIRMS_STATE` | Source Event provides evidence that target State was or remains effective in the declared scope/time. | Event → State snapshot. Does not prevent a later supersession. |

Treat a causal, evidential, contradictory, or interpretive relation as an assertion that can be `ASSERTED`, `VALIDATED`, `SUPPORTED`, `EFFECTIVE`, `CONTESTED`, `QUALIFIED`, or `HISTORICAL` under the truth rules. A valid Event occurrence does not automatically validate any relation asserted about it.

## State-transition history

Model a changing State as a chain of records, not a replacement of Events:

```text
Event A: relationship begins
  └─ INITIATES_TRANSITION → State/Relationship condition S1

Event B: conversation changes the relationship
  ├─ OCCURS_AFTER → Event A
  └─ INITIATES_TRANSITION → transition S1 → S2

Event C: new State becomes effective
  ├─ RESULTS_FROM → Event B            (only if causally supported)
  └─ HAS_CONSEQUENCE → effective S2

Event D: later interaction confirms that State
  ├─ OCCURS_AFTER → Event C
  └─ CONFIRMS_STATE → S2

Event E: new Event changes it again
  ├─ OCCURS_AFTER → Event D
  ├─ INITIATES_TRANSITION → transition S2 → S3
  └─ SUPERSEDES_STATE_FROM → Event C / S2
```

After Event E, retain A–D. The current projection can show S3 as effective while reconstruction can state: A occurred; B followed and may have resulted from A if supported; C made S2 effective; D supported S2; E superseded S2 through the governed S2 → S3 transition. Do not rewrite A–D to make S3 appear always true.

## Building and reconstructing chains

### Create an Event relation

1. Identify source and target records and their endpoint types.
2. Select the most specific supported predicate. If only a shared context is known, use `CONTEXTUALLY_ASSOCIATED_WITH`; if nothing specific is known, retain an incomplete observation rather than `related_to`.
3. Record evidence, relation source, scope, and known/asserted time.
4. Route causality, contradiction, state effect, and relevance effect through Memory Governance.
5. Preserve relation status separately from the source and target Event statuses.

### Reconstruct a chain

1. Start from a target Event, State, Relationship, or current question.
2. Traverse only predicates relevant to the requested chain: temporal, causal/consequence, dependency, evidence, contradiction, continuation/recurrence, relevance, or State transition.
3. Preserve predicate labels and uncertainty at every step. Do not present `OCCURS_BEFORE` as `CAUSES`, or `PROVIDES_EVIDENCE_FOR` as confirmation of occurrence.
4. Use governed State predecessor/successor links as the authoritative State-transition chain.
5. Bound traversal by current scope, direction, attention budget, and project-defined depth; return omitted branches rather than exploring every association.
6. If a chain branches, show alternatives; if it conflicts or cycles, report that rather than forcing linear order.

### Derive an implication from a chain

When asked what a later Event implies about an earlier Event, create a **Derived inference** rather than modifying or relabeling either Event.

1. State the question, start/end records, and exact traversed path.
2. Separate direct assertions from conclusions derived across the path.
3. State the permitted conclusion narrowly. For example, `A → CAUSES B → CAUSES C → CAUSES D` may support a governed inference that A is an indirect causal ancestor of D; it does not prove every property of D is a property of A.
4. Preserve uncertainty: an asserted or contested link yields an asserted or contested inference, not an effective fact.
5. Retain the inference as a versioned, sourced interpretation that may be qualified or superseded without changing the chain’s Events or direct relations.

## Rules and edge cases

- Temporal order permits sequence reconstruction but never proves causality.
- Evidence about an Event may support, challenge, or qualify claims about it; it never changes the fact that the source Event occurred.
- `CONTRADICTS` targets an assertion, State, Relationship, or interpretation—not the existence of an immutable historical Event.
- `SUPERSEDES_STATE_FROM` must point to the superseded State/transition or its establishing Event and must agree with governed State predecessor/successor links.
- `REACTIVATES_RELEVANCE_OF` triggers relevance/attention evaluation; it does not automatically make the prior Event active, focused, effective, or durable.
- `RECURS_FROM` records patterned recurrence without claiming identical causes, identities, or outcomes.
- A chain can branch. Do not flatten multi-cause, multi-evidence, or multi-consequence history into one linear story.
- A relation cycle may be a valid feedback-loop assertion, but it must be explicitly typed and governed. Do not use it as a simple temporal chain.
- A derived chain inference is not direct evidence. It must expose its path, assumptions, and relation statuses.

## Audit questions

For every material Event chain, verify:

- Are all links typed rather than generic associations?
- Does each causal, evidential, contradictory, or supersession relation have source/evidence and status?
- Are temporal claims separate from causal claims?
- Do State-transition relations match the State predecessor/successor history?
- Can each Event retain multiple independent relations without overwriting another?
- Does reconstruction preserve ambiguity, branches, and historical meaning after supersession?
