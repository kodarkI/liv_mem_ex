# Memory lifecycle, truth, and promotion

## Status of this reference

This reference adds baseline operating decisions needed to answer what happens to memory over time, when memory conflicts, and when it deserves durable retention. These are design decisions for this skill, not retroactive claims about the original top-down architecture.

## Memory lifecycle

Every memory-bearing record follows this lifecycle. The lifecycle applies independently to Experience, State snapshot, Relationship, Integration assertion, Direction / Intent, and derived context membership.

```text
CREATE → VALIDATE → USE → UPDATE → SUPERSEDE → ARCHIVE → PRUNE
```

| Stage | Required behavior |
|---|---|
| Create | Assign an immutable identifier, source, received time, and record type. Store the original assertion or a permitted reference to it. |
| Validate | Check required fields, source/provenance, identity resolution, scope, temporal claims, policy boundaries, and duplicates. Invalid records remain observations or rejected proposals; they do not become current truth. |
| Use | Permit a validated, governed record to participate in retrieval, integration, or current context according to its status and Relevance. Use does not itself promote or establish it. |
| Update | Express changed content as a new record or new version linked to its predecessor and source. Record the transition in History. |
| Supersede | When a later governed record replaces an earlier record as effective for the same scope and time rule, retain the earlier record and link it to its successor. A superseded record is historical, not deleted or declared false by default. |
| Archive | Remove a retained record from ordinary active retrieval while preserving its identifier, provenance, History links, lifecycle status, and the reason/timing for archival. Archived records are retrievable through explicit historical access. |
| Prune | Remove or irreversibly minimize content only under an explicit retention/deletion policy. Preserve a tombstone containing the identifier, record type, lifecycle decision, time, authorized reason, and permitted provenance so continuity and audits do not falsely show that nothing existed. |

### What happens when memory is no longer current truth?

Do not delete or overwrite it. Determine whether a later governed record **supersedes** it for a declared scope. If so, retain it as historical with a successor link. If the record is merely no longer relevant, move it to dormant or archive it according to retention policy. If it was invalid or disproved, retain its assertion and the governed qualification/rejection in History.

## Truth and conflict resolution

### Truth categories

Do not treat “truth” as one global flag. A claim must carry a truth category relative to its scope, source, evidence, and effective time.

| Category | Meaning |
|---|---|
| ASSERTED | A source made the claim; it has not passed validation/governance. |
| VALIDATED | Required structure, origin, and boundary checks passed; this does not confirm content. |
| SUPPORTED | Recorded evidence supports the claim, but it has not yet been committed as effective. |
| EFFECTIVE | Governance has selected the claim as current truth for a declared scope and time. |
| HISTORICAL | The claim was previously effective or remains a meaningful occurrence, but is not current truth for the queried scope/time. |
| CONTESTED | Competing claims cannot be resolved under current policy. |
| QUALIFIED | The claim remains recorded but is limited, corrected, or disproved by a later governed decision. |

Use `SUPPORTED`, `ESTABLISHED`, and related Relationship statuses consistently: a Relationship becomes **EFFECTIVE** only when it is `ESTABLISHED` and valid for the queried scope/time. It becomes **ACTIVE** only when also selected by Relevance.

Validation of metadata format, presence, or consistency is not proof that a source is authentic, authoritative, independent, or correct. Treat strong-looking metadata as an assertion about provenance until the project-defined provenance/authenticity policy verifies it. Conversely, weak provenance does not make a claim false: retain it as ASSERTED or VALIDATED according to what actually passed, without promoting it to EFFECTIVE solely to avoid uncertainty.

### Resolution procedure

When two records address the same subject, predicate/field, scope, and overlapping effective time:

1. Retain both records and their sources. Do not deduplicate by deleting evidence.
2. Determine whether they are actually different scopes, times, or interpretations. If they are, preserve both without declaring conflict.
3. If they are semantically the same assertion with the same source/content, link them as duplicates; retain their separate provenance when useful.
4. If they conflict, compare only project-declared resolution factors: source authority, directness of evidence, corroboration, effective time, and explicit correction/supersession.
5. If one claim wins under declared policy, mark it EFFECTIVE and mark the other HISTORICAL or QUALIFIED, with the reason.
6. If policy cannot decide, mark all competing claims CONTESTED and return no single current truth for that scope. Request resolution rather than silently guessing.
7. Record the conflict, decision, policy version, and evidence in History.

Newer is not automatically truer. A newer claim supersedes an older one only when it concerns the same scope and is accepted under the declared policy.

### Order and duplicate safeguards

- Given the same complete evidence set, scope, policy version, and effective-time facts, the final governed truth result must not depend on the order in which the system received the claims. Receipt order remains historical provenance and may affect interim attention, but not the final resolution.
- When the same information recurs with subtle differences, preserve each submitted Experience. Compare claims field-by-field; link only exact or policy-defined semantic duplicates. Do not count mutually dependent, copied, or duplicate sources as independent corroboration.
- If equivalence cannot be determined, retain separate candidate/contested claims and request resolution. Do not merge them merely because they are similar.

## Promotion and retention control

Separate occurrence from durable memory. An Experience may be recorded without being promoted for long-term Living Memory.

| Promotion level | Meaning | Minimum requirement | Ordinary handling |
|---|---|---|---|
| EPHEMERAL | Received material with no established continuing value. | Create and basic validation. | Use only for immediate processing; archive or prune under policy. |
| RETAINED | A validated observation or proposal that may matter later. | Provenance and a defined reason to retain. | Keep accessible to History and governed retrieval. |
| DURABLE | A memory bearing continuing identity, State, Relationship, origin, transition, Direction, or repeatedly demonstrated Relevance. | Governance acceptance plus rationale/evidence. | Preserve continuity links; do not prune except under explicit overriding policy. |
| ARCHIVED | Retained but outside ordinary retrieval/context. | Retention review or loss of ordinary relevance. | Preserve metadata and historical retrieval path. |

Memory Governance decides promotion. It must record the level, reason, source/evidence, policy version, and next review time.

Promote to `DURABLE` when at least one defined reason applies: it establishes or changes persistent identity; it establishes or changes effective State or Relationship; it preserves origin or an important transition; it is necessary to explain an already durable memory; it remains relevant across repeated evaluations; or project policy marks it as required.

Do not promote solely because an item is recent, emotionally salient, retrieved often by accident, or plausible. If no durable criterion applies, keep it EPHEMERAL or RETAINED and schedule review/expiry according to policy.

## Retention decision procedure

1. Classify the record type and its current lifecycle/temporal status.
2. Validate provenance and policy boundaries.
3. Check for a durable-promotion reason.
4. Select promotion level and next review time.
5. Record the Retention decision in History.
6. At review, retain, promote, demote, archive, or prune under policy; never destroy a record without the required lifecycle evidence/tombstone.
