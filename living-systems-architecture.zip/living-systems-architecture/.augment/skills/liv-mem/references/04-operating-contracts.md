# Operating contracts

## Status of this reference

The original architecture is top-down. This reference makes the minimum additional design decisions needed to operate it consistently. Treat these as **baseline defaults**, not as claims that the original architecture already specified them. A project may override a baseline only by documenting the replacement rule and its effect on the foundational principles.

## Canonical records

Use these conceptual records regardless of physical storage format.

| Record | Required contents | Owner |
|---|---|---|
| Experience | immutable identifier, source, occurrence time when known, received time, raw content or reference, and interpretation status | Memory Control |
| Entity | stable identifier, type, identity assertions, and lifecycle status | Entity |
| State snapshot | Entity identifier, asserted fields, effective time, source Experience(s), and supersession link when applicable | State + History |
| Relationship | stable identifier, subject Entity, predicate, object Entity/value, status, origin, evidence, and temporal validity when known | Relationship + Memory Governance |
| History event | immutable identifier, event type, occurrence/recorded time, affected record identifiers, origin, and payload/reference | History |
| Event relation | stable identifier, source Event, typed predicate, target Event/State/claim/interpretation, origin, evidence, asserted/effective time where applicable, status, and scope | Relationship + History + Memory Governance |
| Derived inference | immutable identifier, question, conclusion, traversal path, relation labels/statuses, assumptions, uncertainty, scope, and governing rule/version | Historical Integration + Memory Governance |
| Ontology extension proposal | novel observation, why current Entity/State/Relationship/Event categories are insufficient, candidate concept/predicate, examples, impact, status, and policy/version | Historical Integration + Skill Evolution + Memory Governance |
| Integration assertion | identifiers of connected History/Experience items, asserted interpretation, rationale/evidence, and status | Historical Integration + Memory Governance |
| Direction / Intent | scope, statement or reference, source, status, and effective time | Direction / Intent |
| Context membership | member identifier, reason for Relevance, activation status, and evaluation time | Living Memory |
| Retention decision | record identifier, promotion level, decision, reason, review time, and governing policy/version | Memory Governance |
| Audit finding | immutable identifier, audit run, invariant checked, affected record/component, severity, evidence, and disposition | Self-Auditing |
| Skill version | skill identifier, version, rules, rationale, effective time, approval/disposition, supersession link, and provenance classification | Skill Evolution |
| Attention allocation | target record/issue, attention state, priority reason, triggering event, scope, allocation time, release/review condition, and policy version | Attention Control + Memory Governance |
| Regression case | immutable identifier, scenario inputs, attacked assumption, expected invariants, observed outcomes, classification, governing Skill/policy versions, and replay history | Self-Auditing + Skill Evolution |
| Pattern assertion | linked Experiences/History, observed regularity, scope, evidence, counterexamples, status, and interpretation | Historical Integration + Memory Governance |
| Candidate capability | proposed reusable capability, intended outcome, scope, boundaries, supporting/limiting evidence, reproducibility basis, usefulness basis, expressibility, lifecycle status, review time, and disposition reason | Historical Integration + Memory Governance |
| Skill lineage relation | Skill/candidate capability, typed relation to supporting, limiting, contradictory, or operational evidence, lineage/provenance classification, source, status, and time | Skill Evolution + History |
| Skill coordination plan | issue/scope, applicable Skill set, relation classification, prerequisites/order, selected alternatives, conflicts, attention allocation, and execution/evaluation plan | Skills + Attention Control + Memory Governance |
| Skill invocation / execution | Skill version, requested outcome, current scope/Direction, applicability decision, inputs, output/result, exceptions, and operational evidence reference | Skills + Memory Control |
| Candidate Experience from Skill use | material outcome evidence, originating Skill invocation/execution, reason it may matter, scope, and candidate status | Memory Control + Memory Governance |
| Capability discovery inquiry | triggering signal, proposed scope, inspected evidence/counterexamples, attention state, defer/reopen condition, and outcome | Historical Integration + Attention Control |
| Outcome attribution assertion | Skill invocation/execution, observed outcome, inputs, context, environment evidence, simultaneous Skills, alternative explanations, conclusion/status, and rationale | Historical Integration + Memory Governance |

Do not make a current State, active Relationship, or current context the only record of an occurrence. Record the underlying Experience and History event first.

## Component ownership and contracts

### Memory Control

**Input:** a Current Experience and optional current context.

**Must:**

1. Record the incoming Experience without claiming that its interpretation is final.
2. Extract referenced or candidate Entities, State claims, Relationship claims, and retrieval needs.
3. Detect whether a claim concerns a new item, an apparent change, a possible Relationship, or only an observation.
4. Route every claim to its owning component and record the routing result.

**Output:** a set of typed operation proposals, each linked to its source Experience; unresolved items remain observations or candidates.

**Must not:** establish identities, commit State, establish Relationships, or activate context directly.

### Entity

**Input:** an identity proposal with source evidence.

**Must:** search for compatible existing Entities before creating a new Entity. If one unambiguous match exists, reference it. If none exists, create a new Entity. If more than one plausible match exists, retain an unresolved identity candidate; do not merge or select silently.

**Output:** an Entity reference or an unresolved identity result.

**Must not:** mutate past identity assertions or merge Entities without a governed identity-resolution operation.

### State

**Input:** an Entity reference and an asserted current condition.

**Must:** create a proposed State snapshot linked to the source Experience. Compare it to the currently effective State for the same scope. If accepted, preserve the prior State as historical and record a transition event.

**Output:** a proposed, accepted, rejected, or unresolved State result.

**Must not:** delete or overwrite a previous State snapshot to represent a change.

### Relationship

**Input:** subject, predicate, object, evidence, and any temporal claim.

**Must:** represent each Relationship independently from either Entity’s State; retain its origin and evidence; submit its status to Memory Governance.

**Output:** a Relationship in `POSSIBLE`, `CANDIDATE`, `SUPPORTED`, `ESTABLISHED`, `ACTIVE`, `DORMANT`, or `HISTORICAL` status, or an unresolved proposal.

**Must not:** infer `ESTABLISHED` or `ACTIVE` solely because a Relationship is plausible or retrieved.

### Event relationship handling

**Input:** two or more Events or event-derived records, a typed predicate, source/evidence, scope, and temporal claims where known.

**Must:** retain each typed Event relation as an independent, multi-valued record; permit one Event to have several relations to different targets and, when warranted, several different typed relations to the same target; preserve relation provenance and status.

**Output:** a governed Event relation or an unresolved/contested relation assertion. Follow [Event relationship semantics and chains](11-event-relationship-semantics-and-chains.md).

**Must not:** replace a typed relation with generic `related_to`, infer causality from temporal order, infer a state transition from association, or alter earlier Events when a later Event changes their interpretation or effects.

### History

**Input:** accepted records, rejected proposals, and relevant operation outcomes.

**Must:** append an immutable event for each material occurrence and decision; preserve origin and known sequence; record corrections as new events that supersede or qualify an earlier assertion.

**Output:** ordered or partially ordered historical record. When order is unknown, retain that uncertainty rather than manufacture sequence.

**Must not:** change the content of an earlier event to make the current interpretation easier to read.

### Memory Governance

**Input:** a proposal with source, evidence, identity resolution, applicable policy, and current status.

**Must:** decide only one of `accept`, `reject`, `defer`, or `request resolution`; record the reason and resulting status. It governs commitment, status, temporal condition, and boundary compliance.

**Output:** a governed outcome and any required follow-up operation.

**Must not:** generate claims, evidence, or Relationships. It evaluates them.

### Historical Integration

**Input:** History/Experience items and a candidate interpretive connection.

**Must:** create an Integration assertion rather than altering the underlying History. Route any newly inferred Relationship through Memory Governance.

**Output:** an accepted, deferred, or rejected Integration assertion; optional Relationship proposal.

**Must not:** alter the factual occurrence, origin, or sequence recorded in History.

### Novelty and ontology handling

**Input:** a valid observation that does not fit a defined Entity, State, Relationship, Event, or predicate model without loss or distortion.

**Must:** preserve the observation and its provenance; classify it as `NOVEL` or `INSUFFICIENTLY_MODELED`; state which existing categories/predicates fail and why; create an Ontology extension proposal when it may recur or materially affects interpretation/operation.

**Output:** a qualified observation, optional temporary project-defined extension, or governed proposal for a new concept/predicate/contract.

**Must not:** force the observation into the nearest existing category merely to complete processing, silently redefine existing terms, or make a proposed concept active without review.

### Capability emergence and Skill lineage

**Input:** Pattern assertions, candidate capabilities, operational outcomes, and linked History/Experience evidence.

**Must:** distinguish a recurring pattern from a reusable capability; preserve implicit capabilities when externalization is not justified; externalize a capability as an explicit Skill only when it is understood, reproducible, useful, and expressible within known boundaries; retain selective, typed lineage to material supporting, limiting, contradictory, and operational evidence.

**Output:** an implicit capability, candidate capability, explicit Skill proposal/version, revised Skill version, split/merge proposal, retirement proposal, or deferred outcome. Follow [Capability emergence and Skill lineage](14-capability-emergence-and-skill-lineage.md).

**Must not:** convert recurrence alone into a Skill, require every capability to become explicit, detach an explicit Skill from material lineage, or retroactively rewrite prior Skill versions or their source History.

### Living Memory and Relevance

**Input:** current State, governed Relationships, History, Integration assertions, and Direction / Intent.

**Must:** construct a current context as explicit Context memberships. Each membership must state why it is relevant and whether it is `ACTIVE` or `DORMANT`.

**Output:** a bounded present-facing context. Items outside it remain remembered, not deleted.

**Must not:** upgrade a possible or established Relationship to `ACTIVE` merely by including it in a retrieval result.

### Attention Control

**Input:** governed records, current context, Attention allocations, triggers, Direction / Intent, and focus budget.

**Must:** distinguish availability, `ACTIVE` context membership, and focused attention; allocate attention only through the policy in [Attention and activation policy](10-attention-and-activation-policy.md); record priority, trigger, and release/review condition.

**Output:** an attention state of `NOT_ATTENDING`, `MONITOR`, `QUEUED`, `FOCUSED`, or `URGENT` for a defined target and scope.

**Must not:** promote retention level, establish truth, resolve a conflict, or make a Relationship active merely because it receives attention.

### Direction / Intent

**Input:** a scoped direction assertion with source and effective time.

**Must:** retain direction separately from State and History; make it available as an input to Relevance; record a new Direction / Intent record when it changes.

**Must not:** erase or reinterpret historical facts to fit Direction.

## Skill operation contracts

| Skill | Required behavior |
|---|---|
| Retrieve | Return records with their type, status, origin, and why they are relevant; distinguish current from historical, dormant, and possible. |
| Update | Propose a State or Relationship change; never write directly to the current projection. |
| Relate | Create a candidate Relationship or evaluate one; retain evidence and route its status through Governance. |
| Organize | Change structure, grouping, indexing, or context membership without changing historical occurrence claims. |
| Compare | Compare declared State snapshots, Experiences, or Relationships; report scope and unavailable information. |
| Reconstruct | Rebuild a bounded context from History and current Relevance; identify omitted and uncertain material. |
| Integrate | Create an Integration assertion and governed Relationship proposal; do not modify History. |
| Transition | Record an accepted movement from prior State/Relationship condition to a new one, with source and effective time. |
