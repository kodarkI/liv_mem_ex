# Capability emergence and Skill lineage

## Governing principle

**A Skill is a governed, reusable capability for producing, evaluating, transforming, interpreting, deciding, communicating, or organizing within a declared scope.** It may be a procedure, reasoning strategy, heuristic, transformation, interpretation method, decision framework, communication pattern, workflow, or learned technique.

Do not define a Skill only as a sequence of steps. Do not make every memory, pattern, or capability into an explicit Skill.

```text
Experience / History
  → Pattern assertion
  → Candidate capability
  → implicit capability or explicit Skill
  → operation evidence
  → revision / split / merge / retirement / confirmation
```

## Distinguish the levels

| Level | Meaning | Required handling |
|---|---|---|
| Memory | Evidence about a specific situation: what happened, was asserted, changed, or related. | Preserve provenance, scope, and History. Do not require reuse. |
| Pattern assertion | An observed regularity across one or more memories. | Retain counterexamples and uncertainty. Recurrence alone does not establish usefulness or capability. |
| Candidate capability | A proposed reusable way to act, interpret, decide, transform, communicate, or organize. | State intended outcome, scope, boundaries, evidence, and what would validate or reject it. |
| Implicit capability | A context-bound capability retained in Living Memory but not externalized as a reusable artifact. | Use only with relevant context and evidence; monitor rather than advertise as a general Skill. |
| Explicit Skill | A governed, inspectable, versioned reusable capability that can operate beyond the original memories. | Retain selective lineage, declared scope, boundaries, and outcome evidence. |

The invariant is: **memory is evidence about a situation; a Skill is a reusable way to operate across a class of situations without requiring the original situation to recur.**

## Externalization test

Externalize a Candidate capability as a Skill only when all four conditions are sufficiently supported:

```text
understood + reproducible + useful + expressible
```

| Condition | Required evidence |
|---|---|
| Understood | State intended outcome, scope, mechanism/strategy, known boundaries, and meaningful failure or non-applicability conditions. |
| Reproducible | Show a stable application method or decision rule across relevant cases, or show a rare/high-impact case with a sufficiently clear and testable method. |
| Useful | Show a beneficial result, required protection, or meaningful improvement over not applying it. |
| Expressible | Represent it independently of its source memories so it can be invoked, inspected, validated, and revised. |

Recurrence is one signal of reproducibility and usefulness. It is neither necessary nor sufficient. A rare, high-impact capability may qualify; a frequently observed failure pattern may remain only a Pattern assertion.

Keep a capability implicit or defer it when it is narrow, uncertain, one-off, highly context-dependent, harmful outside its source context, or lacks an expressible boundary.

## Skill lineage

Preserve lineage selectively. Attach only memories and observations that materially motivate, demonstrate, limit, contradict, refine, or evaluate a capability/Skill. Do not attach every memory to a Skill.

| Lineage relation | Meaning |
|---|---|
| `MOTIVATED_BY` | An Experience/History item exposed the need for the capability. |
| `DEMONSTRATED_BY` | Evidence showed beneficial application. |
| `DELIMITED_BY` | Evidence revealed a boundary, exception, or non-applicability condition. |
| `CONTRADICTED_BY` | Evidence challenges an assumption, rule, or expected outcome. |
| `REFINED_BY` | Later operational evidence led to a successor version. |
| `SPLIT_FROM` / `MERGED_FROM` | Structural lineage between Skills/capabilities. |
| `RETIRED_BY` | Evidence or changed Direction/context made continued normal use inappropriate. |

Use lineage to assess trust, weakening, revision, split, merge, or retirement. Lineage is evidence, not an automatic truth score.

## Capability and Skill lifecycle

```text
PATTERN ASSERTION
  → CANDIDATE CAPABILITY
  → DEFERRED / IMPLICIT / EXPLICIT SKILL
  → CONFIRMED / REVISED / SPLIT / MERGED / RETIRED
```

1. Create a Pattern assertion from linked evidence; record scope and counterexamples.
2. Propose a Candidate capability only if a potential reusable operation can be stated.
3. Apply the externalization test.
4. If insufficient, defer or retain as implicit capability with a review trigger; do not force artifact creation.
5. If sufficient, create an explicit Skill version and its material lineage.
6. Link operational outcomes back to the Skill and evaluate whether its outcome, scope, and boundaries remain supported.
7. Create a successor Skill version for revision; retain prior versions and their lineage.

## Skill reuse

Treat reuse as a governed applicability decision, not automatic invocation because a Skill exists or shares a keyword with the current Experience.

```text
Current Experience + Living Memory + Direction
  → retrieve candidate Skills
  → test applicability
  → apply selected Skill or do not apply
  → execution / outcome evidence
  → candidate Experience only if material
  → retention decision
  → lineage evidence only if retained or otherwise required by policy
```

Reuse a Skill only when all of the following hold:

1. Its declared purpose can contribute to the requested or current outcome.
2. The current Entity, State, Relationship, and scope fit its declared applicability conditions.
3. No stated boundary, exception, retirement condition, or contradictory lineage makes use unsafe or misleading.
4. The expected benefit justifies attention and any side effect under the current Direction and focus budget.
5. The Skill version is active for the current policy/context, or an explicit historical/retest use is authorized.

If these conditions do not hold, retain the candidate Skill as irrelevant, inapplicable, deferred, or needing review. Do not force reuse merely because a Skill is available.

When applying a Skill:

1. Record a Skill invocation/execution with selected version, purpose, scope, inputs, applicability reason, and outcome evidence. This is an operational record, not automatically History or Living Memory.
2. Apply the capability through Memory Control and Memory Governance; a Skill does not bypass truth, lifecycle, attention, or boundary rules.
3. Evaluate execution/outcome evidence for materiality. Skill use itself is not automatically Experience.
4. Create a Candidate Experience only when the outcome is meaningful under the criteria below; otherwise release the operational record according to audit/observability policy without adding it to Living Memory.
5. Route a Candidate Experience through the normal validation and retention decision. Only a retained outcome becomes Living Memory and material lineage evidence.
6. Link retained or policy-required outcomes to the Skill using `DEMONSTRATED_BY`, `DELIMITED_BY`, `CONTRADICTED_BY`, or `REFINED_BY` as appropriate.
7. Release attention when the application’s purpose is met; do not keep the Skill active merely because it was invoked.

### Outcome-to-Experience gate

Create a Candidate Experience from Skill use when at least one condition applies:

- the outcome materially changes an Entity, State, Relationship, Direction, boundary, or committed decision;
- the outcome is unexpected, fails, produces an exception, or reveals a meaningful limitation;
- the application reveals a new technique, interpretation, capability, or ontology gap;
- the outcome provides independent or material evidence relevant to an existing claim, Skill, or candidate capability;
- a user, policy, audit, or external obligation requires retention; or
- repeated outcomes are being intentionally aggregated to evaluate a Skill or Candidate capability.

Do not create a Candidate Experience solely because a routine Skill invocation succeeded as expected and produced no material change, discovery, exception, or required evidence. A project may retain aggregated operational metrics separately; aggregated metrics do not become Living Memory unless they pass the same materiality and retention rules.

An explicit Skill is reusable beyond its original memories. Its lineage is retrieved only when needed for applicability, explanation, trust, audit, or refinement; invoking a Skill does not reactivate all source memories.

## Structural evolution

| Change | Use when | Required result |
|---|---|---|
| Revise | The purpose remains stable but evidence changes a method, boundary, judgment, or condition. | Create successor version with `REFINED_BY` evidence. |
| Split | One Skill contains materially distinct scopes, mechanisms, or outcomes that repeatedly need separate application. | Create two or more Skills with `SPLIT_FROM` lineage; preserve the original. |
| Merge | Separate Skills have a materially shared purpose, mechanism, and boundary that makes separate invocation misleading or duplicative. | Create successor Skill with `MERGED_FROM` lineage. |
| Retire | The Skill is obsolete, persistently harmful/ineffective, or no longer relevant to current Direction. | Stop ordinary invocation; retain historical version and `RETIRED_BY` evidence. |
| Reactivate | New evidence or Direction makes a retired/implicit capability relevant again. | Re-evaluate under current rules; do not restore it automatically. |

## Guardrails

- Do not create a Skill merely because a pattern recurs.
- Do not discard a rare but high-impact Candidate capability solely because recurrence is absent.
- Do not claim general reuse from one context without stated scope and testable boundaries.
- Do not let one successful use establish durable trust without considering limits, independent evidence, and counterexamples.
- Do not create a new Skill when a bounded revision of an existing Skill is sufficient.
- Do not revise, split, merge, or retire a Skill without preserving prior versions and selective lineage.
- Do not let Skills become detached doctrine: absence, contradiction, or changed context in lineage must remain visible.
