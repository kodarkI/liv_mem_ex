# Selective capability discovery and outcome attribution

## Capability discovery is attention-governed

Do not continuously analyze all Living Memory for patterns or potential Skills. Begin discovery only through a **Capability discovery inquiry**: a bounded, attention-governed examination of whether specific evidence suggests a Candidate capability.

Use the existing attention states. An inquiry may be `NOT_ATTENDING`, `MONITOR`, `QUEUED`, `FOCUSED`, or `URGENT`; capability discovery is normally `MONITOR`, `QUEUED`, or `FOCUSED`. Do not make it `URGENT` solely because a new pattern looks promising.

## Discovery signals

The following signals make an inquiry permissible; none is a mandatory threshold or an automatic Skill-creation trigger:

- repeated related Experiences or Event/State/Relationship structures;
- repeated successful approaches with a potentially shared method;
- recurring problem-solving structure or repeated reconstruction need;
- an unusually strong, high-impact, or protective outcome;
- repeated failure revealing that a method is missing or a current Skill has a boundary gap;
- an explicit user request to identify or externalize a capability;
- a current Skill becoming plausibly applicable to a new domain;
- accumulated supporting, limiting, or contradictory evidence reaching a meaningful governed state; or
- a material audit finding or recurring weakness.

A signal permits re-evaluation. Apply the attention policy before allocating focus. If no signal affects current Direction, an unresolved decision, a material risk, or a requested outcome, do nothing.

## Bounded discovery procedure

1. Record the triggering signal and the question: what reusable capability, if any, is being investigated?
2. Declare a scope before inspecting memory: current Entities/State/Direction; directly linked Events and Relationships; comparable prior applications/outcomes; and counterexamples or limiting evidence.
3. Traverse only relevant typed Relations and History chains. Do not scan unrelated dormant memory or expand traversal merely because a possible connection is interesting.
4. Produce one of: no capability found; Pattern assertion; Candidate capability; refinement/split/merge question for an existing Skill; or `INSUFFICIENTLY_MODELED` observation.
5. Apply the `understood + reproducible + useful + expressible` test only after a Candidate capability is identified.
6. Record why the inquiry was released, queued, deferred, or retained for review.

## Defer and revisit

Defer an inquiry when evidence is insufficient, the pattern is too context-bound, a higher-priority matter consumes focus, a counterexample needs resolution, or the question cannot be expressed without ontology distortion.

A deferred inquiry must retain its trigger, bounded scope, unanswered question, known evidence/counterexamples, and a reopening condition. Reopen only on new relevant evidence, repeated occurrence, a material outcome, Direction change, explicit request, scheduled review obligation, or resolution of a stated blocker. Do not repeatedly reopen it merely because it remains unresolved.

## Outcome attribution

An unfavorable or favorable outcome is evidence about a situation. It is not automatically evidence that the Skill caused the outcome or should be revised.

Create an **Outcome attribution assertion** before treating an outcome as `DEMONSTRATED_BY`, `DELIMITED_BY`, `CONTRADICTED_BY`, or `REFINED_BY` Skill lineage.

Inspect, within the bounded application scope:

- the Skill’s declared purpose, scope, boundaries, and selected version;
- supplied inputs and missing/ambiguous evidence;
- the current Entity, State, Relationships, Direction, and attention conditions;
- observable environmental conditions or changes;
- other simultaneously applied Skills or material interventions; and
- alternative explanations and uncertainty.

Use one or more provisional conclusions; preserve uncertainty rather than force a single cause:

| Attribution conclusion | Meaning | Skill-evolution implication |
|---|---|---|
| `CONSISTENT_WITH_SKILL` | Outcome matches the expected result in an in-scope context. | May provide supporting evidence; does not prove causation or require evolution. |
| `OUT_OF_SCOPE` | Inputs/context violated a stated boundary or applicability condition. | May delimit the Skill or improve applicability checks; do not treat as a failure of the core Skill. |
| `INSUFFICIENT_EVIDENCE` | Required inputs/evidence were missing, incomplete, or too uncertain. | Improve input/retrieval or defer judgment; do not revise the Skill’s method from this outcome alone. |
| `ENVIRONMENTAL_CHANGE` | A relevant external condition changed the result. | Record context/environment evidence; re-evaluate applicability or scope, not the Skill’s core rule by default. |
| `JOINT_CONTRIBUTION` | Outcome plausibly resulted from the Skill together with another Skill/intervention. | Preserve the contribution uncertainty; do not grant sole credit or blame. |
| `AMBIGUOUS` | Available evidence cannot distinguish alternatives. | Retain/monitor or request resolution; do not revise. |
| `CONTRADICTS_EXPECTATION` | An in-scope, sufficiently evidenced outcome conflicts with the Skill’s stated expected result. | Create a governed revision/weakening inquiry; one case does not automatically revise the Skill. |

The conclusion itself is an assertion with evidence and status. It may later be qualified or superseded without rewriting the original outcome.

## Adversarial outcome rules

- A successful in-scope result supports a Skill only as evidence consistent with it; it does not prove sole causality or create automatic trust.
- An out-of-scope failure tests applicability/boundaries first, not the core method.
- Environmental change must remain separate from claimed Skill behavior unless evidence supports a connection.
- When multiple Skills are used, attribute a joint or ambiguous contribution unless the evidence distinguishes their effects.
- An ambiguous outcome remains unresolved rather than becoming a negative Skill judgment.
- A single apparent failure followed by repeated in-scope success remains a qualified exception or attribution question unless evidence shows a stable boundary or defect.
- Do not revise a Skill merely because an outcome was unfavorable. Determine what the outcome actually tells the system about the Skill.
