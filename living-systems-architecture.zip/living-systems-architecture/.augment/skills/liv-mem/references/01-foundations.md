# Foundations

## Core idea

A living system is not simply a system that stores information. It can recognize what continues to exist; preserve where experiences came from; maintain Relationships; distinguish past States from current States; allow States and Relationships to change; integrate relevant past experiences into the present; distinguish possibilities from established Relationships; keep some History dormant without losing it; form a coherent current context; and carry that context forward into the Next State.

**Living memory is continuity through change.** It neither freezes the past nor abandons the past. The past remains part of the system while the present is allowed to become different.

## Central distinction

| Question | Architecture term |
|---|---|
| What happened? | History |
| What is true now? | State |
| What is connected to what? | Relationship |
| What is this continuing toward? | Direction |

Living Memory integrates all four.

```text
HISTORY
  ↓
RELATIONSHIP → PRESENT STATE ← DIRECTION
  ↓
NEXT STATE
  ↓
HISTORY
```

## Foundational principles

1. Preserve origin.
2. Preserve sequence.
3. Preserve Relationships.
4. Separate History from State.
5. Allow transformation.
6. Separate possibility from commitment.
7. Separate remembered from active.
8. Permit retrospective integration.
9. Do not rewrite History.
10. Maintain Direction.
11. Let Skills operate on memory.
12. Preserve coherence through change.

## What Living Memory is not

Do not reduce Living Memory to storing everything, tracking everything continuously, updating everything whenever something happens, generating every possible Relationship, freezing the past forever, or erasing the past whenever State changes.

Preserve meaningful continuity while allowing the system to change.
