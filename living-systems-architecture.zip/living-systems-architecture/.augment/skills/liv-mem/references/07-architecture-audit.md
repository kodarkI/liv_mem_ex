# Architecture audit

## Scope

This audit applies the Living Systems Architecture to its own skill definition. It records the gap between the initial conceptual architecture and this operational revision.

## Component audit

| Component | Previously defined | Previously missing | Operating decision now defined |
|---|---|---|---|
| Current Experience | Incoming material enters the system. | Record contents and status before interpretation. | Create an immutable Experience record with source, times, and raw content/reference. |
| Memory Control | Perceives, identifies, interprets, detects, and routes. | Inputs, outputs, and authority limit. | Record, extract, classify, route, and propose; never commit identity, State, Relationship, or activation. |
| Memory Governance | Protects coherence and controls status. | Decision outcomes, reasons, and authority boundary. | Accept, reject, defer, or request resolution; record reason and outcome. |
| Entity | Supplies persistent identity. | Matching, ambiguity, and merge behavior. | Search first; create on no match; defer ambiguous matches; prohibit silent merge. |
| State | Represents what is true now; previous State becomes historical. | Snapshot form, update procedure, conflict behavior. | Use source-linked proposed snapshots and governed transitions; preserve prior snapshots. |
| Relationship | First-class structure with lifecycle concepts. | Required proposal fields and transition guards. | Require subject, predicate, object, and source; use guarded status progression. |
| History | Preserves origin, sequence, events, prior State, and changes. | Immutability procedure, correction method, ordering uncertainty. | Append immutable events; represent corrections as new qualifying/superseding events; retain unknown order. |
| Historical Integration | Connects/reinterprets History without rewriting it. | Artifact and commit behavior. | Create Integration assertions and governed Relationship proposals. |
| Living Memory / Relevance | Coherent present context and active/dormant distinction. | Context membership, activation guard, no-direction behavior. | Use explicit Context memberships with relevance reasons; record unavailable Direction. |
| Direction / Intent | Orientation and relevance input. | Separate record and change behavior. | Use scoped, time-bound Direction / Intent records; changes trigger relevance evaluation only. |
| Skills | Named operations through Control/Governance. | Low-level contracts and prohibited shortcuts. | Define required behavior for each Skill and prohibit direct projection mutation. |
| Memory lifecycle | Continuity through change; prior State becomes historical. | Lifecycle stages, archival/pruning, and action when memory is no longer current truth. | Define create → validate → use → update → supersede → archive → prune, with successor links and tombstones. |
| Truth resolution | History, State, and Relationship are distinct; conflicts should not be silently guessed. | Truth categories, conflict procedure, and newer-versus-older rule. | Define scoped truth categories and require policy-based decisions or CONTESTED outcome; newer is not automatically truer. |
| Promotion / retention | Active and dormant are distinct. | Durable-memory threshold, retention levels, and reviews. | Define EPHEMERAL, RETAINED, DURABLE, and ARCHIVED with governed reasons and review decisions. |
| Self-Auditing | Failure handling covered single operational failure. | Degradation detection, integrity checks, and pre-failure inspection. | Define audit invariants, findings, repair-proposal limits, and periodic/event-triggered execution. |
| Skill evolution | Skills operate on memory. | How Skills improve from operational evidence without arbitrary self-change. | Define observation → weakness → proposal → review → versioned deployment → outcome audit. |
| Attention / activation | Relevance could make material ACTIVE, and a context limit could demote material to DORMANT. | Priority, trigger, release, focus capacity, and reopening semantics; activation was too close to attention. | Separate availability, activation, and attention; define priority, attention states, restricted budget, release conditions, and trigger-based reopening. |
| Event-to-event semantics | Events, History, generic Relationships, evidence, and State transitions existed as concepts. | Typed Event predicates, multiple simultaneous links, causal versus temporal distinction, and reconstructable multi-event chains. | Define first-class Event relations with temporal, causal, dependency, consequence, evidence, contradiction, continuation, supersession, reactivation, recurrence, contextual, and State-transition semantics. |
| Challenge-driven evolution | Audit and Skill Evolution used operational evidence in general. | Concrete adversarial tests for emerging meaning, indirect inference, false significance, multi-meaning Events, and novelty. | Define challenge suite, failure signals, PASS/PARTIAL/FAIL/OPEN outcomes, and route findings into versioned refinement. |
| Assumption attack / regression | Challenge tests existed but did not cover deceptive provenance, arrival order, missing chain links, deliberate inaction, decaying urgency, or competing focus. | Permanent hostile-case catalog, explicit attacked assumptions, and replay requirement after change. | Define 14 adversarial Regression cases, order/provenance safeguards, failure-to-assumption mapping, and release-blocking replay rules. |

## Resolved ambiguities

- The original status sequence is now a lifecycle with entry guards and permitted next statuses.
- “Do not rewrite History” now means preserving occurrence records and expressing corrections or interpretations as new records/events.
- “Dormant” now means retained outside the current context; it does not mean forgotten or deleted.
- Active context membership now requires a recorded relevance reason and cannot establish a Relationship.
- A State change now requires a proposal, governed decision, retained predecessor, and transition History event.

## Deliberately unresolved

The baseline does not choose a physical database, an automatic identity-matching or relevance algorithm, specific evidence thresholds, a temporal model, permission policies, or transaction technology. See [Open design questions](06-open-design-questions.md) before implementing any of these.
