# Core layers

## Current Experience / Conversation

Treat Current Experience as what enters the system now: a conversation, observation, event, new piece of information, change in an existing situation, new Relationship, or interaction with something already known. Do not immediately treat every incoming element as permanent memory.

## Memory Control

Use Memory Control as the first point of contact. It perceives, identifies, interprets, detects changes, detects Relationships, and routes operations. It asks what Entities are involved; whether something is new; whether a State or Relationship changed; whether existing History matters; whether something should be retrieved, updated, or remain only as an observation.

Memory Control turns raw experience into memory operations.

## Memory Governance

Use Memory Governance to protect the coherence of Living Memory. It determines identity, relevance, Relationship status, temporal status, activation, commitment, and boundaries.

```text
POSSIBLE → CANDIDATE → SUPPORTED → ESTABLISHED → ACTIVE / DORMANT / HISTORICAL
```

Preserve these rules:

- A possibility is not automatically a Relationship.
- A Relationship is not automatically an active context.

## Entity

Use Entity to answer: **What is this thing?** An Entity may be a person, project, concept, object, place, document, conversation, process, event, or another persistent subject.

The important property is continuity of identity: recognize `X` at time 1, time 2, and time 3 as continuing `X`, even though its State changes.

## State

Use State to answer: **What is true about this Entity now?** State is the current configuration, not the whole History. When State changes, retain the old State as historical.

## Relationship

Treat Relationships as first-class memory structures. A system may retain connections such as `related_to`, `depends_on`, `changed`, `originated_from`, and `influenced`. Relationships may connect Entities, Events, State snapshots, claims, interpretations, or other Relationship records. When an Event connects to another Event, use the typed semantics in [Event relationship semantics and chains](11-event-relationship-semantics-and-chains.md), not a generic `related_to` relation.

A Relationship can have origin, History, State, strength/status, temporal validity, and changes.

## History

Use History to preserve origin, sequence, events, previous States, Relationship changes, and important transitions. It answers: **Where did this come from?** and **What happened along the way?**

Do not confuse History with current State. A previous State can remain historically true without remaining currently true.

## Historical Integration

Use Historical Integration to connect experiences, discover Relationships, compare previous States, recognize recurring patterns, and reinterpret context. A new experience can make an older experience relevant.

Keep History intact while allowing its Relationships and contextual interpretation to evolve.

## Living Memory

Treat Living Memory as the coherent present-facing structure produced from:

```text
IDENTITY + STATE + RELATIONSHIPS + HISTORY + RELEVANT INTEGRATION + DIRECTION
```

Maintain these temporal conditions simultaneously:

- **ACTIVE**: current State, current Relationships, and relevant History.
- **DORMANT**: remembered but not currently active.
- **HISTORICAL**: previous States and Relationships.
- **POSSIBLE**: candidate Relationships not yet established.

Do not treat dormant memory as forgotten. Allow it to become active when a new Relationship makes it relevant.
