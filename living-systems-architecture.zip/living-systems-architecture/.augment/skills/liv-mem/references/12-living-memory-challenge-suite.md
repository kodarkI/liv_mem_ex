# Living-memory challenge suite

## Purpose

Use these adversarial scenarios to test whether the system is Living Memory rather than sophisticated storage. A scenario passes only when its required outcomes are preserved; storing all inputs is not enough.

Run this suite after material rule changes and when operational evidence suggests weakness. Record each run, inputs, expected outcome, actual outcome, governing Skill versions, and Audit finding or refinement proposal when it fails.

## Challenge 1: meaning emerging later

### Scenario

- Event A occurs and appears insignificant. Retain it as EPHEMERAL or RETAINED; it is not active or attended.
- Much later, Event B occurs and provides a specific, governed basis for A to explain current State, an active Relationship, a Direction, or an unresolved decision.

### Required outcome

1. Preserve Event A’s original occurrence, original status, and prior lack of attention.
2. Record `B → REACTIVATES_RELEVANCE_OF → A`, with its source and relevance reason.
3. Re-evaluate A under current context; activate or allocate attention only if the attention policy warrants it.
4. Do not rewrite A as if it had always been significant, effective, or known to have the later meaning.
5. If B only makes a speculative connection, keep the connection asserted/candidate and do not force activation.

### Failure signals

- A’s original record is edited to include B’s later meaning.
- B automatically makes A DURABLE, ACTIVE, FOCUSED, or causally related without a governed reason.
- A stays permanently ignored despite B satisfying a qualified reactivation trigger.

## Challenge 2: indirect relationships

### Scenario

Provide a typed chain `A → B → C → D`, with each link’s predicate, evidence, and status declared. Ask: **What does D imply about A?**

### Required outcome

1. Reconstruct only the relevant bounded chain and show every predicate and status.
2. Separate direct facts about A and D from a Derived inference that follows the chain.
3. State only what the path permits. Example: a fully supported causal chain may support “A is an indirect causal ancestor of D”; an `OCCURS_BEFORE` chain supports sequence only.
4. Preserve gaps, contested links, alternate branches, and omitted paths.
5. Do not turn a derived implication into direct evidence, a current State, or an established causal relation without Governance.

### Failure signals

- “D implies A” is answered without a labeled traversal path.
- Temporal order becomes causal explanation.
- A missing or contested link is silently treated as confirmed.

## Challenge 3: false significance

### Scenario

Provide many Events that are temporally close, semantically similar, or frequently mentioned but have no declared causal, evidential, dependency, State-transition, or named contextual basis.

### Required outcome

1. Preserve the Events separately with their times and provenance.
2. Do not create `CAUSES`, `RESULTS_FROM`, `PROVIDES_EVIDENCE_FOR`, `RECURS_FROM`, or State-transition relations from proximity, similarity, or frequency alone.
3. If a shared context is explicitly known, record only `CONTEXTUALLY_ASSOCIATED_WITH` with that context named; otherwise retain incomplete observations.
4. Do not spend FOCUSED attention merely because a cluster looks interesting.
5. Record candidate hypotheses separately from established structure and require evidence/governance before promotion.

### Failure signals

- Generic association is silently upgraded into a stronger relation.
- Repetition is treated as recurrence without declared recurrence criteria.
- The system exhausts focus budget exploring every possible connection.

## Challenge 4: one Event, multiple meanings

### Scenario

Provide Event X that is simultaneously evidence for claim P, a consequence of Event Q, an initiator of State transition S1 → S2, historically durable, and currently irrelevant.

### Required outcome

1. Retain independent records: `X → PROVIDES_EVIDENCE_FOR → P`, `X → RESULTS_FROM → Q`, and `X → INITIATES_TRANSITION → S1 → S2`.
2. Store X’s retention level, truth/status of each relation, State effect, temporal condition, and attention state independently.
3. Permit X to be DURABLE and HISTORICAL/DORMANT while `NOT_ATTENDING`; no label overwrites another.
4. Require the normal State transition protocol before S2 becomes EFFECTIVE.

### Failure signals

- A single label replaces the distinct evidential, causal, transition, retention, temporal, and attention properties.
- Historical importance automatically makes X active or focused.
- A transition relation automatically makes the target State effective.

## Challenge 5: novelty

### Scenario

Provide a valid Event or observation that cannot fit the existing Entity, State, Relationship, Event, or predicate ontology without distorting its meaning.

### Required outcome

1. Preserve the observation, source, and History record.
2. Mark it `NOVEL` or `INSUFFICIENTLY_MODELED`; identify precisely why available categories do not fit.
3. Keep it qualified and available for retrieval; do not make it current truth, a forced classification, or an established relation.
4. Create an Ontology extension proposal if it recurs or materially affects operation, interpretation, or a governed decision.
5. Review the proposal through Skill Evolution; a new category/predicate becomes active only in a versioned, governed update.

### Failure signals

- The observation is forced into the nearest known category without qualification.
- A new concept is silently created and used as a settled rule.
- The novel observation is discarded because it cannot yet be classified.

## Evaluating and evolving from challenges

For each challenge, assign one outcome:

| Outcome | Meaning | Required next step |
|---|---|---|
| PASS | All required outcomes hold with traceable records. | Retain run as validation evidence. |
| PARTIAL | Core preservation holds but an expected contract or boundary is absent/ambiguous. | Create Audit finding and refinement candidate. |
| FAIL | The system rewrites History, invents structure, collapses distinctions, or bypasses Governance. | Create an Audit finding; block affected derived behavior where needed; enter Skill Evolution review. |
| OPEN | The result depends on an explicitly unresolved project extension point. | Record the missing decision; do not claim the system passed. |

Do not revise the Skill directly from one failed challenge. Treat the result as operational evidence and follow: observation → weakness candidate → refinement proposal → review → versioned deployment → outcome audit.
