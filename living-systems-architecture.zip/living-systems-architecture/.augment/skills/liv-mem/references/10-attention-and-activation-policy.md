# Attention and activation policy

## Purpose

Living Memory must retain broadly enough to preserve continuity while activating selectively and focusing intensely only when warranted. It must not continually reopen or reconsider everything it remembers.

Use this operating pattern:

```text
retain → activate selectively → focus when warranted → resolve/update → release attention → remain available for reactivation
```

## Separate three conditions

Do not conflate these conditions:

| Condition | Meaning | Does it consume scarce attention? |
|---|---|---|
| Availability | A record is retained and can be retrieved within its permitted access/retention rules. | No. |
| Activation | A record participates in current context as `ACTIVE`; otherwise it may be `DORMANT`. | No. |
| Attention | The system is deliberately monitoring, queuing, or focusing work on a target because a priority and trigger justify it. | Only `FOCUSED` and `URGENT` consume focus capacity. |

Therefore, a memory may be Durable and dormant, Ephemeral and urgently focused, Historical and active because it explains a current State, Contested and urgent, Validated but unattended, or Dormant and eligible for reactivation.

## Attention states

| State | Meaning | Permitted transition |
|---|---|---|
| NOT_ATTENDING | Retained or active material receives no deliberate monitoring or work. | MONITOR, QUEUED, FOCUSED, URGENT when a qualifying trigger occurs. |
| MONITOR | The system watches for a defined trigger or review time but does not investigate now. | NOT_ATTENDING, QUEUED, FOCUSED, URGENT. |
| QUEUED | Important but not now: the item merits work, but focus capacity or priority prevents immediate work. | NOT_ATTENDING, MONITOR, FOCUSED, URGENT. |
| FOCUSED | The item currently receives bounded investigative, update, or resolution work. | NOT_ATTENDING, MONITOR, QUEUED, URGENT. |
| URGENT | The item requires immediate resolution or protective action because delay threatens current truth, an active commitment, a boundary, or an explicitly declared critical Direction. | FOCUSED, MONITOR, NOT_ATTENDING after the urgent condition is addressed. |

An Attention allocation must name the target, scope, state, priority reason, triggering event, allocation time, and release or review condition.

## Attention priority

Assess priority after Governance and separately from promotion level, truth category, and Relationship status. Use the highest applicable priority; do not manufacture importance from novelty alone.

| Priority | Apply when | Required attention outcome |
|---|---|---|
| URGENT | A contested/effective claim affects current State or an active Relationship; a boundary/integrity violation affects current context; an explicit user request requires resolution now; or delay threatens an explicitly declared critical Direction. | Allocate `URGENT`, subject to the interruption rule. |
| HIGH | The item materially affects current State, an active Relationship, a committed Direction, an unresolved decision required for the Next State, or a repeated weakness. | Allocate `FOCUSED` if capacity exists; otherwise `QUEUED`. |
| NORMAL | The item explains current context, has a qualified trigger, or is a planned review. | Allocate `MONITOR` or `QUEUED`; focus only when capacity and Direction permit. |
| LOW | The item is old, unrelated to current scope/Direction, already resolved, or lacks a qualifying trigger. | Keep `NOT_ATTENDING` or `MONITOR` only. |

`DURABLE`, `EPHEMERAL`, `HISTORICAL`, `VALIDATED`, and `CONTESTED` are not attention priorities. They inform priority only through their effect on current State, Relationships, Direction, scope, evidence, or unresolved decisions.

## Activation and reopening triggers

Evaluate triggers event-by-event. A trigger makes re-evaluation permissible; it does not automatically allocate focus.

| Trigger | Required response |
|---|---|
| New evidence linked to the record | Re-evaluate truth/status and priority; focus only if it changes or may change current context or a governed decision. |
| Contradiction with an effective claim | Create a conflict record; allocate URGENT/HIGH only when the contested scope affects current State, active Relationship, or critical Direction. Otherwise queue or monitor. |
| State change | Re-evaluate memories linked by Entity, scope, origin, or governed Relationship; activate only those with an explicit relevance reason. |
| Relationship change | Re-evaluate connected History and context memberships; do not traverse indefinitely beyond project-defined depth/budget. |
| User explicitly revisits a matter | Activate and allocate at least NORMAL attention in the requested scope, subject to boundaries. |
| Direction / Intent change | Re-run relevance against the changed Direction; queue/focus only affected items. |
| Unresolved decision reaches its review point or blocks Next State | Raise to HIGH; focus if capacity exists. |
| Repeated occurrence or recurring audit weakness | Create or update a weakness record; allocate HIGH only after the recurrence rule is met. |
| Scheduled review/retention review | Monitor or queue according to policy; do not focus merely because a timer fired. |

## Focus budget and selection

Attention is restricted. Do not pursue every interesting connection simultaneously.

Each scope must declare a focus budget. Until a project supplies a different limit, use this baseline: **one `FOCUSED` allocation per scope and one interrupting `URGENT` allocation per scope.** All other eligible items remain `QUEUED` or `MONITOR`.

Select work in this order:

1. An unresolved URGENT item interrupts a FOCUSED item only when the urgent condition meets the stated definition.
2. Choose HIGH items that unblock the Next State, protect current truth, or affect an active Relationship before NORMAL items.
3. Within the same priority, choose the item most directly connected to current scope and Direction; if still tied, preserve queue order.
4. Keep all non-selected eligible items in QUEUED with their priority reason and next review/trigger.

Do not expand the focus budget because an item is interesting, newly related, or merely Durable. A project may define multiple scopes with separate budgets, but it must prevent the same target from consuming focus in incompatible scopes without a recorded coordination rule.

## Attention decay and release

Release attention when its recorded purpose is met. A memory does not remain attended merely because it was once important.

| Condition | Required action |
|---|---|
| Conflict is resolved, qualified, or deliberately deferred with a next review | Move from URGENT/FOCUSED to MONITOR, QUEUED, or NOT_ATTENDING; record the decision. |
| State/Relationship update is committed and no unresolved effect remains | Release to NOT_ATTENDING or MONITOR; retain normal activation only if still relevant. |
| Investigation produced no sufficient evidence | Release to NOT_ATTENDING or MONITOR with the negative result and reopening triggers. |
| User request or planned review is fulfilled | Release unless another independent trigger remains. |
| Focus time/budget expires without resolution | Move to QUEUED or MONITOR; record progress, blocker, and next review. |
| Active item loses relevance after context/Direction change | Remove from ACTIVE as appropriate and release attention; retain it as dormant or historical. |

Release is not deletion, demotion of truth, or loss of retention. It ends active work while preserving availability and stated reopening conditions.

## Reopening rules

Do not reopen a Dormant, Archived, Historical, or previously released matter solely because it exists, is old, or is connected by a speculative Relationship. Reopen only on a qualifying trigger listed above, an explicit request, or a project-defined review obligation.

When reopening, create a new Attention allocation linked to the previous release decision. Re-evaluate current scope, Direction, truth category, and evidence before restoring `ACTIVE`, `FOCUSED`, or `URGENT` status. A reopened item may remain available but `NOT_ATTENDING` if the trigger is insufficient.

## Attention safeguards

- Retrieval does not equal activation; activation does not equal focus.
- Attention does not make a claim truer, a Relationship established, or a memory durable.
- Batch events must be deduplicated into a single review/queue item when they concern the same target and issue.
- A speculative Relationship may suggest a review but cannot by itself trigger `URGENT` or establish focus.
- Self-Auditing may trigger review but cannot consume focus capacity without this policy’s priority test.
