# Open design questions and extension points

The operating contracts define baseline behavior, but the following choices remain intentionally undecided. Define them for each project before treating its system as production-ready.

## Open design questions

- What physical storage, schema, graph/event representation, indexes, and runtime architecture will implement the canonical records?
- What Entity types, identity evidence, match thresholds, merge authorities, and split procedures will apply?
- What State fields, scopes, granularity, effective-time rules, and conflict-resolution policy will apply?
- Which Relationship predicates, directionality rules, evidence criteria, strength model, and temporal-validity model will apply?
- What Governance policies, thresholds, authorities, review paths, and reversibility requirements will apply to each status transition?
- What Relevance algorithm, ranking, context-size limit, and automatic-versus-human activation policy will apply?
- What clock, ordering semantics, versioning model, and causal/temporal conflict rules will apply?
- Which History fields are immutable occurrences, which are corrigible metadata, and how are corrections represented?
- What methods may Historical Integration use to discover patterns or propose connections, and what evidence is adequate for each use?
- What form, scope, source, authority, and lifecycle will Direction / Intent have?
- What permissions, retention periods, deletion authorities, privacy, access boundaries, and legal/ethical constraints govern every record type?
- What exact source-authority, corroboration, and semantic-equivalence rules will the truth-resolution procedure use?
- What promotion thresholds, review intervals, archival tiers, and pruning criteria will apply to each memory type?
- What audit schedule, severity taxonomy, observation windows, repair authority, and recurring-weakness thresholds will apply?
- Who may approve, deploy, roll back, and migrate a Skill version, and what test environment validates it?
- What scope model, focus budgets, interruption policy, review intervals, and priority evidence will the attention policy use?
- Which additional Event predicates, causal-evidence criteria, semantic-equivalence rules, chain depth limits, and feedback-loop policies will the project require?
- What explicit novelty threshold, temporary-extension authority, ontology review cadence, and compatibility/migration policy will govern ontology extensions?
- What provenance-verification, source-dependency, semantic-duplicate, and final order-invariance rules will govern conflicting evidence?
- Which regression cases are mandatory per change type, and what release authority may accept an explicit regression tradeoff?
- What evidence thresholds, rarity/high-impact criteria, authority, review cadence, and trust/retirement policy will govern capability externalization and Skill lineage?
- What applicability ranking, compatibility rules, authority for historical Skill reuse, and outcome-measurement policy will govern Skill reuse?
- What discovery-signal evidence, inspection bounds, inquiry review cadence, and authority will govern capability discovery?
- What attribution evidence, environmental-observation model, multi-Skill contribution method, and revision threshold will govern interpretation of Skill outcomes?
- What Skill-interaction policy, precedence authority, composition safety rules, and comparison method will govern multiple applicable Skills?
- What Candidate-capability review cadence, stale/expiry policy, reopening authority, and ordinary-retrieval behavior will prevent candidate accumulation?
- What runtime observability, test harness, trace retention, and acceptance criteria will establish behavioral validation for each specified mechanism?
- What transaction, recovery, audit, and observability model will ensure the required multi-record operation behavior?

## Extension points

| Extension point | Project-specific definition required |
|---|---|
| Entity model | Types, identifiers, identity evidence, matching, merge/split rules, and lifecycle. |
| State model | Fields, scopes, ownership, versions, effective time, and conflict resolution. |
| Relationship model | Predicates, directionality, evidence, strength, validity, and transition criteria. |
| Governance policy | Evidence requirements, thresholds, authorities, boundaries, review, and reversibility. |
| History model | Event format, provenance, ordering, correction procedure, retention, and audit requirements. |
| Relevance model | Retrieval, ranking, activation, dormancy, context size, and reactivation rules. |
| Direction / Intent model | Source, representation, scope, authority, and update rules. |
| Skill contracts | Inputs, outputs, side effects, validation, authorization, and user-facing error behavior. |
| Next-State process | Proposal, validation, transaction, conflict resolution, commitment, and recovery. |
| Attention policy | Scope, focus budget, interruption, priority evidence, review schedule, release, and reopening rules. |
| Event relationship model | Predicate vocabulary, endpoint types, inverse/derivation rules, causal evidence, chain reconstruction, and cycle policy. |
| Ontology evolution | Novelty classification, extension proposal, approval authority, versioning, and migration policy. |
| Adversarial regression | Mandatory case selection, simulator/harness, pass criteria, replay triggers, and release authority. |
| Capability emergence and Skill lineage | Pattern detection, externalization evidence, implicit-capability handling, lineage scope, trust, revision, split/merge, and retirement policy. |
| Skill reuse | Retrieval, applicability, version selection, boundary checks, outcome capture, and feedback-to-lineage policy. |
| Capability discovery | Trigger signals, scoped inspection, deferral/reopening, and Candidate-capability proposal policy. |
| Outcome attribution | Context, evidence sufficiency, environmental change, joint contribution, uncertainty, and evolution thresholds. |
| Skill-set coordination | Complementarity, overlap, conflict, prerequisites, precedence, composition, and multi-Skill outcome attribution. |
| Candidate capability hygiene | Lifecycle, review, stale/expiry, rejection, reactivation, and evidence retention. |
| Runtime validation | Observability, traces, test harness, acceptance, and operational-evidence policy. |
