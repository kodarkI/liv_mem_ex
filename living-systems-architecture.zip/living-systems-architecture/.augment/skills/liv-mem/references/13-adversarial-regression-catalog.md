# Adversarial regression catalog

## Purpose

This catalog attacks hidden assumptions in the Living Systems Architecture. It is a permanent regression suite: retain every case, especially failures, with its original inputs and replay history. Do not rewrite a failed case after a fix; append the later result.

Use this loop:

```text
architecture → adversarial simulation → unexpected failure → identify assumption
→ refine Skill/model → replay → regression test
```

A case is not passed because the system stores the inputs. It passes only when it preserves the stated invariants without inventing structure, rewriting History, collapsing distinctions, or consuming unjustified attention.

## Replay protocol

1. Freeze the scenario inputs, declared policy/configuration, and expected invariants in a Regression case.
2. Run the same scenario under the target Skill and policy versions.
3. Record outputs, current truth, retained History, Event relations, context/attention allocations, and all derived inferences.
4. Compare the actual output against each invariant.
5. Classify `PASS`, `PARTIAL`, `FAIL`, or `OPEN`.
6. For PARTIAL/FAIL, identify the specific assumption that enabled the result. Create an Audit finding and follow Skill Evolution.
7. After a refinement, replay every case affected by the changed contract; preserve both old and new results.

## Permanent cases

| ID | Adversarial scenario | Required result | Assumption under attack |
|---|---|---|---|
| AR-01 | A routine Event has no current link, no review obligation, and no policy significance. | Retain or prune per policy, but allocate no activation or attention. The correct answer is **do nothing**. | Every stored Event must be interpreted, connected, or investigated. |
| AR-02 | A trivial Event A is later explained by Event B and becomes necessary to explain current State. | Record B’s reactivation relation; retain A’s original meaning/status; re-evaluate without rewriting A. | Initial importance determines permanent importance. |
| AR-03 | A seemingly critical Event triggers urgent review, then evidence shows it does not affect current scope or Direction. | Release attention; preserve the Event and investigation; do not keep it active/focused solely because it once seemed critical. | Early urgency implies lasting relevance. |
| AR-04 | Two Events are close in time and language but share no causal, evidential, dependency, or named context basis. | Preserve both; create no strong relation or attention work. | Similarity/proximity/repetition is structure. |
| AR-05 | Two Events appear unrelated, but supplied evidence gives a typed causal chain through known intermediate Events. | Preserve the chain and derive only path-labeled indirect inference; do not claim direct association unless separately evidenced. | Surface unrelatedness means no historical connection. |
| AR-06 | Feed conflicting claims in order A then B; replay with B then A, holding complete evidence/time/policy equal. | Final governed truth is identical; only receipt History/interim attention may differ. | Arrival order determines truth. |
| AR-07 | Repeat information with minor wording, formatting, or partial-detail variation. | Preserve each Experience; identify exact/policy-defined duplicates; do not multiply corroboration or State transitions; leave uncertain equivalence unresolved. | Repetition is independent confirmation or safely mergeable. |
| AR-08 | Give a causal chain with intermediate Events deliberately removed. | Show a gap and retain only supported direct relations. Do not invent the missing Events, causal bridge, or State transition. | Chains are complete and gaps may be guessed. |
| AR-09 | Submit an incorrect claim with complete-looking identifiers, timestamps, signatures, or source metadata. | Validate form separately from authenticity/correctness; retain but do not make EFFECTIVE without policy-supported authority/corroboration. | Strong-looking metadata proves truth. |
| AR-10 | Submit a correct claim with weak provenance and later independent confirmation. | Initially retain as ASSERTED/VALIDATED as warranted; do not discard as false. Update support/effectiveness only through governed corroboration. | Weak provenance makes a claim false or unusable forever. |
| AR-11 | An old historical Event becomes necessary to explain a new current State. | Re-activate/reconstruct with an explicit relevance reason; preserve its historical condition and do not make it newly current truth. | Historical means permanently irrelevant. |
| AR-12 | An Event arrives looking current but its occurrence time/source later shows it was historical. | Preserve received and occurrence times; correct the projection through a new governed decision; do not erase the original receipt or treat it as a current change. | Arrival time equals occurrence/currentness. |
| AR-13 | Provide an Event that cannot fit any existing concept or predicate without distortion. | Preserve as NOVEL/INSUFFICIENTLY_MODELED; qualify it; create ontology-extension proposal when material/recurrent; do not force or discard it. | Existing ontology is complete. |
| AR-14 | Several unrelated HIGH/NORMAL issues become eligible simultaneously. | Apply the focus budget: select only the justified FOCUSED item(s), queue/monitor the rest with reasons and review/trigger; do not pursue all. | All important items deserve simultaneous focus. |
| AR-15 | A recurring pattern describes repeated deadline panic but yields no stable, beneficial method. | Preserve a Pattern assertion and counterexamples; do not create a Skill merely from frequency. | Recurrence is sufficient for a Skill. |
| AR-16 | A single rare recovery incident yields a clear, bounded, testable method that prevents severe future loss. | Permit Candidate capability and externalization review despite no recurrence; retain scope and limits. | Recurrence is necessary for a Skill. |
| AR-17 | A context-bound memory is useful only for one person and one historical situation. | Retain as memory or implicit capability; do not externalize as a generally invocable Skill. | Every useful lesson should become a Skill. |
| AR-18 | A one-time migration Skill is useful only during a temporary system transition. | Create explicit temporary Skill if justified; retire it afterward while retaining lineage and History. | Skills are permanent once created. |
| AR-19 | Several project handoffs independently show the same bounded method improves continuity. | Create one Candidate capability/Skill with selective lineage to material supporting and limiting cases. | Each source memory requires its own Skill. |
| AR-20 | A broad coordination Skill repeatedly needs different methods for planning, execution, and closure. | Propose a split only if distinct scopes/mechanisms/outcomes are evidenced; preserve `SPLIT_FROM` lineage. | One broad Skill should remain monolithic. |
| AR-21 | A retrieval Skill fails only when conflicting evidence exists, but remains useful elsewhere. | Revise the existing Skill’s boundary/behavior rather than create a duplicate Skill. | Every failure requires another Skill. |
| AR-22 | A Skill has no material supporting, limiting, contradictory, or operational lineage. | Qualify its trust; request review rather than inventing provenance or treating it as fully supported. | Explicit artifacts are trustworthy without evidence. |
| AR-23 | A keyword-similar Skill exists, but its scope or boundary does not fit the current situation. | Do not apply it; record inapplicability or defer/review as appropriate. | Any available or similar Skill should be reused. |
| AR-24 | A valid Skill is applied and produces an unexpected material outcome. | Create Candidate Experience; retain and link lineage only through normal validation/retention; evaluate revision only through governed evidence. | Skill invocation is the end of learning. |
| AR-25 | A routine Skill invocation succeeds as expected and causes no material change, discovery, exception, or retention obligation. | Keep any required operational trace outside Living Memory; create no Candidate Experience, History event, or lineage relation. | Every Skill use is Experience. |
| AR-26 | A Skill produces a meaningful unexpected result. | Create Candidate Experience, then validate and decide retention; if retained, link the result as lineage evidence. | Outcomes are either automatically memory or automatically ignored. |
| AR-27 | A Skill fails or produces a material exception. | Create Candidate Experience; preserve the failure evidence according to retention/boundary policy; evaluate whether it delimits, contradicts, or refines the Skill. | Failure is only an operational error, not potentially meaningful experience. |
| AR-28 | Skill use reveals a new technique that may apply beyond the present case. | Create Candidate Experience; if retained, create a Pattern assertion or Candidate capability only when the reusable method can be stated. | Any discovered technique is automatically a Skill. |
| AR-29 | Repeated materially independent confirmations show a Skill works within its declared scope. | Aggregate or retain evidence under policy; use it to confirm/trust or evolve the Skill only after governance. | Repetition is either ignored or automatically creates a new Skill version. |
| AR-30 | Memory contains interesting but unrelated material and no discovery signal, request, risk, or blocked decision. | Do not start capability discovery or broaden memory inspection. | Living Memory must always mine itself for Skills. |
| AR-31 | Repeated related Experiences, a repeated successful approach, or a recurring weakness produces a material discovery signal. | Create a bounded discovery inquiry; queue/focus only under attention policy; allow no-capability/defer outcome. | Discovery signals automatically create Skills. |
| AR-32 | A discovery inquiry lacks enough evidence or loses focus capacity. | Defer with scope, evidence, counterexamples, blocker, and reopening condition; do not repeatedly reopen it. | Unresolved discovery must remain active. |
| AR-33 | A Skill works exactly as expected in scope. | Attribute `CONSISTENT_WITH_SKILL`; retain evidence only if material; do not claim sole causation or force evolution. | Success proves the Skill caused the outcome. |
| AR-34 | A Skill fails because the input was outside its scope. | Attribute `OUT_OF_SCOPE`; consider boundary/applicability refinement, not core-Skill failure. | Every failure disproves the Skill. |
| AR-35 | A Skill is correct but an external environmental change alters the result. | Attribute `ENVIRONMENTAL_CHANGE` or `AMBIGUOUS`; preserve evidence; do not revise core method by default. | Outcome is caused solely by the Skill. |
| AR-36 | Two Skills jointly produce a result. | Attribute `JOINT_CONTRIBUTION` or `AMBIGUOUS` unless evidence separates effects; do not give sole credit/blame. | One invoked Skill owns the outcome. |
| AR-37 | The outcome cannot distinguish among several explanations. | Attribute `AMBIGUOUS`; retain/defer or seek resolution; do not revise. | The system must choose one cause. |
| AR-38 | A Skill appears to fail once but succeeds repeatedly afterward in scope. | Preserve the failure as qualified evidence; investigate boundary/context only if supported; do not revise merely from the single unfavorable outcome. | One failure requires Skill revision. |

## Required output for every case

Report, at minimum:

- immutable occurrence and received History;
- current truth and its scope/time, or explicit CONTESTED/unknown result;
- all direct typed Event/State/Relationship relations with status and evidence;
- every derived inference with full path, assumptions, and uncertainty;
- retention, activation, and attention outcomes separately;
- no-action, queue, release, or escalation reason; and
- the attacked assumption and outcome classification.

## Interpret a failure

| Failure shape | Likely hidden assumption | Refinement direction |
|---|---|---|
| System invents links | Similarity, order, or recurrence is treated as evidence. | Tighten predicate evidence guards and false-significance tests. |
| System rewrites earlier meaning | Current interpretation is stored inside immutable occurrence. | Separate Event, interpretation, and integration records. |
| System cannot reactivate old material | Historical/dormant is treated as inaccessible or permanently low-value. | Improve relevance triggers and historical reconstruction. |
| System remains busy after resolution | Attention is coupled to retention/activation. | Enforce release conditions and focus budget. |
| Different arrival order changes final truth | Receipt order is leaking into truth resolution. | Enforce order-invariance and recomputation. |
| Duplicate variants inflate confidence | Similar records are assumed independent. | Add source-dependency and semantic-duplicate policy. |
| Missing chain links are invented | Reconstruction is forced to form a complete narrative. | Require explicit gaps and constrain Derived inference. |
| Formally strong metadata wins without verification | Metadata format is mistaken for authority/authenticity. | Separate validation from provenance verification/corroboration. |
| Novel input is forced or discarded | Ontology completeness is assumed. | Use NOVEL classification and governed ontology evolution. |
| Many issues exhaust capacity | Priority is mistaken for entitlement to focus. | Apply QUEUED/MONITOR states and explicit scope budget. |
| Pattern automatically becomes Skill | Frequency is mistaken for reusable capability. | Require understood, reproducible, useful, and expressible evidence. |
| Rare but critical capability is ignored | Recurrence is treated as necessary. | Permit high-impact, bounded Candidate capability review. |
| Skill proliferates or duplicates | Externalization is treated as the default response to learning. | Preserve implicit capabilities and prefer revision over duplication. |
| Skill loses connection to reality | Lineage and outcomes are not retained. | Require selective material lineage and outcome-based review. |
| Skill is reused outside its scope | Availability or keyword similarity is mistaken for applicability. | Apply purpose, scope, boundary, Direction, and benefit checks before invocation. |
| Routine operations flood memory | Invocation is treated as Experience without a materiality gate. | Separate invocation, execution evidence, Candidate Experience, and retention decision. |
| Capability mining never stops | Pattern discovery is triggered by memory existence rather than governed signals and focus. | Use bounded discovery inquiries, attention states, and deferral/reopening rules. |
| Skill learns the wrong lesson | Outcome is treated as direct proof of Skill success/failure. | Create an attribution assertion and preserve alternative explanations before evolution. |

## Regression invariants

Every material Skill, policy, ontology, or data-model revision must replay all relevant Regression cases. A revision fails release review if it reintroduces a prior failure, unless the change explicitly documents an accepted tradeoff, authority, and mitigation.
