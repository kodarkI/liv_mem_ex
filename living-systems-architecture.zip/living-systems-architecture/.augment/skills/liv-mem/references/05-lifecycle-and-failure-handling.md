# Lifecycle and failure handling

## Relationship lifecycle

Use the lifecycle below. A project may add evidence criteria, but may not skip the distinction between possibility, commitment, and activation.

| Status | Meaning | Entry condition | Permitted next status |
|---|---|---|---|
| POSSIBLE | A connection has been suggested without sufficient evaluation. | Proposal received. | CANDIDATE, rejected/withdrawn. |
| CANDIDATE | The connection is well-formed enough to evaluate. | Subject, predicate, object, and source are known. | SUPPORTED, POSSIBLE, rejected/withdrawn. |
| SUPPORTED | Evidence supports the connection, but Governance has not committed it. | Evidence recorded and evaluated as supporting. | ESTABLISHED, CANDIDATE, rejected/withdrawn. |
| ESTABLISHED | Governance has committed the Relationship as part of the system’s reality. | Governance accepts it under project policy. | ACTIVE, DORMANT, HISTORICAL, revised by new event. |
| ACTIVE | Established and relevant to current context. | Relevance evaluation includes it. | DORMANT, HISTORICAL. |
| DORMANT | Established but not currently active. | No current relevance, while still retained. | ACTIVE, HISTORICAL. |
| HISTORICAL | A formerly established/active Relationship no longer applies as current. | A later transition ends or supersedes its current validity. | Retained as HISTORICAL; a new Relationship/validity period may be proposed. |

`Rejected` and `withdrawn` are outcomes, not architecture statuses. Retain the proposal and reason in History; do not expose it as an established Relationship.

## State transition protocol

1. Receive a State claim through Memory Control.
2. Resolve or defer Entity identity.
3. Create a proposed State snapshot linked to its source.
4. Compare the proposal with the effective State in the same declared scope.
5. Send the proposal to Memory Governance.
6. If accepted, append a transition History event, retain the prior State snapshot, and make the new snapshot effective for its stated time/scope.
7. If rejected or deferred, retain the claim and outcome in History without making it current State.

Never convert an unresolved, conflicting, or temporally ambiguous State claim into current State by default.

## Relevance and activation protocol

Evaluate Relevance after Governance, using only records that declare their status and origin.

1. Establish the current scope and Direction / Intent, if one exists.
2. Consider current State, active Relationships, recent change, historical origin, established context, and governed Integration assertions.
3. Add an item as `ACTIVE` only with a recorded relevance reason.
4. Mark remembered-but-not-selected material `DORMANT`; do not delete it.
5. If no Direction / Intent exists, evaluate Relevance from current scope and governed context only; record that Direction was unavailable.

Activation makes a memory available to the present context; it does not by itself consume attention. Apply [Attention and activation policy](10-attention-and-activation-policy.md) before focusing on an active item.

The scoring, ranking, size limit, and selection algorithm remain project extension points. They must be declared before automated activation is relied on.

## Edge cases and required outcomes

| Case | Required outcome |
|---|---|
| Ambiguous Entity match | Create or retain an unresolved identity candidate; do not merge or select an Entity automatically. |
| Duplicate Experience | Retain provenance and link as a duplicate when detectable; do not create duplicate State transitions or Relationships without independent cause. |
| Conflicting current State claims | Retain both claims with source and scope; do not silently choose one. Governance must reject, defer, or record a project-defined resolution. |
| Out-of-order Experience | Record received time and asserted occurrence time separately; revise current projections only through a new governed transition. |
| Missing occurrence time | Preserve the Experience with unknown occurrence time; do not invent sequence. |
| Relationship missing subject, predicate, object, or source | Keep only as incomplete observation; do not create a Candidate. |
| Evidence later disproves an established Relationship | Record a new governed change; make the prior valid condition Historical or qualified. Do not delete its historical record. |
| Direction changes | Record a new Direction / Intent; rerun Relevance. Do not rewrite History or State merely because Direction changed. |
| Context limit is reached | Demote least-relevant non-required active material to Dormant with a recorded reason; do not delete it. The selection rule is project-defined. |
| Retrieval finds only dormant/historical material | Return it with its temporal condition; do not imply that it is current. |
| Integration contradicts recorded History | Preserve both. Treat integration as a disputed interpretation or reject it; never alter the underlying History event. |
| Event relation lacks a typed predicate or source/evidence | Retain only as an incomplete observation; do not create a generic association as a substitute. |
| Causal assertion has only temporal ordering | Retain `OCCURRED_AFTER`/`OCCURRED_BEFORE` if supported; keep causality unestablished or contested. |
| Later Event supersedes a State | Retain all Events and State snapshots; link the later Event to the governed State transition/supersession rather than rewriting prior Events. |
| Event chain contains a loop | Retain direct asserted relations, flag the cycle for audit/resolution, and do not treat a cyclic traversal as a linear causal or State-transition chain. |
| Insufficient permissions or boundary violation | Reject or defer the operation; record only the allowed metadata and reason. Do not leak protected contents into context. |
| Failure during a multi-record operation | Commit no current projection until the required History event and governed decision can be recorded together; otherwise retain an incomplete operation outcome for recovery. |

## Boundaries between components

| Boundary | Rule |
|---|---|
| Memory Control → Governance | Control proposes and routes; Governance commits, rejects, or defers. |
| Entity → State | State references an Entity; State does not decide identity. |
| State → History | A changed State produces a new historical transition; History does not become current State automatically. |
| Relationship → Relevance | Relationship status precedes activation; Relevance does not establish a Relationship. |
| Historical Integration → History | Integration adds interpretation/assertions; it does not alter occurrence records. |
| Event relationship handling → State | Event relations may explain or support a State transition; only the governed State protocol makes a State effective. |
| Direction → Relevance | Direction informs relevance; it does not redefine facts or directly mutate State. |
| Skills → all components | Skills request defined operations; they may not bypass Memory Control or Governance. |
