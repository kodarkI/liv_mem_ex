# Living cycle and Skills

## Relevance

Use Relevance to prevent unlimited possibilities from becoming active memory.

```text
possible ≠ relevant ≠ established ≠ active
```

A memory becomes active because it has a meaningful Relationship to the current context. Relevance can come from current Entity, current State, active Relationship, recent change, historical origin, current Direction, previously established context, or a newly discovered Relationship.

## Direction / Intent

Use Direction / Intent to answer: **Where is the continuing system moving?** Direction provides another basis for determining Relevance; it does not force every memory toward a predetermined goal.

```text
PAST → CURRENT STATE → CURRENT CONTEXT → DIRECTION → NEXT STATE
```

## Skills

Treat Skills as operations performed on the Living Memory system. They are not the memory itself.

| Skill | Operation |
|---|---|
| Retrieve | Find relevant current State, History, or Relationships. |
| Update | Change current State or Relationship structure. |
| Relate | Create or evaluate connections. |
| Organize | Structure information and Relationships. |
| Compare | Examine different States or experiences. |
| Reconstruct | Rebuild relevant context from History. |
| Integrate | Connect newly relevant experience with existing History. |
| Transition | Record movement from one State to another. |

Require Skills to operate through Memory Control and Memory Governance rather than bypassing them.

## The Living Cycle

```text
EXPERIENCE
  ↓
PERCEPTION
  ↓
IDENTIFICATION
  ↓
MEMORY OPERATION
  ↓
RELEVANCE / GOVERNANCE
  ↓
STATE + RELATIONSHIP + HISTORY
  ↓
INTEGRATION
  ↓
CURRENT CONTEXT
  ↓
DIRECTION
  ↓
NEXT STATE
  ↓
NEW EXPERIENCE
  ↓
…
```

Treat this as a continuity loop, not simply an update loop.
