# Self-auditing and skill evolution

## Self-Auditing

Self-Auditing is a system function distinct from ordinary failure handling. Failure handling reacts to a known failed operation. Self-Auditing periodically or event-triggeredly inspects the system for drift, degradation, broken invariants, and repeated weaknesses before they become failures.

Run audits on a defined schedule and after material changes to policies, Skills, migrations, or abnormal failure rates. Store every result as an Audit finding, including successful audit runs.

## Audit invariants

At minimum, audit the following:

| Invariant | Detect | Required outcome |
|---|---|---|
| Provenance | Memory-bearing records missing source, identifier, or required History link. | Mark finding; prevent promotion/current use where required; propose repair or resolution. |
| Referential integrity | Broken Entity, predecessor/successor, source, evidence, or context references. | Mark finding; exclude broken derived records from current context; preserve the original record. |
| Lifecycle integrity | Invalid state/status transitions or records missing required validation/governance decisions. | Mark finding; quarantine the affected projection from current truth; request governed repair. |
| Current-truth consistency | More than one EFFECTIVE conflicting claim in the same scope/time. | Mark claims CONTESTED or preserve established policy winner; never silently select an arbitrary one. |
| Duplicate/identity integrity | Likely duplicate Experiences, State snapshots, Relationships, or Entities. | Create candidate duplicate/identity-resolution work; do not automatically merge. |
| Context integrity | ACTIVE material lacking a relevance reason, invalid status, or accessible provenance. | Demote it from ACTIVE pending reevaluation; keep it retained. |
| Attention integrity | FOCUSED/URGENT work without a qualifying trigger, priority reason, budget slot, or release/review condition; QUEUED work that is never reviewed. | Release, queue, or correct the allocation under Attention Control; do not silently expand the focus budget. |
| Event-chain integrity | Event relations without typed predicates/evidence, invalid endpoint types, missing State-transition links, impossible temporal claims, or unintended cycles. | Preserve direct records, flag the chain, exclude invalid derived chain conclusions, and request governed repair/resolution. |
| Provenance-strength integrity | Strong-looking metadata accepted as proof of authenticity/authority, weak-provenance claims treated as false by default, or duplicate/copying sources counted as independent support. | Qualify the affected support/truth outcome; preserve claims; request provenance or corroboration review. |
| Order-invariance integrity | Equivalent complete evidence sets produce different final truth results only because claims arrived in different order. | Flag as a resolution defect; recompute under the declared policy and retain the arrival-order history separately. |
| Regression integrity | A previously recorded failed challenge has no replay result after a material Skill/policy change, or a known failure returns without an explicit accepted tradeoff. | Block release of the changed behavior where appropriate; create an Audit finding and refinement/rollback proposal. |
| Capability-lineage integrity | Explicit Skill lacks the internal lineage, external provenance, or unknown-provenance classification required for its origin; or revision/split/merge/retirement loses required material evidence. | Qualify the Skill’s trust status; request lineage/provenance review; do not invent source evidence. |
| Candidate-capability integrity | Candidate lacks lifecycle status, review/reopen condition, disposition reason, or remains active/deferred beyond its declared review without assessment. | Review, defer, strengthen, reject, or mark stale/expired; preserve underlying evidence and do not silently delete it. |
| Skill-coordination integrity | Multiple applicable Skills are jointly invoked without a coordination plan, conflicting Skills are combined, or prerequisite/order constraints are ignored. | Stop unsafe joint execution; create or repair a governed coordination plan. |
| Retention integrity | Records past review date, durable records without a rationale, or pruned records without tombstones. | Create retention review; prohibit untraceable deletion. |
| Skill conformance | Operations that bypassed contracts, used obsolete policy versions, or produced recurring exceptions. | Record finding and route it to weakness analysis. |

An audit may propose a repair but may not directly alter historical occurrence records, silently merge Entities, or make a contested claim effective.

## Detect recurring weaknesses

A recurring weakness is not a single failure. It is a repeated pattern of Audit findings, deferred decisions, failed operations, or manual overrides sharing a component, Skill, invariant, operation type, or root-cause hypothesis within a project-defined observation window.

For every detected pattern:

1. Create a weakness record with the matched evidence and window.
2. Classify its impact: data integrity, incorrect current context, missing retention, policy ambiguity, performance/capacity, boundary/security, or usability/operational burden.
3. Check whether a known exception or an existing unresolved design question explains it.
4. If evidence is insufficient, keep the weakness as a candidate; do not claim root cause.
5. If evidence is sufficient under project policy, create a Skill refinement proposal or a component/policy change proposal.
6. Track the proposal through resolution and audit its outcome after deployment.

Do not revise a Skill solely because of one surprising output unless it reveals a direct violation of a defined invariant.

## Skill evolution lifecycle

Treat a Skill as a governed, versioned operational artifact. A Skill version governs future operations; it does not rewrite the History of operations performed under an earlier version.

```text
OBSERVATION → WEAKNESS CANDIDATE → REFINEMENT PROPOSAL → REVIEW → APPROVED / REJECTED / DEFERRED → DEPLOYED VERSION → OUTCOME AUDIT
```

| Stage | Required behavior |
|---|---|
| Observation | Record operational evidence: Audit finding, failure, exception, repeated override, or validated improvement opportunity. |
| Weakness candidate | State the affected Skill rule, evidence, impact, and unresolved assumptions. |
| Refinement proposal | Specify the exact rule change, intended effect, affected components, migration/compatibility plan, test cases, risks, and rollback condition. |
| Review | Check consistency with foundational principles, component boundaries, existing Skills, and open design questions. |
| Approved / Rejected / Deferred | Record the governed decision and rationale. Rejected/Deferred proposals remain historical learning, not active rules. |
| Deployed version | Create a new Skill version with effective time and supersession link. Keep the prior version retrievable. |
| Outcome audit | Compare expected and observed behavior; retain, revise, or roll back the new version through another governed version event. |

Treat a failed architecture challenge as an Observation. Record the scenario, expected invariant, actual behavior, affected Skill rule/component, and whether the failure is a missing rule, ambiguous rule, invalid implementation, or intentional open design question. Route repeated or material failures through the normal weakness and refinement lifecycle.

Keep every `FAIL` and `PARTIAL` challenge as a permanent regression case. Do not delete or overwrite a failed case after a fix; append a replay result under the new Skill/policy version.

## Non-negotiable evolution rules

- Do not let a Skill edit itself directly from a single observation.
- Do not replace an old Skill version in place; create a successor version.
- Do not use a new rule retroactively to judge historical operations without recording the policy/version distinction.
- Do not approve a refinement that breaks provenance, sequence, the separation of History from State, or the separation of possibility from commitment.
- Do not deploy a refinement without declared validation cases and an outcome-audit condition.

## Boundaries

| Boundary | Rule |
|---|---|
| Self-Auditing → Memory Governance | Audit reports findings and repair proposals; Governance decides commitment/action. |
| Weakness analysis → Skill Evolution | Analysis identifies evidence-backed patterns; Skill Evolution versions operating rules. |
| Skill Evolution → Operations | New versions govern only operations occurring after their effective time, unless a separately governed migration states otherwise. |
| Audit → History | Audit adds evidence and interpretation; it does not alter historical occurrences. |
